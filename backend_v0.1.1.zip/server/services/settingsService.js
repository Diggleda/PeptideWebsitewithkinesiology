const mysqlClient = require('../database/mysqlClient');
const { settingsStore } = require('../storage');
const { logger } = require('../config/logger');
const { env } = require('../config/env');

const DEFAULT_SETTINGS = {
  shopEnabled: true,
  stripeMode: null, // null = follow env
};

const SETTINGS_KEYS = Object.keys(DEFAULT_SETTINGS);

const normalizeSettings = (settings = {}) => {
  const merged = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  merged.shopEnabled = Boolean(merged.shopEnabled);
  const stripeMode = typeof merged.stripeMode === 'string'
    ? merged.stripeMode.toLowerCase().trim()
    : null;
  merged.stripeMode = (stripeMode === 'test' || stripeMode === 'live') ? stripeMode : null;
  return merged;
};

const loadFromStore = () => normalizeSettings(settingsStore.read());

const persistToStore = (settings) => {
  settingsStore.write(normalizeSettings(settings));
};

const loadFromSql = async () => {
  if (!mysqlClient.isEnabled()) {
    return null;
  }

  try {
    const rows = await mysqlClient.fetchAll?.(
      'SELECT `key`, `value_json` FROM settings WHERE `key` IN ("shopEnabled","stripeMode")',
    );
    if (!rows || !Array.isArray(rows)) {
      return null;
    }
    const merged = { ...DEFAULT_SETTINGS };
    rows.forEach((row) => {
      if (!row || !row.key) return;
      if (!Object.prototype.hasOwnProperty.call(DEFAULT_SETTINGS, row.key)) return;
      if (Object.prototype.hasOwnProperty.call(row, 'value_json')) {
        merged[row.key] = row.value_json;
      }
    });
    return normalizeSettings(merged);
  } catch (error) {
    logger.warn({ err: error }, 'Failed to load settings from MySQL; falling back to file store');
    return null;
  }
};

const persistToSql = async (settings) => {
  if (!mysqlClient.isEnabled()) {
    return;
  }
  const normalized = normalizeSettings(settings);
  try {
    for (const key of SETTINGS_KEYS) {
      // eslint-disable-next-line no-await-in-loop
      await mysqlClient.execute(
        `
          INSERT INTO settings (\`key\`, value_json, updated_at)
          VALUES (:key, :value_json, NOW())
          ON DUPLICATE KEY UPDATE value_json = VALUES(value_json), updated_at = NOW()
        `,
        { key, value_json: normalized[key] },
      );
    }
  } catch (error) {
    logger.error({ err: error }, 'Failed to persist settings to MySQL');
  }
};

const getSettings = async () => {
  const sqlSettings = await loadFromSql();
  if (sqlSettings) {
    persistToStore(sqlSettings);
    return sqlSettings;
  }
  return loadFromStore();
};

const getShopEnabled = async () => {
  const settings = await getSettings();
  return Boolean(settings.shopEnabled);
};

const setShopEnabled = async (enabled) => {
  const next = normalizeSettings({ ...loadFromStore(), shopEnabled: Boolean(enabled) });
  persistToStore(next);
  await persistToSql(next);
  return next.shopEnabled;
};

const resolveStripeMode = (settings) => {
  const override = settings?.stripeMode;
  if (override === 'test' || override === 'live') {
    return override;
  }
  const mode = String(env.stripe?.mode || 'test').toLowerCase().trim();
  return mode === 'live' ? 'live' : 'test';
};

const getStripeMode = async () => {
  const settings = await getSettings();
  return resolveStripeMode(settings);
};

const getStripeModeSync = () => resolveStripeMode(loadFromStore());

const setStripeMode = async (mode) => {
  const normalizedMode = String(mode || '').toLowerCase().trim();
  const value = normalizedMode === 'live' ? 'live' : 'test';
  const next = normalizeSettings({ ...loadFromStore(), stripeMode: value });
  persistToStore(next);
  await persistToSql(next);
  return resolveStripeMode(next);
};

module.exports = {
  getSettings,
  getShopEnabled,
  setShopEnabled,
  getStripeMode,
  getStripeModeSync,
  setStripeMode,
  SETTINGS_KEYS,
  DEFAULT_SETTINGS,
};
