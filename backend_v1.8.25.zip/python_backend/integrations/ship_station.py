from __future__ import annotations

import logging
from typing import Dict, List, Optional

import requests

from ..services import get_config

logger = logging.getLogger(__name__)

API_BASE_URL = "https://ssapi.shipstation.com"


class IntegrationError(RuntimeError):
    def __init__(self, message: str, response: Optional[Dict] = None, status: int = 500):
        super().__init__(message)
        self.response = response
        self.status = status


def is_configured(log: bool = False) -> bool:
    cfg = get_config().ship_station
    configured = bool(cfg.get("api_token") or (cfg.get("api_key") and cfg.get("api_secret")))
    if log:
        logger.info(
            "ShipStation configuration check",
            extra={
                "api_token_set": bool(cfg.get("api_token")),
                "api_key_set": bool(cfg.get("api_key")),
                "api_secret_set": bool(cfg.get("api_secret")),
                "carrier_code": bool(cfg.get("carrier_code")),
                "service_code": bool(cfg.get("service_code")),
                "ship_from_postal": cfg.get("ship_from", {}).get("postal_code"),
            },
        )
    return configured


def _http_args():
    cfg = get_config().ship_station
    headers = {"Content-Type": "application/json"}
    auth = None
    if cfg.get("api_token"):
        headers["Authorization"] = f"Bearer {cfg['api_token']}"
    else:
        auth = (cfg.get("api_key"), cfg.get("api_secret"))
    return headers, auth


def _sum_weight_ounces(items: List[Dict]) -> float:
    total = 0.0
    for item in items or []:
        total += float(item.get("quantity") or 0) * float(item.get("weightOz") or 0)
    return max(total, 8.0)


def _aggregate_dimensions(items: List[Dict]) -> Optional[Dict]:
    length = None
    width = None
    height = None

    for item in items or []:
        q = float(item.get("quantity") or 0) or 0
        l = _coerce_inventory_number(item.get("length"))
        w = _coerce_inventory_number(item.get("width"))
        h = _coerce_inventory_number(item.get("height"))
        if l and (length is None or l > length):
            length = l
        if w and (width is None or w > width):
            width = w
        if h:
            height = (height or 0) + h * max(q, 1)

    if length and width and height:
        return {
            "length": length,
            "width": width,
            "height": height,
            "units": "inches",
        }
    return None


def _ship_from() -> Dict:
    cfg = get_config().ship_station.get("ship_from") or {}
    return {
        "city": cfg.get("city") or "",
        "state": cfg.get("state") or "",
        "postal_code": cfg.get("postal_code") or "",
        "country": cfg.get("country_code") or "US",
    }


def _coerce_inventory_number(*values: Optional[float]) -> Optional[float]:
    for value in values:
        if value in (None, "", False):
            continue
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            continue
        if numeric >= 0:
            return numeric
    return None


def estimate_rates(shipping_address: Dict, items: List[Dict]) -> List[Dict]:
    if not is_configured():
        raise IntegrationError("ShipStation is not configured", status=503)

    required = [
        shipping_address.get("addressLine1"),
        shipping_address.get("city"),
        shipping_address.get("state"),
        shipping_address.get("postalCode"),
    ]
    if not all(required):
        raise IntegrationError("Shipping address is incomplete", status=400)

    headers, auth = _http_args()
    cfg = get_config().ship_station
    ship_from = _ship_from()
    def build_payload(strip_service: bool = False) -> Dict:
        service_code = None if strip_service else (cfg.get("service_code") or None)
        carrier_code = cfg.get("carrier_code") or None
        if not service_code:
            # Without a pinned service, omit carrier to let ShipStation return all enabled carriers.
            carrier_code = None
        payload = {
            "carrierCode": carrier_code,
            "serviceCode": service_code,
            "packageCode": cfg.get("package_code") or None,
            "confirmation": "none",
            "fromCity": ship_from["city"],
            "fromState": ship_from["state"],
            "fromPostalCode": ship_from["postal_code"],
            "fromCountry": ship_from["country"],
            "toCity": shipping_address.get("city"),
            "toState": shipping_address.get("state"),
            "toPostalCode": shipping_address.get("postalCode"),
            "toCountry": shipping_address.get("country") or "US",
            "weight": {
                "value": _sum_weight_ounces(items or []),
                "units": "ounces",
            },
        }
        dimensions = _aggregate_dimensions(items or [])
        if dimensions:
            payload["dimensions"] = dimensions
        return {k: v for k, v in payload.items() if v not in (None, "", {})}

    payload = build_payload(strip_service=False)

    def _extract_response(exc: requests.RequestException):
        data = None
        status = getattr(exc.response, "status_code", None)
        if exc.response is not None:
            try:
                data = exc.response.json()
            except Exception:
                data = exc.response.text
        return data, status

    def attempt(payload_variant: Dict):
        resp = requests.post(
            f"{API_BASE_URL}/shipments/getrates",
            json=payload_variant,
            headers=headers,
            auth=auth,
            timeout=15,
        )
        resp.raise_for_status()
        return resp

    try:
        response = attempt(payload)
    except requests.RequestException as exc:  # pragma: no cover
        data, status = _extract_response(exc)

        logger.warning(
            "ShipStation rate request failed; retrying without serviceCode",
            exc_info=True,
            extra={
                "status": status,
                "payload": payload,
                "response": data,
            },
        )
        try:
            retry_payload = build_payload(strip_service=True)
            response = attempt(retry_payload)
        except requests.RequestException as retry_exc:  # pragma: no cover
            retry_data, retry_status = _extract_response(retry_exc)
            logger.error(
                "ShipStation rate request failed after retry",
                exc_info=True,
                extra={
                    "status": retry_status,
                    "payload": retry_payload,
                    "response": retry_data,
                },
            )
            raise IntegrationError(
                "Failed to retrieve ShipStation rates",
                response=retry_data or data,
                status=retry_status or status or 502,
            ) from retry_exc

    data = response.json()
    return data if isinstance(data, list) else []


def fetch_product_by_sku(sku: Optional[str]) -> Optional[Dict]:
    if not sku or not is_configured():
        return None

    headers, auth = _http_args()
    params = {
        "sku": sku.strip(),
        "includeInactive": "false",
        "pageSize": 1,
    }

    try:
        response = requests.get(
            f"{API_BASE_URL}/products",
            params=params,
            headers=headers,
            auth=auth,
            timeout=10,
        )
        response.raise_for_status()
    except requests.RequestException as exc:  # pragma: no cover - defensive logging
        data = None
        if exc.response is not None:
            try:
                data = exc.response.json()
            except Exception:
                data = exc.response.text
        logger.error("ShipStation product lookup failed", exc_info=True, extra={"sku": sku})
        raise IntegrationError("Failed to fetch ShipStation product", response=data) from exc

    payload = response.json() or {}
    products = payload.get("products") if isinstance(payload, dict) else None
    if isinstance(products, list) and products:
        product = products[0] or {}
        return {
            "id": product.get("productId") or product.get("product_id") or product.get("id"),
            "sku": product.get("sku") or sku,
            "name": product.get("name"),
            "stockOnHand": _coerce_inventory_number(
                product.get("onHand"),
                product.get("quantityOnHand"),
                product.get("quantity_on_hand"),
                product.get("stock"),
            ),
            "available": _coerce_inventory_number(
                product.get("available"),
                product.get("quantityAvailable"),
                product.get("quantity_available"),
            ),
        }
    return None


def fetch_order_status(order_number: Optional[str]) -> Optional[Dict]:
    """
    Retrieve ShipStation order details by order number to check fulfillment status/tracking.
    Returns a minimal dict or None if not found.
    """
    if not order_number or not is_configured():
        return None

    headers, auth = _http_args()
    try:
        resp = requests.get(
            f"{API_BASE_URL}/orders",
            params={"orderNumber": str(order_number).strip(), "pageSize": 1},
            headers=headers,
            auth=auth,
            timeout=10,
        )
        resp.raise_for_status()
    except requests.RequestException as exc:  # pragma: no cover - network path
        data = None
        if exc.response is not None:
            try:
                data = exc.response.json()
            except Exception:
                data = exc.response.text
        logger.error("ShipStation order lookup failed", exc_info=True, extra={"orderNumber": order_number})
        raise IntegrationError("ShipStation order lookup failed", response=data, status=getattr(exc.response, "status_code", 502) or 502) from exc

    payload = resp.json() or {}
    orders = payload.get("orders") if isinstance(payload, dict) else None
    if not orders:
        return None
    order = orders[0] or {}
    shipments = order.get("shipments") or []
    tracking = None
    if isinstance(shipments, list) and shipments:
        for shipment in shipments:
            tracking = shipment.get("trackingNumber") or tracking
            if tracking:
                break
    return {
        "status": order.get("orderStatus"),
        "shipDate": order.get("shipDate"),
        "trackingNumber": tracking or order.get("trackingNumber"),
        "carrierCode": order.get("carrierCode"),
        "serviceCode": order.get("serviceCode"),
        "orderNumber": order.get("orderNumber"),
        "orderId": order.get("orderId"),
    }
