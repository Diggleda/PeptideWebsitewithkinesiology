const { initStorage } = require('../storage');
const { logger } = require('../config/logger');
const { env } = require('../config/env');
const mysqlClient = require('../database/mysqlClient');
const mysqlSchema = require('../database/mysqlSchema');

const bootstrap = async () => {
  initStorage();
  logger.info({ dataDir: env.dataDir }, 'Storage initialized');
  if (env.mysql?.enabled) {
    await mysqlClient.configure();
    await mysqlSchema.ensureSchema();
  }
};

module.exports = { bootstrap };
