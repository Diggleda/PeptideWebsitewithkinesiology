from __future__ import annotations

import hashlib
import logging
from typing import Dict, List, Tuple

from . import get_config
from ..integrations import ship_engine

logger = logging.getLogger(__name__)


class ShippingError(RuntimeError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _normalize_string(value) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _sanitize_address(raw: Dict) -> Dict:
    return {
        "name": _normalize_string(raw.get("name")) or None,
        "company": _normalize_string(raw.get("company")) or None,
        "addressLine1": _normalize_string(raw.get("addressLine1")),
        "addressLine2": _normalize_string(raw.get("addressLine2")),
        "city": _normalize_string(raw.get("city")),
        "state": _normalize_string(raw.get("state")),
        "postalCode": _normalize_string(raw.get("postalCode")),
        "country": _normalize_string(raw.get("country")) or "US",
        "phone": _normalize_string(raw.get("phone")) or None,
    }


def _ensure_address(raw: Dict) -> Dict:
    if not isinstance(raw, dict):
        raise ShippingError("Shipping address is required")
    sanitized = _sanitize_address(raw)
    required_fields = [
        sanitized["addressLine1"],
        sanitized["city"],
        sanitized["state"],
        sanitized["postalCode"],
        sanitized["country"],
    ]
    if not all(required_fields):
        raise ShippingError("Shipping address must include street, city, state, postal code, and country")
    return sanitized


def _normalize_items(raw_items) -> List[Dict]:
    normalized: List[Dict] = []
    if not isinstance(raw_items, list):
        return normalized
    for item in raw_items:
        try:
            quantity = float(item.get("quantity") or 0)
            weight = float(item.get("weightOz") or 0)
        except (TypeError, ValueError):
            quantity = 0
            weight = 0
        if quantity <= 0:
            continue
        normalized.append({"quantity": quantity, "weightOz": max(weight, 0)})
    return normalized


def _total_weight(items: List[Dict]) -> float:
    weight = 0.0
    for item in items:
        weight += item["quantity"] * item["weightOz"]
    return max(weight, 8.0)


def _create_fingerprint(address: Dict) -> str:
    parts = [
        address.get("addressLine1"),
        address.get("addressLine2"),
        address.get("city"),
        address.get("state"),
        address.get("postalCode"),
        address.get("country"),
    ]
    data = "|".join((part or "").upper() for part in parts)
    return hashlib.sha1(data.encode("utf-8")).hexdigest()


def get_rates(shipping_address: Dict, items) -> Dict:
    address = _ensure_address(shipping_address or {})
    normalized_items = _normalize_items(items or [])
    if not normalized_items:
        raise ShippingError("At least one item with quantity is required to price shipping")

    if not ship_engine.is_configured():
        raise ShippingError("Shipping is not configured", status=503)

    fingerprint = _create_fingerprint(address)
    total_weight = _total_weight(normalized_items)

    try:
        raw_rates = ship_engine.estimate_rates(address, total_weight)
    except ship_engine.IntegrationError as exc:
        logger.error("ShipEngine rate estimate failed", exc_info=True)
        error_message = "Failed to retrieve shipping rates"
        if isinstance(exc.response, dict):
            errors = exc.response.get("errors") or exc.response.get("message")
            if errors:
                if isinstance(errors, list):
                    error_message = errors[0].get("message") or error_message
                elif isinstance(errors, str):
                    error_message = errors
        raise ShippingError(error_message, status=502) from exc

    rates = []
    for rate in raw_rates or []:
        amount_info = rate.get("shipping_amount") or rate.get("amount") or {}
        try:
            amount = float(amount_info.get("amount") or amount_info.get("value"))
        except (TypeError, ValueError):
            amount = None
        if amount is None:
            continue
        currency = amount_info.get("currency") or "USD"
        rates.append(
            {
                "carrierId": rate.get("carrier_id"),
                "serviceCode": rate.get("service_code"),
                "serviceType": rate.get("service_type"),
                "estimatedDeliveryDays": rate.get("delivery_days") or rate.get("estimated_days"),
                "deliveryDateGuaranteed": rate.get("guaranteed_service"),
                "rate": amount,
                "currency": currency,
                "addressFingerprint": fingerprint,
                "meta": {
                    "carrierFriendlyName": rate.get("carrier_friendly_name"),
                    "serviceDescription": rate.get("service_description"),
                },
            }
        )

    return {
        "success": True,
        "rates": rates,
        "addressFingerprint": fingerprint,
    }
