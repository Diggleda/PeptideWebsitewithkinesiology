<?php
declare(strict_types=1);

// loads your secure config outside webroot (same pattern you used before)
$config = require('/home/oz0fsscenn2m/secure/config_googlesheetsWebhook.php');

// CORS preflight for Google Sheets
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
  header('Access-Control-Allow-Origin: https://docs.google.com');
  header('Access-Control-Allow-Headers: Content-Type, Authorization, X-WebHook-Signature');
  header('Access-Control-Allow-Methods: POST, OPTIONS');
  http_response_code(204);
  exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://docs.google.com');

// Method guard
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
  exit;
}

// Simple shared-secret auth (mirrors your sales-reps handler)
$provided = ($_SERVER['HTTP_AUTHORIZATION'] ?? '') ?: ($_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '');
if (!isset($config['webhook_secret']) || !hash_equals((string)$config['webhook_secret'], (string)$provided)) {
  http_response_code(401);
  echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
  exit;
}

// Read JSON
$raw = file_get_contents('php://input') ?: '';
$payload = json_decode($raw, true);
if (!is_array($payload) || !isset($payload['quotes']) || !is_array($payload['quotes'])) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid payload; expected { "quotes": [...] }']);
  exit;
}

// DB connect (PDO)
$pdo = new PDO(
  (string)$config['dsn'],
  (string)$config['username'],
  (string)$config['password'],
  [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);

// Ensure table (adjust if you already have it)
$pdo->exec("\n  CREATE TABLE IF NOT EXISTS quotes (\n    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,\n    text VARCHAR(1024) NOT NULL,\n    author VARCHAR(255) DEFAULT NULL,\n    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n    UNIQUE KEY uq_text_author (text(255), author(191))\n  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n");

// Insert / upsert
$insert = $pdo->prepare("\n  INSERT INTO quotes (text, author)\n  VALUES (:text, :author)\n  ON DUPLICATE KEY UPDATE\n    author = VALUES(author),\n    updated_at = CURRENT_TIMESTAMP\n");

$results = [];
foreach ($payload['quotes'] as $i => $q) {
  $text = trim((string)($q['text'] ?? ''));
  $author = trim((string)($q['author'] ?? ''));
  if ($text === '' && $author === '') {
    $results[] = ['index' => $i, 'status' => 'skipped', 'reason' => 'empty row'];
    continue;
  }
  try {
    $insert->execute([':text' => $text, ':author' => ($author !== '' ? $author : null)]);
    $status = ($insert->rowCount() === 1) ? 'inserted' : 'updated';
    $results[] = ['index' => (int)$i, 'status' => $status];
  } catch (Throwable $e) {
    $results[] = ['index' => (int)$i, 'status' => 'error', 'reason' => $e->getMessage()];
  }
}

echo json_encode(['ok' => true, 'results' => $results], JSON_UNESCAPED_SLASHES);
?>
