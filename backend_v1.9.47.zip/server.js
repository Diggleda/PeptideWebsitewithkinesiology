const { start } = require('./server/index');

start();
