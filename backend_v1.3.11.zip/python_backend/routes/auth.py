from __future__ import annotations

from typing import Dict, Optional

from flask import Blueprint, g, request

from ..middleware.auth import require_auth
from ..services import auth_service, passkey_service
from ..utils.http import handle_action

blueprint = Blueprint("auth", __name__, url_prefix="/api/auth")


@blueprint.post("/register")
def register():
    payload = request.get_json(force=True, silent=True) or {}
    return handle_action(lambda: auth_service.register(payload))


@blueprint.post("/login")
def login():
    payload = request.get_json(force=True, silent=True) or {}
    return handle_action(lambda: auth_service.login(payload))


@blueprint.get("/check-email")
def check_email():
    email = request.args.get("email", "")
    return handle_action(lambda: auth_service.check_email(email))


@blueprint.get("/me")
@require_auth
def me():
    user_id = g.current_user.get("id")
    return handle_action(lambda: auth_service.get_profile(user_id))


@blueprint.post("/verify-npi")
def verify_npi():
    payload = request.get_json(force=True, silent=True) or {}
    npi_number = payload.get("npiNumber") or payload.get("npi_number")
    return handle_action(lambda: auth_service.verify_npi(npi_number))


@blueprint.put("/me")
@require_auth
def update_me():
    user_id = g.current_user.get("id")
    payload = request.get_json(force=True, silent=True) or {}
    return handle_action(lambda: auth_service.update_profile(user_id, payload))


@blueprint.post("/passkeys/login/options")
def passkey_login_options():
    payload = request.get_json(force=True, silent=True) or {}
    context = _passkey_context()
    return handle_action(
        lambda: passkey_service.generate_authentication_options_for_user(
            payload.get("email"),
            origin=context["origin"],
            rp_id=context["rp_id"],
        )
    )


@blueprint.post("/passkeys/login/verify")
def passkey_login_verify():
    payload = request.get_json(force=True, silent=True) or {}
    context = _passkey_context()
    return handle_action(
        lambda: passkey_service.verify_authentication_response_for_user(
            payload,
            origin=context["origin"],
            rp_id=context["rp_id"],
        )
    )


@blueprint.post("/passkeys/register/options")
@require_auth
def passkey_register_options():
    context = _passkey_context()
    return handle_action(
        lambda: passkey_service.generate_registration_options_for_user(
            g.current_user.get("id"),
            origin=context["origin"],
            rp_id=context["rp_id"],
        )
    )


@blueprint.post("/passkeys/register/verify")
@require_auth
def passkey_register_verify():
    payload = request.get_json(force=True, silent=True) or {}
    context = _passkey_context()
    return handle_action(
        lambda: passkey_service.verify_registration_response_for_user(
            payload,
            g.current_user.get("id"),
            origin=context["origin"],
            rp_id=context["rp_id"],
        )
    )


def _passkey_context() -> Dict[str, Optional[str]]:
    return {
        "origin": _get_request_origin(),
        "rp_id": _get_request_rp_id(),
    }


def _get_request_origin() -> Optional[str]:
    origin = request.headers.get("Origin")
    if origin:
        return origin
    referer = request.headers.get("Referer")
    if referer:
        try:
            from urllib.parse import urlparse

            parsed = urlparse(referer)
            if parsed.scheme and parsed.netloc:
                return f"{parsed.scheme}://{parsed.netloc}"
        except ValueError:
            pass
    host = _get_request_host()
    if host:
        proto = _resolve_protocol(host)
        return f"{proto}://{host}"
    return None


def _get_request_rp_id() -> Optional[str]:
    host = _get_request_host()
    if not host:
        return None
    return host.split(":")[0].lower()


def _get_request_host() -> Optional[str]:
    forwarded = request.headers.get("X-Forwarded-Host")
    if forwarded:
        return forwarded.split(",")[0].strip()
    host = request.host or ""
    return host.split(",")[0].strip() or None


def _resolve_protocol(host: str) -> str:
    proto_header = request.headers.get("X-Forwarded-Proto")
    if proto_header:
        proto = proto_header.split(",")[0].strip().lower()
        if proto == "http" and not _is_loopback_host(host):
            return "https"
        if proto:
            return proto
    if not _is_loopback_host(host):
        return "https"
    return request.scheme or "http"


def _is_loopback_host(host: str) -> bool:
    normalized = (host or "").lower()
    return (
        normalized.startswith("127.")
        or normalized.startswith("[::1]")
        or normalized == "localhost"
        or normalized == "::1"
    )
