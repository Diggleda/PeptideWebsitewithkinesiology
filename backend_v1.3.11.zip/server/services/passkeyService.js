const crypto = require('crypto');
const {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} = require('@simplewebauthn/server');
const { isoBase64URL } = require('@simplewebauthn/server/helpers');
const userRepository = require('../repositories/userRepository');
const { env } = require('../config/env');
const { sanitizeUser, createAuthToken } = require('./authService');

const defaultRpId = (env.passkeys?.rpId || '').trim().toLowerCase() || null;
const rpName = (env.passkeys?.rpName || '').trim() || 'PepPro Marketplace';
const baseAllowedOrigins = (env.passkeys?.origins?.length ? env.passkeys.origins : [])
  .concat([
    'http://localhost:5173',
    'http://127.0.0.1:5173',
  ])
  .map((value) => value && value.trim())
  .filter((value, index, array) => Boolean(value) && array.indexOf(value) === index);

const registrationChallenges = new Map();
const authenticationChallenges = new Map();

const normalizeOrigin = (value) => {
  if (!value || typeof value !== 'string') {
    return null;
  }
  try {
    const url = new URL(value);
    return url.origin;
  } catch {
    return null;
  }
};

const normalizeRpId = (value) => {
  if (!value || typeof value !== 'string') {
    return null;
  }
  return value.trim().toLowerCase() || null;
};

const isSubdomainOfDefault = (candidate) => {
  if (!defaultRpId) {
    return false;
  }
  if (!candidate) {
    return false;
  }
  if (candidate === defaultRpId) {
    return true;
  }
  return candidate.endsWith(`.${defaultRpId}`);
};

const resolveRpId = (candidate) => {
  const normalizedCandidate = normalizeRpId(candidate);
  if (defaultRpId) {
    if (!normalizedCandidate) {
      return defaultRpId;
    }
    if (isSubdomainOfDefault(normalizedCandidate)) {
      return defaultRpId;
    }
  }
  return normalizedCandidate || defaultRpId || 'localhost';
};

const buildAllowedOrigins = (candidateOrigin) => {
  const normalized = normalizeOrigin(candidateOrigin);
  const values = normalized ? [...baseAllowedOrigins, normalized] : [...baseAllowedOrigins];
  return values
    .map((origin) => origin && origin.trim())
    .filter((origin, index, array) => Boolean(origin) && array.indexOf(origin) === index);
};

const createError = (message, status = 400) => {
  const error = new Error(message);
  error.status = status;
  return error;
};

const randomId = () => {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return crypto.randomBytes(16).toString('hex');
};

const getUserById = (userId) => {
  const user = userRepository.findById(userId);
  if (!user) {
    throw createError('USER_NOT_FOUND', 404);
  }
  return user;
};

const ensurePasskeys = (user) => (Array.isArray(user.passkeys) ? user.passkeys : []);

const toAuthenticator = (passkey) => ({
  credentialID: isoBase64URL.toBuffer(passkey.credentialID),
  credentialPublicKey: isoBase64URL.toBuffer(passkey.publicKey),
  counter: passkey.counter || 0,
  transports: passkey.transports || [],
});

const findAuthenticatorOwner = (credentialId) => {
  const user = userRepository.findByPasskeyId(credentialId);
  if (!user) {
    throw createError('PASSKEY_NOT_FOUND', 404);
  }
  const passkeys = ensurePasskeys(user);
  const entry = passkeys.find((pk) => pk.credentialID === credentialId);
  if (!entry) {
    throw createError('PASSKEY_NOT_FOUND', 404);
  }
  return { user, entry };
};

const generateOptionsForRegistration = async (userId, context = {}) => {
  const user = getUserById(userId);
  const existingPasskeys = ensurePasskeys(user);
  const effectiveRpId = resolveRpId(context?.rpId);
  const originHint = normalizeOrigin(context?.origin);

  const options = await generateRegistrationOptions({
    rpName,
    rpID: effectiveRpId,
    userID: user.id,
    userName: user.email,
    userDisplayName: user.name || user.email,
    attestationType: 'none',
    authenticatorSelection: {
      residentKey: 'preferred',
      userVerification: 'required',
      authenticatorAttachment: 'platform',
    },
    excludeCredentials: existingPasskeys.map((pk) => ({
      id: isoBase64URL.toBuffer(pk.credentialID),
      type: 'public-key',
    })),
  });

  const requestId = randomId();
  registrationChallenges.set(requestId, {
    challenge: options.challenge,
    userId: user.id,
    createdAt: Date.now(),
    rpId: effectiveRpId,
    origin: originHint,
  });

  return { requestId, publicKey: options };
};

const verifyRegistration = async ({ requestId, attestationResponse, label }, userId, context = {}) => {
  const pending = registrationChallenges.get(requestId);
  if (!pending || pending.userId !== userId) {
    throw createError('PASSKEY_CHALLENGE_NOT_FOUND', 400);
  }
  registrationChallenges.delete(requestId);

  const user = getUserById(userId);

  const verification = await verifyRegistrationResponse({
    response: attestationResponse,
    expectedChallenge: pending.challenge,
    expectedOrigin: buildAllowedOrigins(pending.origin || context?.origin),
    expectedRPID: pending.rpId || resolveRpId(context?.rpId),
    requireUserVerification: true,
  });

  if (!verification.verified || !verification.registrationInfo) {
    throw createError('PASSKEY_REGISTRATION_FAILED', 400);
  }

  const {
    credentialPublicKey,
    credentialID,
    counter,
    credentialDeviceType,
    credentialBackedUp,
  } = verification.registrationInfo;

  const credentialIdB64 = isoBase64URL.fromBuffer(credentialID);
  const publicKeyB64 = isoBase64URL.fromBuffer(credentialPublicKey);

  const existingPasskeys = ensurePasskeys(user);
  if (existingPasskeys.some((pk) => pk.credentialID === credentialIdB64)) {
    throw createError('PASSKEY_ALREADY_REGISTERED', 409);
  }

  const updatedUser = userRepository.update({
    ...user,
    passkeys: [
      ...existingPasskeys,
      {
        credentialID: credentialIdB64,
        publicKey: publicKeyB64,
        counter,
        transports: attestationResponse.response?.transports || [],
        deviceType: credentialDeviceType,
        backedUp: credentialBackedUp,
        createdAt: new Date().toISOString(),
        label: typeof label === 'string' && label.trim() ? label.trim() : null,
      },
    ],
  }) || user;

  return {
    verified: true,
    user: sanitizeUser(updatedUser),
  };
};

const generateOptionsForAuthentication = async (email, context = {}) => {
  let user = null;
  if (email && email.trim()) {
    user = userRepository.findByEmail(email.trim());
    if (!user) {
      throw createError('EMAIL_NOT_FOUND', 404);
    }
    if (!ensurePasskeys(user).length) {
      throw createError('PASSKEY_NOT_REGISTERED', 404);
    }
  }

  const allowCredentials = user
    ? ensurePasskeys(user).map((pk) => ({
      id: isoBase64URL.toBuffer(pk.credentialID),
      type: 'public-key',
      transports: pk.transports,
    }))
    : [];

  const effectiveRpId = resolveRpId(context?.rpId);
  const originHint = normalizeOrigin(context?.origin);

  const options = await generateAuthenticationOptions({
    rpID: effectiveRpId,
    allowCredentials,
    userVerification: 'required',
  });

  const requestId = randomId();
  authenticationChallenges.set(requestId, {
    challenge: options.challenge,
    createdAt: Date.now(),
    rpId: effectiveRpId,
    origin: originHint,
  });

  return { requestId, publicKey: options };
};

const verifyAuthentication = async ({ requestId, assertionResponse }, context = {}) => {
  const pending = authenticationChallenges.get(requestId);
  if (!pending) {
    throw createError('PASSKEY_CHALLENGE_NOT_FOUND', 400);
  }
  authenticationChallenges.delete(requestId);

  const credentialID = assertionResponse?.id;
  if (!credentialID) {
    throw createError('PASSKEY_ID_REQUIRED', 400);
  }

  const { user, entry } = findAuthenticatorOwner(credentialID);

  const verification = await verifyAuthenticationResponse({
    response: assertionResponse,
    expectedChallenge: pending.challenge,
    expectedOrigin: buildAllowedOrigins(pending.origin || context?.origin),
    expectedRPID: pending.rpId || resolveRpId(context?.rpId),
    authenticator: toAuthenticator(entry),
    requireUserVerification: true,
  });

  if (!verification.verified || !verification.authenticationInfo) {
    throw createError('PASSKEY_AUTH_FAILED', 401);
  }

  const { newCounter, credentialDeviceType, credentialBackedUp } = verification.authenticationInfo;

  const nextPasskeys = ensurePasskeys(user).map((pk) => (
    pk.credentialID === entry.credentialID
      ? {
        ...pk,
        counter: newCounter,
        deviceType: credentialDeviceType || pk.deviceType,
        backedUp: typeof credentialBackedUp === 'boolean' ? credentialBackedUp : pk.backedUp,
        lastUsedAt: new Date().toISOString(),
      }
      : pk
  ));

  const updatedUser = userRepository.update({
    ...user,
    passkeys: nextPasskeys,
    visits: (user.visits || 1) + 1,
    lastLoginAt: new Date().toISOString(),
  }) || user;

  return {
    token: createAuthToken({ id: updatedUser.id, email: updatedUser.email }),
    user: sanitizeUser(updatedUser),
  };
};

module.exports = {
  generateOptionsForRegistration,
  verifyRegistration,
  generateOptionsForAuthentication,
  verifyAuthentication,
};
