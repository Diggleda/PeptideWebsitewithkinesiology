from __future__ import annotations

import logging
from typing import Dict, Iterable, List, Optional, Set

from ..integrations import ship_station, woo_commerce

logger = logging.getLogger(__name__)


def _normalize_sku(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    cleaned = str(value).strip()
    return cleaned or None


def _collect_skus(items: Optional[Iterable[Dict]], skus: Optional[Iterable[str]]) -> List[str]:
    unique: Set[str] = set()
    for item in items or []:
        candidate = _normalize_sku(item.get("sku") or item.get("productId"))
        if candidate:
            unique.add(candidate)
    for sku in skus or []:
        candidate = _normalize_sku(sku)
        if candidate:
            unique.add(candidate)
    return list(unique)


def _resolve_shipstation_stock(product: Dict) -> Optional[float]:
    available = product.get("available")
    on_hand = product.get("stockOnHand") or product.get("onHand")
    for value in (available, on_hand):
        try:
            if value is None:
                continue
            numeric = float(value)
            if numeric >= 0:
                return numeric
        except (TypeError, ValueError):
            continue
    return None


def sync_shipstation_inventory_to_woo(items: Optional[List[Dict]] = None, skus: Optional[List[str]] = None) -> Dict:
    sku_list = _collect_skus(items, skus)
    if not sku_list:
        return {"status": "skipped", "reason": "no_skus"}

    if not ship_station.is_configured() or not woo_commerce.is_configured():
        return {"status": "skipped", "reason": "integrations_disabled"}

    results: List[Dict] = []

    for sku in sku_list:
        try:
            ship_product = ship_station.fetch_product_by_sku(sku)
            if not ship_product:
                results.append({"sku": sku, "status": "shipstation_not_found"})
                continue

            target_stock = _resolve_shipstation_stock(ship_product)
            if target_stock is None:
                results.append({"sku": sku, "status": "shipstation_missing_stock"})
                continue

            woo_product = woo_commerce.find_product_by_sku(sku)
            if not woo_product:
                results.append({"sku": sku, "status": "woo_not_found"})
                continue

            update_result = woo_commerce.update_product_inventory(
                woo_product.get("id"),
                stock_quantity=target_stock,
                parent_id=woo_product.get("parent_id"),
                product_type=woo_product.get("type"),
            )

            results.append(
                {
                    "sku": sku,
                    "status": update_result.get("status", "updated"),
                    "stockQuantity": target_stock,
                    "wooProductId": woo_product.get("id"),
                    "shipStation": {
                        "stockOnHand": ship_product.get("stockOnHand"),
                        "available": ship_product.get("available"),
                    },
                    "wooInventory": update_result.get("response"),
                }
            )
        except ship_station.IntegrationError as exc:  # pragma: no cover - network error path
            logger.error("ShipStation inventory sync failed", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})
        except woo_commerce.IntegrationError as exc:  # pragma: no cover - network error path
            logger.error("WooCommerce inventory sync failed", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.error("Unexpected inventory sync failure", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})

    return {"status": "completed", "total": len(results), "results": results}
