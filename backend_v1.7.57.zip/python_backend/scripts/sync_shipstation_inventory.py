from __future__ import annotations

import argparse
import json
import logging
import sys

from ..config import load_config
from ..logging import configure_logging
from ..services import configure_services
from ..services import inventory_sync_service
from ..integrations import ship_station, woo_commerce

LOGGER = logging.getLogger("peppro.inventory_sync")


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync ShipStation inventory to WooCommerce by SKU.")
    parser.add_argument("skus", nargs="+", help="One or more SKU values to sync")
    args = parser.parse_args()

    config = load_config()
    configure_logging(config)
    configure_services(config)

    if not ship_station.is_configured():
        LOGGER.error("ShipStation is not configured. Set SHIPSTATION credentials before running this script.")
        sys.exit(2)

    if not woo_commerce.is_configured():
        LOGGER.error("WooCommerce is not configured. Set Woo credentials before running this script.")
        sys.exit(2)

    LOGGER.info("Syncing %s SKU(s) from ShipStation → WooCommerce", len(args.skus))
    result = inventory_sync_service.sync_shipstation_inventory_to_woo(skus=args.skus)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
