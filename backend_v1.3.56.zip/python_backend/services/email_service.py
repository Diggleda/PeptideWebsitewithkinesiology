from __future__ import annotations

import os
import smtplib
import ssl
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
import logging

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from . import get_config

logger = logging.getLogger(__name__)


def _write_dev_mail(subject: str, recipient: str, body: str) -> None:
    config = get_config()
    log_path = Path(config.data_dir) / 'mail.log'
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open('a', encoding='utf-8') as handle:
            handle.write(f"[{datetime.utcnow().isoformat()}] {subject}\nTo: {recipient or 'unknown'}\n{body}\n\n")
    except Exception:  # pragma: no cover - best effort utility
        logger.debug("Unable to write dev mail log", exc_info=True)


def _smtp_settings() -> Dict[str, Any]:
    def _to_int(value: Optional[str], fallback: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback

    settings = {
        "host": os.environ.get("SMTP_HOST") or os.environ.get("EMAIL_HOST"),
        "port": _to_int(os.environ.get("SMTP_PORT"), 587),
        "secure": str(os.environ.get("SMTP_SECURE") or "").lower() == "true",
        "user": os.environ.get("SMTP_USER") or os.environ.get("EMAIL_USER"),
        "password": os.environ.get("SMTP_PASS") or os.environ.get("EMAIL_PASS"),
        "from": os.environ.get("MAIL_FROM") or "PepPro <support@peppro.net>",
        "timeout": _to_int(os.environ.get("SMTP_TIMEOUT"), 15),
    }
    logger.info(
        "Loaded SMTP settings",
        extra={
            "host": settings["host"],
            "port": settings["port"],
            "secure": settings["secure"],
            "from": settings["from"],
            "hasUser": bool(settings["user"]),
            "timeout": settings["timeout"],
        },
    )
    return settings


def _has_smtp(settings: Dict[str, Any]) -> bool:
    return bool(settings["host"] and settings["user"] and settings["password"])


def _send_email(recipient: str, subject: str, html: str, settings: Dict[str, Any]) -> None:
    if not _has_smtp(settings):
        logger.warning("SMTP settings incomplete, falling back to dev logging")
        raise RuntimeError("SMTP settings are not configured")

    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = settings["from"]
    message["To"] = recipient
    message.attach(MIMEText(html, "html"))

    timeout = settings.get("timeout") or 15
    context = ssl.create_default_context()
    if settings["secure"]:
        logger.info(
            "Connecting to SMTP over SSL",
            extra={"host": settings["host"], "port": settings["port"]},
        )
        with smtplib.SMTP_SSL(settings["host"], settings["port"], context=context, timeout=timeout) as server:
            server.login(settings["user"], settings["password"])
            server.sendmail(settings["from"], [recipient], message.as_string())
    else:
        logger.info(
            "Connecting to SMTP with STARTTLS",
            extra={"host": settings["host"], "port": settings["port"]},
        )
        with smtplib.SMTP(settings["host"], settings["port"], timeout=timeout) as server:
            server.starttls(context=context)
            server.login(settings["user"], settings["password"])
            server.sendmail(settings["from"], [recipient], message.as_string())
    logger.info("Password reset email dispatched via SMTP", extra={"recipient": recipient})


def send_password_reset_email(recipient: str, reset_url: str) -> None:
    """
    Dispatch a password reset link. In development we log the URL locally so engineers can click it.
    """
    logger.info("Dispatching password reset email", extra={"recipient": recipient, "reset_url": reset_url})
    config = get_config()
    subject = "Password Reset Request"
    html = (
        "<p>You requested a password reset for your PepPro account.</p>"
        f"<p><a href=\"{reset_url}\">Click here to reset your password</a></p>"
        "<p>If you did not request this, you can ignore this email.</p>"
    )
    settings = _smtp_settings()

    if config.is_production:
        try:
            _send_email(recipient, subject, html, settings)
            return
        except Exception:
            logger.error("Failed to send password reset email", exc_info=True)

    _write_dev_mail(subject, recipient, f"Reset your PepPro password: {reset_url}")
    logger.info("Password reset email logged locally", extra={"recipient": recipient})


def send_template(template_name: str, context: Optional[Dict[str, Any]] = None) -> None:
    """
    Placeholder template sender used by other services. Currently logs output for local debugging.
    """
    logger.info("send_template invoked", extra={"template": template_name, "context": context})
    if not get_config().is_production:
        recipient = ""
        if isinstance(context, dict):
            recipient = str(context.get("to") or context.get("recipient") or "")
        _write_dev_mail(f"Template: {template_name}", recipient, f"Context: {context}")
