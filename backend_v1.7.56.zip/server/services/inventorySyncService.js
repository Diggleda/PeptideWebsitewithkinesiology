const shipStationClient = require('../integration/shipStationClient');
const wooCommerceClient = require('../integration/wooCommerceClient');
const { logger } = require('../config/logger');
const { env } = require('../config/env');

const normalizeSku = (value) => {
  if (!value) {
    return null;
  }
  return String(value).trim();
};

const PRODUCT_PAGE_SIZE = 200;
const MAX_PRODUCT_PAGES = 25;
const DEFAULT_BACKGROUND_INTERVAL_MS = 5_000;
let inventorySyncTimer = null;
let inventorySyncRunning = false;

const collectSkus = (items = [], extraSkus = []) => {
  const unique = new Set();
  (items || []).forEach((item) => {
    const normalized = normalizeSku(item?.sku || item?.productId);
    if (normalized) {
      unique.add(normalized);
    }
  });
  (extraSkus || []).forEach((sku) => {
    const normalized = normalizeSku(sku);
    if (normalized) {
      unique.add(normalized);
    }
  });
  return Array.from(unique);
};

const syncShipStationInventoryToWoo = async (items = [], options = {}) => {
  const skus = collectSkus(items, options?.skus);

  if (skus.length === 0) {
    return {
      status: 'skipped',
      reason: 'no_skus',
    };
  }
  if (!shipStationClient.isConfigured() || !wooCommerceClient.isConfigured()) {
    return {
      status: 'skipped',
      reason: 'integrations_disabled',
    };
  }

  const results = [];

  for (const sku of skus) {
    try {
      const shipStationProduct = await shipStationClient.fetchProductBySku(sku);
      if (!shipStationProduct) {
        results.push({ sku, status: 'shipstation_not_found' });
        continue;
      }

      const resolvedStock = Number.isFinite(shipStationProduct.stockOnHand)
        ? shipStationProduct.stockOnHand
        : shipStationProduct.available;

      const wooProduct = await wooCommerceClient.findProductBySku(sku);
      if (!wooProduct?.id) {
        results.push({ sku, status: 'woo_not_found' });
        continue;
      }

      const inventoryResult = await wooCommerceClient.updateProductInventory(wooProduct.id, {
        stock_quantity: resolvedStock,
        parent_id: wooProduct.parent_id || null,
        type: wooProduct.type || null,
      });

      results.push({
        sku,
        status: 'updated',
        stockQuantity: resolvedStock,
        wooProductId: wooProduct.id,
        shipStation: {
          stockOnHand: shipStationProduct.stockOnHand,
          available: shipStationProduct.available,
        },
        wooInventory: {
          stock_quantity: inventoryResult?.response?.stock_quantity ?? null,
        },
      });
    } catch (error) {
      logger.error({ err: error, sku }, 'Inventory sync failed for SKU');
      results.push({
        sku,
        status: 'error',
        message: error.message,
      });
    }
  }

  return {
    status: 'completed',
    total: results.length,
    results,
  };
};

const fetchShipStationSkus = async () => {
  if (!shipStationClient.isConfigured()) {
    return [];
  }
  const skus = new Set();
  let page = 1;
  while (page <= MAX_PRODUCT_PAGES) {
    // eslint-disable-next-line no-await-in-loop
    const response = await shipStationClient.listProducts({
      page,
      pageSize: PRODUCT_PAGE_SIZE,
    });
    const products = Array.isArray(response?.products) ? response.products : [];
    if (products.length === 0) {
      break;
    }
    products.forEach((product) => {
      const normalized = normalizeSku(product?.sku);
      if (normalized) {
        skus.add(normalized);
      }
    });
    if (response?.pages && page >= Number(response.pages)) {
      break;
    }
    page += 1;
  }
  return Array.from(skus);
};

const syncAllShipStationInventory = async () => {
  const skus = await fetchShipStationSkus();
  if (!skus.length) {
    return {
      status: 'skipped',
      reason: 'no_shipstation_products',
    };
  }
  return syncShipStationInventoryToWoo([], { skus });
};

const startBackgroundInventorySync = () => {
  if (inventorySyncTimer) {
    return;
  }
  if (!shipStationClient.isConfigured() || !wooCommerceClient.isConfigured()) {
    logger.warn('Background inventory sync disabled; ShipStation or WooCommerce is not configured');
    return;
  }
  const intervalMs = Math.max(env.inventorySync?.intervalMs || DEFAULT_BACKGROUND_INTERVAL_MS, 1_000);
  const runner = async () => {
    if (inventorySyncRunning) {
      logger.warn('Previous inventory sync still running; skipping tick');
      return;
    }
    inventorySyncRunning = true;
    try {
      const result = await syncAllShipStationInventory();
      logger.debug(
        {
          status: result?.status,
          total: result?.total ?? 0,
        },
        'Background inventory sync tick completed',
      );
    } catch (error) {
      logger.error({ err: error }, 'Background inventory sync failed');
    } finally {
      inventorySyncRunning = false;
    }
  };
  runner();
  inventorySyncTimer = setInterval(runner, intervalMs);
  logger.info({ intervalMs }, 'Background inventory sync scheduled');
};

module.exports = {
  syncShipStationInventoryToWoo,
  syncAllShipStationInventory,
  startBackgroundInventorySync,
};
