from __future__ import annotations

import logging
import threading
from typing import Dict, Iterable, List, Optional, Set

from ..integrations import ship_station, woo_commerce

logger = logging.getLogger(__name__)
PRODUCT_PAGE_SIZE = 200
MAX_PRODUCT_PAGES = 25
_background_thread: Optional[threading.Thread] = None
_background_stop = threading.Event()


def _normalize_sku(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    cleaned = str(value).strip()
    return cleaned or None


def _collect_skus(items: Optional[Iterable[Dict]], skus: Optional[Iterable[str]]) -> List[str]:
    unique: Set[str] = set()
    for item in items or []:
        candidate = _normalize_sku(item.get("sku") or item.get("productId"))
        if candidate:
            unique.add(candidate)
    for sku in skus or []:
        candidate = _normalize_sku(sku)
        if candidate:
            unique.add(candidate)
    return list(unique)


def _resolve_shipstation_stock(product: Dict) -> Optional[float]:
    available = product.get("available")
    on_hand = product.get("stockOnHand") or product.get("onHand")
    for value in (available, on_hand):
        try:
            if value is None:
                continue
            numeric = float(value)
            if numeric >= 0:
                return numeric
        except (TypeError, ValueError):
            continue
    return None


def _fetch_shipstation_skus() -> List[str]:
    if not ship_station.is_configured():
        return []
    skus: Set[str] = set()
    page = 1
    while page <= MAX_PRODUCT_PAGES:
        page_data = ship_station.list_products(page=page, page_size=PRODUCT_PAGE_SIZE)
        products = page_data.get("products") if isinstance(page_data, dict) else []
        if not products:
            break
        for product in products:
            sku = _normalize_sku(product.get("sku"))
            if sku:
                skus.add(sku)
        pages = page_data.get("pages")
        if pages and page >= int(pages):
            break
        page += 1
    return list(skus)


def sync_shipstation_inventory_to_woo(items: Optional[List[Dict]] = None, skus: Optional[List[str]] = None) -> Dict:
    sku_list = _collect_skus(items, skus)
    if not sku_list:
        return {"status": "skipped", "reason": "no_skus"}

    if not ship_station.is_configured() or not woo_commerce.is_configured():
        return {"status": "skipped", "reason": "integrations_disabled"}

    results: List[Dict] = []

    for sku in sku_list:
        try:
            ship_product = ship_station.fetch_product_by_sku(sku)
            if not ship_product:
                results.append({"sku": sku, "status": "shipstation_not_found"})
                continue

            target_stock = _resolve_shipstation_stock(ship_product)
            if target_stock is None:
                results.append({"sku": sku, "status": "shipstation_missing_stock"})
                continue

            woo_product = woo_commerce.find_product_by_sku(sku)
            if not woo_product:
                results.append({"sku": sku, "status": "woo_not_found"})
                continue

            update_result = woo_commerce.update_product_inventory(
                woo_product.get("id"),
                stock_quantity=target_stock,
                parent_id=woo_product.get("parent_id"),
                product_type=woo_product.get("type"),
            )

            results.append(
                {
                    "sku": sku,
                    "status": update_result.get("status", "updated"),
                    "stockQuantity": target_stock,
                    "wooProductId": woo_product.get("id"),
                    "shipStation": {
                        "stockOnHand": ship_product.get("stockOnHand"),
                        "available": ship_product.get("available"),
                    },
                    "wooInventory": update_result.get("response"),
                }
            )
        except ship_station.IntegrationError as exc:  # pragma: no cover - network error path
            logger.error("ShipStation inventory sync failed", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})
        except woo_commerce.IntegrationError as exc:  # pragma: no cover - network error path
            logger.error("WooCommerce inventory sync failed", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.error("Unexpected inventory sync failure", exc_info=True, extra={"sku": sku})
            results.append({"sku": sku, "status": "error", "message": str(exc)})

    return {"status": "completed", "total": len(results), "results": results}


def sync_all_shipstation_inventory() -> Dict:
    sku_list = _fetch_shipstation_skus()
    if not sku_list:
        return {"status": "skipped", "reason": "no_shipstation_products"}
    return sync_shipstation_inventory_to_woo(skus=sku_list)


def start_background_inventory_sync(interval_seconds: int = 5) -> None:
    if interval_seconds <= 0:
        logger.info("Inventory sync disabled; non-positive interval provided")
        return
    if not ship_station.is_configured() or not woo_commerce.is_configured():
        logger.info("Inventory sync disabled; ShipStation or WooCommerce is not configured")
        return
    global _background_thread
    if _background_thread and _background_thread.is_alive():
        return

    def _worker() -> None:
        logger.info("Background inventory sync started", extra={"intervalSeconds": interval_seconds})
        while not _background_stop.is_set():
            try:
                sync_all_shipstation_inventory()
            except Exception:  # pragma: no cover - defensive logging
                logger.exception("Background inventory sync tick failed")
            if _background_stop.wait(interval_seconds):
                break
        logger.info("Background inventory sync stopped")

    _background_stop.clear()
    _background_thread = threading.Thread(target=_worker, name="inventory-sync", daemon=True)
    _background_thread.start()
