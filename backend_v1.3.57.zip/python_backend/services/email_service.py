from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
import logging

import requests

from . import get_config

logger = logging.getLogger(__name__)

SENDGRID_ENDPOINT = "https://api.sendgrid.com/v3/mail/send"


def _write_dev_mail(subject: str, recipient: str, body: str) -> None:
    config = get_config()
    log_path = Path(config.data_dir) / 'mail.log'
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open('a', encoding='utf-8') as handle:
            handle.write(f"[{datetime.utcnow().isoformat()}] {subject}\nTo: {recipient or 'unknown'}\n{body}\n\n")
    except Exception:  # pragma: no cover - best effort utility
        logger.debug("Unable to write dev mail log", exc_info=True)


def _email_settings() -> Dict[str, Any]:
    def _to_int(value: Optional[str], fallback: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback

    api_key = (
        os.environ.get("SENDGRID_API_KEY")
        or os.environ.get("SENDGRID_API_TOKEN")
        or os.environ.get("SMTP_PASS")
        or os.environ.get("EMAIL_PASS")
    )
    settings = {
        "from": os.environ.get("MAIL_FROM") or "PepPro <support@peppro.net>",
        "timeout": _to_int(os.environ.get("SENDGRID_TIMEOUT") or os.environ.get("SMTP_TIMEOUT"), 15),
        "api_key": api_key,
        "endpoint": os.environ.get("SENDGRID_API_URL") or SENDGRID_ENDPOINT,
    }
    logger.info(
        "Loaded email settings",
        extra={"from": settings["from"], "hasSendGridKey": bool(settings["api_key"]), "endpoint": settings["endpoint"]},
    )
    return settings


def _format_from_address(raw: str) -> Dict[str, str]:
    parts = raw.split("<")
    if len(parts) == 2 and ">" in parts[1]:
        name = parts[0].strip().strip('"').strip()
        email = parts[1].split(">", 1)[0].strip()
        formatted = {"email": email}
        if name:
            formatted["name"] = name
        return formatted
    return {"email": raw.strip()}


def _send_via_sendgrid(recipient: str, subject: str, html: str, settings: Dict[str, Any]) -> None:
    api_key = settings.get("api_key")
    if not api_key:
        logger.warning("SendGrid API key missing, falling back to dev logging")
        raise RuntimeError("SendGrid API key is not configured")

    payload = {
        "personalizations": [
            {
                "to": [{"email": recipient}],
                "subject": subject,
            }
        ],
        "from": _format_from_address(settings["from"]),
        "content": [
            {"type": "text/plain", "value": html.replace("<p>", "").replace("</p>", "\n")},
            {"type": "text/html", "value": html},
        ],
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    timeout = settings.get("timeout") or 15
    response = requests.post(settings["endpoint"], json=payload, headers=headers, timeout=timeout)
    if response.status_code >= 400:
        logger.error(
            "SendGrid API call failed",
            extra={"status": response.status_code, "body": response.text[:512]},
        )
        response.raise_for_status()
    logger.info("Password reset email dispatched via SendGrid", extra={"recipient": recipient})


def send_password_reset_email(recipient: str, reset_url: str) -> None:
    """
    Dispatch a password reset link. In development we log the URL locally so engineers can click it.
    """
    logger.info("Dispatching password reset email", extra={"recipient": recipient, "reset_url": reset_url})
    config = get_config()
    subject = "Password Reset Request"
    html = (
        "<p>You requested a password reset for your PepPro account.</p>"
        f"<p><a href=\"{reset_url}\">Click here to reset your password</a></p>"
        "<p>If you did not request this, you can ignore this email.</p>"
    )
    settings = _email_settings()

    if config.is_production:
        try:
            _send_via_sendgrid(recipient, subject, html, settings)
            return
        except Exception:
            logger.error("Failed to send password reset email", exc_info=True)

    _write_dev_mail(subject, recipient, f"Reset your PepPro password: {reset_url}")
    logger.info("Password reset email logged locally", extra={"recipient": recipient})


def send_template(template_name: str, context: Optional[Dict[str, Any]] = None) -> None:
    """
    Placeholder template sender used by other services. Currently logs output for local debugging.
    """
    logger.info("send_template invoked", extra={"template": template_name, "context": context})
    if not get_config().is_production:
        recipient = ""
        if isinstance(context, dict):
            recipient = str(context.get("to") or context.get("recipient") or "")
        _write_dev_mail(f"Template: {template_name}", recipient, f"Context: {context}")
