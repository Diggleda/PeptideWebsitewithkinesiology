from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import logging

import requests

from . import get_config

logger = logging.getLogger(__name__)

SENDGRID_ENDPOINT = "https://api.sendgrid.com/v3/mail/send"


def _write_dev_mail(subject: str, recipient: str, body: str) -> None:
    config = get_config()
    log_path = Path(config.data_dir) / 'mail.log'
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open('a', encoding='utf-8') as handle:
            handle.write(f"[{datetime.utcnow().isoformat()}] {subject}\nTo: {recipient or 'unknown'}\n{body}\n\n")
    except Exception:  # pragma: no cover - best effort utility
        logger.debug("Unable to write dev mail log", exc_info=True)


def _email_settings() -> Dict[str, Any]:
    def _to_int(value: Optional[str], fallback: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return fallback

    api_key = (
        os.environ.get("SENDGRID_API_KEY")
        or os.environ.get("SENDGRID_API_TOKEN")
        or os.environ.get("SMTP_PASS")
        or os.environ.get("EMAIL_PASS")
    )
    settings = {
        "from": os.environ.get("MAIL_FROM") or "PepPro <support@peppro.net>",
        "timeout": _to_int(os.environ.get("SENDGRID_TIMEOUT") or os.environ.get("SMTP_TIMEOUT"), 15),
        "api_key": api_key,
        "endpoint": os.environ.get("SENDGRID_API_URL") or SENDGRID_ENDPOINT,
    }
    logger.info(
        "Loaded email settings",
        extra={"from": settings["from"], "hasSendGridKey": bool(settings["api_key"]), "endpoint": settings["endpoint"]},
    )
    return settings


def _format_from_address(raw: str) -> Dict[str, str]:
    parts = raw.split("<")
    if len(parts) == 2 and ">" in parts[1]:
        name = parts[0].strip().strip('"').strip()
        email = parts[1].split(">", 1)[0].strip()
        formatted = {"email": email}
        if name:
            formatted["name"] = name
        return formatted
    return {"email": raw.strip()}


def _send_via_sendgrid(
    recipient: str,
    subject: str,
    html: str,
    settings: Dict[str, Any],
    plain_text: Optional[str] = None,
) -> None:
    api_key = settings.get("api_key")
    if not api_key:
        logger.warning("SendGrid API key missing, falling back to dev logging")
        raise RuntimeError("SendGrid API key is not configured")

    content_blocks = []
    if plain_text:
        content_blocks.append({"type": "text/plain", "value": plain_text})
    else:
        content_blocks.append({"type": "text/plain", "value": html.replace("<p>", "").replace("</p>", "\n")})
    content_blocks.append({"type": "text/html", "value": html})

    payload = {
        "personalizations": [
            {
                "to": [{"email": recipient}],
                "subject": subject,
            }
        ],
        "from": _format_from_address(settings["from"]),
        "content": content_blocks,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    timeout = settings.get("timeout") or 15
    response = requests.post(settings["endpoint"], json=payload, headers=headers, timeout=timeout)
    if response.status_code >= 400:
        logger.error(
            "SendGrid API call failed",
            extra={"status": response.status_code, "body": response.text[:512]},
        )
        response.raise_for_status()
    logger.info("Password reset email dispatched via SendGrid", extra={"recipient": recipient})


def _build_password_reset_email(reset_url: str, base_url: str) -> Tuple[str, str]:
    logo_url = f"{base_url.rstrip('/')}/Peppro_fulllogo.png"
    html = f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>PepPro Password Reset</title>
  </head>
  <body style="margin:0;padding:0;background-color:#f5f6f8;font-family:Arial,Helvetica,sans-serif;color:#111827;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f5f6f8;padding:32px 0;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background-color:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,0.08);">
            <tr>
              <td style="background-color:#0b274b;padding:24px;" align="center">
                <img src="{logo_url}" alt="PepPro" style="max-width:180px;width:100%;height:auto;display:block;" />
              </td>
            </tr>
            <tr>
              <td style="padding:32px 28px 8px;">
                <h1 style="margin:0 0 16px;font-size:22px;font-weight:700;color:#0b274b;">Reset your PepPro password</h1>
                <p style="margin:0 0 12px;line-height:1.6;">
                  We received a request to reset your account password. Click the button below to choose a new password.
                </p>
                <p style="margin:0 0 24px;line-height:1.6;">
                  If you did not request this, you can safely ignore this email—your password will remain unchanged.
                </p>
                <p style="margin:0 0 32px;text-align:center;">
                  <a href="{reset_url}" style="display:inline-block;padding:14px 28px;background-color:#1d4ed8;color:#ffffff;font-weight:600;border-radius:999px;text-decoration:none;">Reset Password</a>
                </p>
                <p style="margin:0 0 8px;font-size:14px;line-height:1.5;color:#6b7280;">
                  Or copy and paste this link into your browser:
                </p>
                <p style="margin:0;font-size:14px;line-height:1.5;color:#1d4ed8;word-break:break-all;">
                  {reset_url}
                </p>
              </td>
            </tr>
            <tr>
              <td style="padding:24px 28px 32px;font-size:12px;color:#6b7280;line-height:1.5;">
                <p style="margin:0 0 4px;">Need help? Contact PepPro support at <a href="mailto:support@peppro.net" style="color:#1d4ed8;text-decoration:none;">support@peppro.net</a>.</p>
                <p style="margin:0;">This link will expire in 60 minutes to keep your account secure.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>"""
    plain = (
        "You requested a password reset for your PepPro account.\n"
        f"Reset your password using this link: {reset_url}\n"
        "If you did not request this, you can ignore this email.\n"
        "Need help? Contact support@peppro.net."
    )
    return html, plain


def send_password_reset_email(recipient: str, reset_url: str) -> None:
    """
    Dispatch a password reset link. In development we log the URL locally so engineers can click it.
    """
    logger.info("Dispatching password reset email", extra={"recipient": recipient, "reset_url": reset_url})
    config = get_config()
    subject = "Password Reset Request"
    base_url = (config.frontend_base_url or "http://localhost:3000").rstrip("/")
    html, plain_text = _build_password_reset_email(reset_url, base_url)
    settings = _email_settings()

    if config.is_production:
        try:
            _send_via_sendgrid(recipient, subject, html, settings, plain_text=plain_text)
            return
        except Exception:
            logger.error("Failed to send password reset email", exc_info=True)

    _write_dev_mail(subject, recipient, plain_text)
    logger.info("Password reset email logged locally", extra={"recipient": recipient})


def send_template(template_name: str, context: Optional[Dict[str, Any]] = None) -> None:
    """
    Placeholder template sender used by other services. Currently logs output for local debugging.
    """
    logger.info("send_template invoked", extra={"template": template_name, "context": context})
    if not get_config().is_production:
        recipient = ""
        if isinstance(context, dict):
            recipient = str(context.get("to") or context.get("recipient") or "")
        _write_dev_mail(f"Template: {template_name}", recipient, f"Context: {context}")
