from __future__ import annotations

from flask import Blueprint

from ..services import get_config
from ..services import news_service
from ..integrations import ship_engine, woo_commerce
from ..utils.http import handle_action

blueprint = Blueprint("system", __name__, url_prefix="/api")


@blueprint.get("/health")
def health():
    def action():
        config = get_config()
        return {
            "status": "ok",
            "message": "Server is running",
            "build": config.backend_build,
            "timestamp": _now(),
        }

    return handle_action(action)


@blueprint.get("/help")
def help_endpoint():
    def action():
        config = get_config()
        return {
            "ok": True,
            "service": "Protixa Backend",
            "build": config.backend_build,
            "note": "Backend build 2025-11-11",
            "integrations": {
                "wooCommerce": {"configured": woo_commerce.is_configured()},
                "shipEngine": {"configured": ship_engine.is_configured()},
            },
            "endpoints": [
                "/api/auth/login",
                "/api/auth/register",
                "/api/auth/me",
                "/api/auth/check-email",
                "/api/auth/passkeys/login/options",
                "/api/auth/passkeys/login/verify",
                "/api/auth/passkeys/register/options",
                "/api/auth/passkeys/register/verify",
                "/api/orders",
                "/api/woo/products",
                "/api/woo/products/categories",
                "/api/referrals/doctor/summary",
                "/api/referrals/admin/dashboard",
                "/api/integrations/google-sheets/sales-reps",
                "/api/help",
                "/api/help/config",
                "/api/news/peptides",
                "/api/health",
            ],
            "timestamp": _now(),
        }

    return handle_action(action)


@blueprint.get("/help/config")
def help_config():
    def action():
        config = get_config()
        passkeys_cfg = config.passkeys or {}
        return {
            "ok": True,
            "build": config.backend_build,
            "cors": {
                "allowList": config.cors_allow_list,
            },
            "passkeys": {
                "rpId": passkeys_cfg.get("rp_id") or None,
                "rpName": passkeys_cfg.get("rp_name") or None,
                "allowedOrigins": passkeys_cfg.get("allowed_origins") or [],
            },
            "timestamp": _now(),
        }

    return handle_action(action)


def _now():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


@blueprint.get("/news/peptides")
def peptide_news():
    def action():
        items = news_service.fetch_peptide_news(limit=8)
        return {
            "items": [
                {
                    "title": item.title,
                    "url": item.url,
                    "summary": item.summary,
                    "imageUrl": item.image_url,
                    "date": item.date,
                }
                for item in items
            ],
            "count": len(items),
        }

    return handle_action(action)
