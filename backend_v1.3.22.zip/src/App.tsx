import { useState, useMemo, useEffect, useRef, useCallback, FormEvent, ReactNode } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Header } from './components/Header';
import { FeaturedSection } from './components/FeaturedSection';
import { ProductCard } from './components/ProductCard';
import type { Product as CardProduct } from './components/ProductCard';
import type { Product, ProductVariant, BulkPricingTier } from './types/product';
import { loadLocalProductForCard } from './lib/localWooFixture';
import { CategoryFilter } from './components/CategoryFilter';
import { CheckoutModal } from './components/CheckoutModal';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { toast } from 'sonner@2.0.3';
import { Grid, List, ShoppingCart, Eye, EyeOff, ArrowRight, ArrowLeft, ChevronRight, RefreshCw, ArrowUpDown, Fingerprint, Loader2 } from 'lucide-react';
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Bar } from 'recharts@2.15.2';
import { authAPI, ordersAPI, referralAPI, newsAPI, quotesAPI, checkServerHealth } from './services/api';
import { ProductDetailDialog } from './components/ProductDetailDialog';
import { LegalFooter } from './components/LegalFooter';
import { AuthActionResult } from './types/auth';
import { DoctorCreditSummary, ReferralRecord, SalesRepDashboard } from './types/referral';
import { listProducts, listCategories, listProductVariations } from './lib/wooClient';
import { beginPasskeyAuthentication, beginPasskeyRegistration, detectConditionalPasskeySupport, detectPlatformPasskeySupport } from './lib/passkeys';
import { requestStoredPasswordCredential, storePasswordCredential } from './lib/passwordCredential';

interface User {
  id: string;
  name: string;
  email: string;
  hasPasskeys?: boolean;
  referralCode?: string | null;
  npiNumber?: string | null;
  npiLastVerifiedAt?: string | null;
  npiVerification?: {
    name?: string | null;
    credential?: string | null;
    enumerationType?: string | null;
    primaryTaxonomy?: string | null;
    organizationName?: string | null;
  } | null;
  role: 'doctor' | 'sales_rep' | string;
  salesRepId?: string | null;
  salesRep?: {
    id: string;
    name?: string | null;
    email?: string | null;
    phone?: string | null;
  } | null;
  referrerDoctorId?: string | null;
  phone?: string | null;
  officeAddressLine1?: string | null;
  officeAddressLine2?: string | null;
  officeCity?: string | null;
  officeState?: string | null;
  officePostalCode?: string | null;
  referralCredits?: number;
  totalReferrals?: number;
  mustResetPassword?: boolean;
}

// Feature flags for passkey UX. Defaults keep prompts manual-only.
const PASSKEY_AUTOPROMPT = String((import.meta as any).env?.VITE_PASSKEY_AUTOPROMPT || '').toLowerCase() === 'true';
const PASSKEY_AUTOREGISTER = String((import.meta as any).env?.VITE_PASSKEY_AUTOREGISTER || '').toLowerCase() === 'true';

interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  note?: string;
  variant?: ProductVariant | null;
}

interface FilterState {
  categories: string[];
  types: string[];
  inStockOnly: boolean;
}

type WooImage = { src?: string | null };
type WooCategory = { id: number; name: string };
type WooMeta = { key?: string | null; value?: unknown };
type WooAttribute = { id?: number; name?: string | null; option?: string | null };
type WooVariationAttribute = { id?: number; name?: string | null; option?: string | null };

interface WooVariation {
  id: number;
  price?: string;
  regular_price?: string;
  stock_status?: string;
  image?: WooImage | null;
  attributes?: WooVariationAttribute[];
  description?: string | null;
  sku?: string | null;
  meta_data?: WooMeta[];
  tiered_pricing_fixed_rules?: Record<string, unknown> | null;
}

interface WooProduct {
  id: number;
  name: string;
  price?: string;
  regular_price?: string;
  price_html?: string;
  images?: WooImage[];
  categories?: WooCategory[];
  stock_status?: string;
  average_rating?: string;
  rating_count?: number;
  sku?: string;
  type?: string;
  short_description?: string;
  description?: string;
  meta_data?: WooMeta[];
  attributes?: WooAttribute[];
  default_attributes?: WooVariationAttribute[];
  variations?: number[];
}

interface PeptideNewsItem {
  title: string;
  url: string;
  summary?: string;
  image?: string;
  date?: string;
}

interface AccountOrderLineItem {
  id?: string | null;
  name?: string | null;
  quantity?: number | null;
  total?: number | null;
  price?: number | null;
}

interface AccountOrderSummary {
  id: string;
  number?: string | null;
  status?: string | null;
  currency?: string | null;
  total?: number | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  source: 'local' | 'woocommerce';
  lineItems?: AccountOrderLineItem[];
  integrations?: Record<string, string | null> | null;
  paymentMethod?: string | null;
  integrationDetails?: Record<string, any> | null;
}

const WOO_PLACEHOLDER_IMAGE =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%2395C5F9'/%3E%3Cstop offset='100%25' stop-color='%235FB3F9'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='400' height='400' fill='url(%23g)'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-family='Arial' font-size='28' fill='rgba(255,255,255,0.75)'%3EWoo Product%3C/text%3E%3C/svg%3E";

const coerceNumber = (value: unknown): number | undefined => {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
};

const toOrderLineItems = (items: any): AccountOrderLineItem[] => {
  if (!Array.isArray(items)) {
    return [];
  }
  return items
    .map((item) => {
      const quantity = coerceNumber(item?.quantity);
      const price = coerceNumber(item?.price);
      const total = coerceNumber(item?.total) ?? (price && quantity ? price * quantity : undefined);
      return {
        id: item?.id ? String(item.id) : undefined,
        name: typeof item?.name === 'string' ? item.name : null,
        quantity: quantity ?? null,
        total: total ?? null,
        price: price ?? null,
      };
    })
    .filter((line) => line.name);
};

const normalizeAccountOrdersResponse = (payload: any): AccountOrderSummary[] => {
  const result: AccountOrderSummary[] = [];
  if (payload && Array.isArray(payload.woo)) {
    payload.woo.forEach((order: any) => {
      const identifier = order?.id
        ? String(order.id)
        : order?.number
          ? `woo-${order.number}`
          : `woo-${Math.random().toString(36).slice(2, 10)}`;
      result.push({
        id: identifier,
        number: order?.number || identifier,
        status: order?.status || 'pending',
        currency: order?.currency || 'USD',
        total: coerceNumber(order?.total) ?? null,
        createdAt: order?.createdAt || order?.dateCreated || order?.date_created || null,
        updatedAt: order?.updatedAt || order?.dateModified || order?.date_modified || null,
        source: 'woocommerce',
        lineItems: toOrderLineItems(order?.lineItems),
        integrations: order?.integrations || null,
        paymentMethod: order?.paymentMethod || null,
        integrationDetails: order?.integrationDetails || null,
      });
    });
  }

  return result.sort((a, b) => {
    const tsA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const tsB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return tsB - tsA;
  });
};

const normalizeHumanName = (value: string) =>
  (value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const HONORIFIC_TOKENS = new Set(['mr', 'mrs', 'ms', 'mx', 'dr', 'prof', 'sir', 'madam']);
const SUFFIX_TOKENS = new Set(['jr', 'sr', 'ii', 'iii', 'iv', 'v']);

const tokenizeName = (value: string) =>
  normalizeHumanName(value)
    .split(' ')
    .map((token) => token.replace(/[.,]/g, ''))
    .filter(
      (token) =>
        token &&
        !HONORIFIC_TOKENS.has(token) &&
        !SUFFIX_TOKENS.has(token),
    );

const namesRoughlyMatch = (a: string, b: string) => {
  const tokensA = tokenizeName(a);
  const tokensB = tokenizeName(b);
  if (!tokensA.length || !tokensB.length) {
    return false;
  }
  if (tokensA.join(' ') === tokensB.join(' ')) {
    return true;
  }
  const firstA = tokensA[0];
  const lastA = tokensA[tokensA.length - 1];
  const firstB = tokensB[0];
  const lastB = tokensB[tokensB.length - 1];
  if (!firstA || !lastA || !firstB || !lastB) {
    return false;
  }
  if (firstA !== firstB || lastA !== lastB) {
    return false;
  }
  const middleA = tokensA.slice(1, -1).join(' ');
  const middleB = tokensB.slice(1, -1).join(' ');
  if (!middleA || !middleB) {
    return true;
  }
  return middleA === middleB;
};

const PEPTIDE_NEWS_PLACEHOLDER_IMAGE =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0%25' stop-color='%23B7D8F9'/%3E%3Cstop offset='100%25' stop-color='%2395C5F9'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='120' height='120' rx='16' fill='url(%23grad)'/%3E%3Cpath d='M35 80l15-18 12 14 11-12 12 16' stroke='%23ffffff' stroke-width='5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3Ccircle cx='44' cy='43' r='9' fill='none' stroke='%23ffffff' stroke-width='5'/%3E%3C/svg%3E";

const MIN_NEWS_LOADING_MS = 600;
const LOGIN_KEEPALIVE_INTERVAL_MS = 60000;

const SALES_REP_STATUS_ORDER = [
  'pending',
  'contacted',
  'follow_up',
  'code_issued',
  'converted',
  'closed',
  'not_interested',
  'disqualified',
  'rejected',
  'in_review',
];

const humanizeReferralStatus = (status?: string) => {
  if (!status) {
    return 'Unknown';
  }
  return status
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

const stripHtml = (value?: string | null): string =>
  value ? value.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : '';

const formatNewsDate = (dateString?: string | null): string => {
  if (!dateString) return '';
  const raw = dateString.trim();
  try {
    // Try generic Date parsing (covers RFC-2822 like: Mon, 27 Oct 2025 00:00:00 +0000)
    const dt = new Date(raw);
    if (!Number.isNaN(dt.getTime())) {
      dt.setDate(dt.getDate() + 1);
      return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    // Parse ISO date string (YYYY-MM-DD)
    const parts = raw.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1; // Month is 0-indexed
      const day = parseInt(parts[2], 10);
      const date = new Date(year, month, day);
      if (!Number.isNaN(date.getTime())) {
        date.setDate(date.getDate() + 1);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      }
    }

    // Fallback: strip time segment if present and keep day+month+year
    const rfc = raw.match(/^([A-Za-z]{3},?\s+\d{1,2}\s+[A-Za-z]{3}\s+\d{4})/);
    if (rfc) return rfc[1];

    const tIndex = raw.indexOf('T');
    if (tIndex > 0) {
      const ymd = raw.slice(0, tIndex);
      const ymdParts = ymd.split('-');
      if (ymdParts.length === 3) {
        const y = parseInt(ymdParts[0], 10);
        const m = parseInt(ymdParts[1], 10) - 1;
        const d = parseInt(ymdParts[2], 10);
        const d2 = new Date(y, m, d);
        if (!Number.isNaN(d2.getTime())) {
          d2.setDate(d2.getDate() + 1);
          return d2.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        }
      }
    }

    return raw;
  } catch {
    return raw;
  }
};

const describeNpiErrorMessage = (code?: string): string => {
  const normalized = (code || '').toUpperCase().trim();
  switch (normalized) {
    case 'NPI_INVALID':
      return 'Please enter a valid 10-digit NPI number.';
    case 'NPI_NOT_FOUND':
      return 'We could not verify that NPI in the CMS registry. Double-check the digits and try again.';
    case 'NPI_ALREADY_REGISTERED':
      return 'An account already exists for this NPI number.';
    case 'NPI_LOOKUP_FAILED':
      return 'We could not reach the CMS registry. Please try again in a moment.';
    default:
      return 'Unable to verify this NPI number. Please confirm it is correct.';
  }
};

const BULK_META_KEYS = [
  'bulk_pricing_tiers',
  'bulk_pricing',
  '_bulk_pricing_tiers',
  'quantity_discounts',
  'quantity_discount',
];

const normalizeBulkTier = (min: unknown, discount: unknown): BulkPricingTier | null => {
  const minQuantity = Number(min);
  const discountPct = Number(discount);
  if (!Number.isFinite(minQuantity) || !Number.isFinite(discountPct)) {
    return null;
  }
  if (minQuantity <= 0) {
    return null;
  }
  return {
    minQuantity: Math.max(1, Math.floor(minQuantity)),
    discountPercentage: Math.max(0, Math.min(100, Number(discountPct))),
  };
};

const parseBulkPricingValue = (value: unknown): BulkPricingTier[] => {
  if (value === null || value === undefined) {
    return [];
  }

  if (Array.isArray(value)) {
    return value
      .map((entry) => {
        if (typeof entry === 'object' && entry !== null) {
          const maybe = entry as Record<string, unknown>;
          return (
            normalizeBulkTier(
              maybe.minQuantity ?? maybe.min ?? maybe.quantity ?? maybe.qty,
              maybe.discountPercentage ?? maybe.discount ?? maybe.percent ?? maybe.percentage,
            )
          );
        }
        if (typeof entry === 'string') {
          const match = entry.match(/(\d+(?:\.\d+)?)\s*[:=,-]\s*(\d+(?:\.\d+)?)/);
          if (match) {
            return normalizeBulkTier(match[1], match[2]);
          }
        }
        return null;
      })
      .filter((tier): tier is BulkPricingTier => Boolean(tier));
  }

  if (typeof value === 'object') {
    const record = value as Record<string, unknown>;
    return Object.entries(record)
      .map(([key, discount]) => normalizeBulkTier(key, discount))
      .filter((tier): tier is BulkPricingTier => Boolean(tier));
  }

  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return parseBulkPricingValue(parsed);
    } catch {
      return value
        .split(/[\n,;]/)
        .map((token) => token.trim())
        .filter(Boolean)
        .map((token) => {
          const parts = token.split(/[:=|-]/).map((part) => part.trim());
          if (parts.length >= 2) {
            return normalizeBulkTier(parts[0].replace(/[^\d.]/g, ''), parts[1].replace(/[^\d.]/g, ''));
          }
          return null;
        })
        .filter((tier): tier is BulkPricingTier => Boolean(tier));
    }
  }

  return [];
};

const toNumeric = (value: unknown): number | null => {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  if (typeof value === 'string') {
    const parsed = Number(value.replace(/[^\d.\-]/g, ''));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
};

const normalizeFixedRule = (min: unknown, unitPrice: unknown, basePrice: number): BulkPricingTier | null => {
  const minQuantity = Number(min);
  const price = toNumeric(unitPrice);
  if (!Number.isFinite(minQuantity) || !price || !Number.isFinite(basePrice) || basePrice <= 0 || minQuantity <= 0) {
    return null;
  }
  const discount = Math.max(0, Math.min(100, (1 - price / basePrice) * 100));
  return {
    minQuantity: Math.floor(minQuantity),
    discountPercentage: Math.round(discount),
  };
};

const parseFixedPriceRules = (value: unknown, basePrice: number): BulkPricingTier[] => {
  if (!value || !Number.isFinite(basePrice) || basePrice <= 0) {
    return [];
  }

  const entries: Array<{ min: unknown; price: unknown }> = [];
  const collect = (min: unknown, price: unknown) => {
    entries.push({ min, price });
  };

  if (Array.isArray(value)) {
    value.forEach((item) => {
      if (typeof item === 'object' && item !== null) {
        collect((item as any).quantity ?? (item as any).min ?? (item as any).minQuantity, (item as any).price ?? (item as any).value);
      }
    });
  } else if (typeof value === 'object') {
    Object.entries(value as Record<string, unknown>).forEach(([key, price]) => collect(key, price));
  } else if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return parseFixedPriceRules(parsed, basePrice);
    } catch {
      value.split(/[\n,;]/).forEach((token) => {
        if (!token) return;
        const parts = token.split(/[:=|-]/).map((part) => part.trim());
        if (parts.length >= 2) {
          collect(parts[0], parts[1]);
        }
      });
    }
  }

  return entries
    .map(({ min, price }) => normalizeFixedRule(min, price, basePrice))
    .filter((tier): tier is BulkPricingTier => Boolean(tier))
    .sort((a, b) => a.minQuantity - b.minQuantity);
};

const parsePepproTiersFromMeta = (meta: WooMeta[] | undefined, basePrice: number): BulkPricingTier[] => {
  if (!Array.isArray(meta) || basePrice <= 0) {
    return [];
  }
  const tiers: BulkPricingTier[] = [];
  meta.forEach((entry) => {
    const key = String(entry?.key || '');
    if (!key.includes('peppro_tier') || key.includes('note')) {
      return;
    }
    const qtyMatch = key.match(/(\d+)/);
    const minQuantity = qtyMatch ? Number(qtyMatch[1]) : null;
    const price = toNumeric(entry?.value);
    if (!minQuantity || !price) {
      return;
    }
    const tier = normalizeFixedRule(minQuantity, price, basePrice);
    if (tier) {
      tiers.push(tier);
    }
  });
  return tiers.sort((a, b) => a.minQuantity - b.minQuantity);
};

const parseVariantBulkPricing = (variation: WooVariation, basePrice: number): BulkPricingTier[] => {
  if (!Number.isFinite(basePrice) || basePrice <= 0) {
    return [];
  }
  const fromProp = parseFixedPriceRules(variation.tiered_pricing_fixed_rules ?? null, basePrice);
  if (fromProp.length > 0) {
    return fromProp;
  }
  const meta = variation.meta_data ?? [];
  const fixedRulesMeta = meta.find((entry) => entry?.key === '_fixed_price_rules')?.value;
  const fromMeta = parseFixedPriceRules(fixedRulesMeta, basePrice);
  if (fromMeta.length > 0) {
    return fromMeta;
  }
  return parsePepproTiersFromMeta(meta as WooMeta[], basePrice);
};

const mapWooProductToProduct = (product: WooProduct, productVariations: WooVariation[] = []): Product => {
  const imageSources = (product.images ?? [])
    .map((image) => image?.src)
    .filter((src): src is string => Boolean(src));
  const rawCategoryName = product.categories?.[0]?.name?.trim() ?? '';
  const categoryName = rawCategoryName && !rawCategoryName.toLowerCase().includes('subscription') ? rawCategoryName : '';
  const subscriptionMetaFlag = (product.meta_data ?? []).some((meta) => {
    const key = (meta?.key ?? '').toString().toLowerCase();
    const value = typeof meta?.value === 'string' ? meta.value.toLowerCase() : '';
    return key.includes('subscription') || value.includes('subscription');
  });
  const priceHtml = (product.price_html ?? '').toLowerCase();
  const categorySubscription = (product.categories ?? []).some((cat) =>
    (cat?.name ?? '').toLowerCase().includes('subscription'),
  );
  const descriptionText = `${product.description ?? ''} ${product.short_description ?? ''}`.toLowerCase();
  const isSubscriptionProduct =
    subscriptionMetaFlag ||
    priceHtml.includes('subscription') ||
    priceHtml.includes('/ month') ||
    (product.type ?? '').toLowerCase().includes('subscription') ||
    (product.name ?? '').toLowerCase().includes('subscription') ||
    categorySubscription ||
    descriptionText.includes('subscription');

  const parsePrice = (value?: string) => {
    if (value === undefined || value === null || value === '') {
      return undefined;
    }
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : undefined;
  };

  const normalizeAttributes = (attributes?: WooVariationAttribute[]) =>
    (attributes ?? [])
      .map((attr) => {
        const name = stripHtml(attr?.name ?? '').trim();
        const value = stripHtml(attr?.option ?? '').trim();
        if (!name && !value) {
          return null;
        }
        return {
          name: name || value || 'Option',
          value: value || name || '',
        };
      })
      .filter(
        (attr): attr is { name: string; value: string } =>
          Boolean(attr && (attr.name || attr.value)),
      );

  const bulkPricingMeta = product.meta_data?.find((meta) => {
    const key = (meta?.key ?? '').toString().toLowerCase();
    return BULK_META_KEYS.includes(key);
  });
  const parentBulkPricing = bulkPricingMeta ? parseBulkPricingValue(bulkPricingMeta.value) : [];
  let variantDerivedBulkPricing: BulkPricingTier[] = [];

  const variantList: ProductVariant[] = (productVariations ?? [])
    .map((variation) => {
      const parsedVariantPrice = parsePrice(variation.price) ?? parsePrice(variation.regular_price);
      const fallbackPrice = parsePrice(product.price) ?? parsePrice(product.regular_price) ?? 0;
      const price = parsedVariantPrice ?? fallbackPrice;
      const originalPrice = parsePrice(variation.regular_price);
      const attributes = normalizeAttributes(variation.attributes);
      const label =
        attributes.length > 0
          ? attributes.map((attr) => attr.value || attr.name).filter(Boolean).join(' • ')
          : variation.sku
            ? variation.sku
            : `Variant ${variation.id}`;
      const variantId = `woo-variation-${variation.id}`;
      const variantBulk = parseVariantBulkPricing(variation, price);
      if (!variantDerivedBulkPricing.length && variantBulk.length) {
        variantDerivedBulkPricing = variantBulk;
      }
      return {
        id: variantId,
        label,
        price,
        originalPrice: originalPrice && originalPrice > price ? originalPrice : undefined,
        sku: variation.sku ?? undefined,
        inStock: (variation.stock_status ?? '').toLowerCase() !== 'outofstock',
        attributes,
        image: variation.image?.src ?? undefined,
        description: stripHtml(variation.description ?? '') || undefined,
      };
    })
    .filter((variant): variant is ProductVariant => Number.isFinite(variant.price));

  const hasVariants = variantList.length > 0;
  const variantPrices = variantList
    .map((variant) => variant.price)
    .filter((value): value is number => Number.isFinite(value));
  const minVariantPrice = variantPrices.length > 0 ? Math.min(...variantPrices) : undefined;
  const basePrice = parsePrice(product.price) ?? parsePrice(product.regular_price) ?? 0;
  const price = hasVariants ? (minVariantPrice ?? basePrice) : basePrice;
  const baseOriginalPrice = parsePrice(product.regular_price);
  const originalPrice = !hasVariants && baseOriginalPrice && baseOriginalPrice > price ? baseOriginalPrice : undefined;
  const cleanedDescription = stripHtml(product.short_description || product.description);
  const manufacturerMeta = product.meta_data?.find((meta) => meta?.key === 'manufacturer')?.value;
  const productBulkPricing = parentBulkPricing.length > 0 ? parentBulkPricing : variantDerivedBulkPricing;
  const variantImages = variantList.map((variant) => variant.image).filter((src): src is string => Boolean(src));
  const combinedImages = [...variantImages, ...imageSources].filter(
    (src, index, self) => Boolean(src) && self.indexOf(src) === index,
  ) as string[];
  const galleryImages = combinedImages.length > 0 ? combinedImages : [WOO_PLACEHOLDER_IMAGE];
  const variantSummary = hasVariants
    ? (() => {
        const labels = variantList.map((variant) => variant.label).filter(Boolean);
        if (labels.length <= 3) {
          return labels.join(' • ');
        }
        const remaining = labels.length - 3;
        return `${labels.slice(0, 3).join(' • ')} +${remaining} more`;
      })()
    : undefined;
  const defaultVariantId = hasVariants
    ? variantList.find((variant) => variant.inStock)?.id ?? variantList[0]?.id
    : undefined;

  return {
    id: `woo-${product.id}`,
    name: stripHtml(product.name) || `Product ${product.id}`,
    category: categoryName,
    price,
    originalPrice,
    rating: Number.parseFloat(product.average_rating || '') || 5,
    reviews: Number.isFinite(product.rating_count) ? Number(product.rating_count) : 0,
    image: galleryImages[0] ?? WOO_PLACEHOLDER_IMAGE,
    images: galleryImages,
    inStock: hasVariants
      ? variantList.some((variant) => variant.inStock)
      : (product.stock_status ?? '').toLowerCase() !== 'outofstock',
    prescription: false,
    dosage: hasVariants
      ? `${variantList.length} option${variantList.length === 1 ? '' : 's'} available`
      : product.sku
        ? `SKU ${product.sku}`
        : 'See details',
    manufacturer: stripHtml(typeof manufacturerMeta === 'string' ? manufacturerMeta : '') || '',
    type: product.type ?? 'General',
    isSubscription: isSubscriptionProduct,
    description: cleanedDescription || undefined,
    variants: hasVariants ? variantList : undefined,
    hasVariants,
    defaultVariantId,
    variantSummary,
    bulkPricingTiers: productBulkPricing.length > 0 ? productBulkPricing : undefined,
  };
};

const toCardProduct = (product: Product): CardProduct => {
  const variations = (product.variants && product.variants.length > 0)
    ? product.variants.map((variant) => ({
        id: variant.id,
        strength: variant.label || variant.attributes.map((attr) => attr.value).join(' • ') || 'Option',
        basePrice: variant.price,
      }))
    : [{
        id: product.id,
        strength: product.dosage || 'Standard',
        basePrice: product.price,
      }];

  return {
    id: product.id,
    name: product.name,
    category: product.category,
    image: product.image,
    inStock: product.inStock,
    manufacturer: product.manufacturer,
    variations,
    bulkPricingTiers: product.bulkPricingTiers ?? [],
  };
};

const fetchProductVariations = async (products: WooProduct[]): Promise<Map<number, WooVariation[]>> => {
  const variationMap = new Map<number, WooVariation[]>();
  if (products.length === 0) {
    return variationMap;
  }

  const queue = [...products];
  const concurrency = Math.min(4, queue.length);

  const workers = Array.from({ length: concurrency }, () =>
    (async function worker() {
      while (queue.length > 0) {
        const nextProduct = queue.shift();
        if (!nextProduct) {
          break;
        }
        try {
          const variations = await listProductVariations<WooVariation[]>(nextProduct.id, { per_page: 100, status: 'publish' });
          if (Array.isArray(variations)) {
            variationMap.set(nextProduct.id, variations);
          } else {
            variationMap.set(nextProduct.id, []);
          }
        } catch (error) {
          console.warn('[WooCommerce] Failed to load variations', { productId: nextProduct.id, error });
        }
      }
    })(),
  );

  await Promise.all(workers);
  return variationMap;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [productDetailOpen, setProductDetailOpen] = useState(false);
  const [loginPromptToken, setLoginPromptToken] = useState(0);
  const apiWarmupInFlight = useRef(false);
  const [shouldReopenCheckout, setShouldReopenCheckout] = useState(false);
  const [loginContext, setLoginContext] = useState<'checkout' | null>(null);
  const [landingAuthMode, setLandingAuthMode] = useState<'login' | 'signup'>('login');
  const [postLoginHold, setPostLoginHold] = useState(false);
  const [isReturningUser, setIsReturningUser] = useState(false);
  const [infoFocusActive, setInfoFocusActive] = useState(false);
  const [shouldAnimateInfoFocus, setShouldAnimateInfoFocus] = useState(false);
  const prevUserRef = useRef<User | null>(null);
  const [showLandingLoginPassword, setShowLandingLoginPassword] = useState(false);
  const [showLandingSignupPassword, setShowLandingSignupPassword] = useState(false);
  const [showLandingSignupConfirm, setShowLandingSignupConfirm] = useState(false);
  const checkoutButtonObserverRef = useRef<IntersectionObserver | null>(null);
  const [isCheckoutButtonVisible, setIsCheckoutButtonVisible] = useState(false);
  const filterSidebarRef = useRef<HTMLDivElement | null>(null);
  const landingLoginEmailRef = useRef<HTMLInputElement | null>(null);
  const landingLoginPasswordRef = useRef<HTMLInputElement | null>(null);
  const landingCredentialAutofillInFlight = useRef(false);
  const [passkeySupport, setPasskeySupport] = useState({
    platform: false,
    conditional: false,
    checked: false,
  });
  const stripePromise = useMemo(() => {
    const key = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '';
    return key ? loadStripe(key) : null;
  }, []);
  const stripeIsTestMode = useMemo(() => {
    const explicitMode = (import.meta.env.VITE_STRIPE_MODE || import.meta.env.STRIPE_MODE || '').toLowerCase();
    if (explicitMode === 'test') {
      return true;
    }
    const pk = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '';
    return pk.startsWith('pk_test');
  }, []);
  const passkeyConditionalInFlight = useRef(false);
  const [passkeyLoginPending, setPasskeyLoginPending] = useState(false);
  const [landingLoginPending, setLandingLoginPending] = useState(false);
  const [enablePasskeyPending, setEnablePasskeyPending] = useState(false);
  const [enablePasskeyError, setEnablePasskeyError] = useState('');
  const passkeyAutoRegisterAttemptedRef = useRef(false);
  const [accountOrders, setAccountOrders] = useState<AccountOrderSummary[]>([]);
  const [accountOrdersLoading, setAccountOrdersLoading] = useState(false);
  const [accountOrdersError, setAccountOrdersError] = useState<string | null>(null);
  const [accountOrdersSyncedAt, setAccountOrdersSyncedAt] = useState<string | null>(null);
  const [accountModalRequest, setAccountModalRequest] = useState<{ tab: 'details' | 'orders'; open?: boolean; token: number } | null>(null);
  const triggerLandingCredentialAutofill = useCallback(async () => {
    if (landingCredentialAutofillInFlight.current) {
      return;
    }
    landingCredentialAutofillInFlight.current = true;
    try {
      const credential = await requestStoredPasswordCredential();
      if (credential) {
        if (landingLoginEmailRef.current) {
          landingLoginEmailRef.current.value = credential.id;
        }
        if (landingLoginPasswordRef.current) {
          landingLoginPasswordRef.current.value = credential.password;
        }
      }
    } finally {
      landingCredentialAutofillInFlight.current = false;
    }
  }, []);

  const loadAccountOrders = useCallback(async () => {
    if (!user?.id) {
      setAccountOrders([]);
      setAccountOrdersSyncedAt(null);
      setAccountOrdersError(null);
      return [];
    }
    setAccountOrdersLoading(true);
    setAccountOrdersError(null);
    try {
      const response = await ordersAPI.getAll();
      const normalized = normalizeAccountOrdersResponse(response);
      setAccountOrders(normalized);
      const fetchedAt =
        response && typeof response === 'object' && (response as any).fetchedAt
          ? (response as any).fetchedAt
          : new Date().toISOString();
      setAccountOrdersSyncedAt(typeof fetchedAt === 'string' ? fetchedAt : new Date().toISOString());
      const wooErrorMessage =
        response && typeof response === 'object' && (response as any).wooError
          ? (response as any).wooError.message || null
          : null;
      setAccountOrdersError(wooErrorMessage);
      return normalized;
    } catch (error: any) {
      const message = typeof error?.message === 'string' ? error.message : 'Unable to load orders.';
      setAccountOrdersError(message);
      throw error;
    } finally {
      setAccountOrdersLoading(false);
    }
  }, [user?.id]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const platform = await detectPlatformPasskeySupport();
      const conditional = detectConditionalPasskeySupport();
      if (!cancelled) {
        setPasskeySupport({
          platform,
          conditional,
          checked: true,
        });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    return () => {
      if (newsLoadingTimeoutRef.current) {
        clearTimeout(newsLoadingTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!user?.id) {
      setAccountOrders([]);
      setAccountOrdersSyncedAt(null);
      setAccountOrdersError(null);
      return;
    }
    loadAccountOrders();
  }, [user?.id, loadAccountOrders]);

  useEffect(() => {
    let cancelled = false;
    let retryTimeoutId: number | null = null;
    const warmApi = async () => {
      if (apiWarmupInFlight.current || cancelled) {
        return;
      }
      apiWarmupInFlight.current = true;
      try {
        await checkServerHealth();
        console.debug('[Health] API warmup complete');
      } catch (error) {
        console.warn('[Health] API warmup failed', error);
        if (!cancelled) {
          apiWarmupInFlight.current = false;
          retryTimeoutId = window.setTimeout(warmApi, 1200);
        }
        return;
      }
      apiWarmupInFlight.current = false;
    };
    warmApi();
    return () => {
      cancelled = true;
      if (retryTimeoutId !== null) {
        window.clearTimeout(retryTimeoutId);
      }
    };
  }, []);

  useEffect(() => {
    if (!user && loginPromptToken > 0) {
      checkServerHealth().catch((error) => {
        console.warn('[Health] Login prompt warmup failed', error);
      });
    }
  }, [loginPromptToken, user]);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }

    if (user) {
      return undefined;
    }

    let cancelled = false;

    const sendKeepAlive = async () => {
      if (cancelled) {
        return;
      }
      try {
        await checkServerHealth();
      } catch (error) {
        if (!cancelled) {
          console.warn('[Health] Keep-alive ping failed', error);
        }
      }
    };

    sendKeepAlive();
    const intervalId = window.setInterval(() => {
      void sendKeepAlive();
    }, LOGIN_KEEPALIVE_INTERVAL_MS);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [user]);

  useEffect(() => {
    if (postLoginHold && user && shouldAnimateInfoFocus) {
      setInfoFocusActive(true);
      const timeoutId = window.setTimeout(() => {
        setInfoFocusActive(false);
        setShouldAnimateInfoFocus(false);
      }, 1500);
      return () => {
        window.clearTimeout(timeoutId);
        setInfoFocusActive(false);
      };
    }
    if (!shouldAnimateInfoFocus) {
      setInfoFocusActive(false);
    }
  }, [postLoginHold, user?.id, shouldAnimateInfoFocus]);

  const applyLoginSuccessState = useCallback((nextUser: User) => {
    setUser(nextUser);
    setPostLoginHold(true);
    setShouldAnimateInfoFocus(true);
    setInfoFocusActive(true);
    const isReturning = (nextUser.visits ?? 1) > 1;
    setIsReturningUser(isReturning);
    setLoginContext(null);
    setShowLandingLoginPassword(false);
    setShowLandingSignupPassword(false);
    setShowLandingSignupConfirm(false);
    // Allow auto-registration attempt after each successful login
    passkeyAutoRegisterAttemptedRef.current = false;
  }, []);

  const performPasskeyLogin = useCallback(async (options?: {
    emailHint?: string | null;
    useConditionalUI?: boolean;
  }) => {
    const { requestId, publicKey } = await authAPI.passkeys.getAuthenticationOptions(options?.emailHint || undefined);
    const assertion = await beginPasskeyAuthentication(publicKey, Boolean(options?.useConditionalUI));
    const nextUser = await authAPI.passkeys.completeAuthentication({
      requestId,
      assertionResponse: assertion,
    });
    applyLoginSuccessState(nextUser);
    return nextUser;
  }, [applyLoginSuccessState]);

  const startConditionalPasskeyLogin = useCallback(async () => {
    // Try conditional UI even if detection says unavailable; some browsers under-report support.
    if (user || passkeyConditionalInFlight.current) {
      return;
    }
    passkeyConditionalInFlight.current = true;
    try {
      await performPasskeyLogin({ useConditionalUI: true });
    } catch (error: any) {
      if (!(error instanceof DOMException) || error.name !== 'NotAllowedError') {
        console.debug('[Passkey] Conditional login dismissed or failed', error);
      }
    } finally {
      passkeyConditionalInFlight.current = false;
    }
  }, [performPasskeyLogin, user]);

  useEffect(() => {
    // Only attempt conditional UI when explicitly enabled via env flag.
    if (!user && PASSKEY_AUTOPROMPT && passkeySupport.conditional) {
      void startConditionalPasskeyLogin();
    }
  }, [user, passkeySupport.conditional, startConditionalPasskeyLogin]);

  const handleLandingCredentialFocus = useCallback(() => {
    // Only try to autofill saved username/password; do not auto-trigger passkey UI.
    void triggerLandingCredentialAutofill();
  }, [triggerLandingCredentialAutofill]);

  const handleManualPasskeyLogin = useCallback(async () => {
    if (!passkeySupport.platform) {
      setLandingLoginError('Passkey login is not available on this device.');
      return;
    }
    const emailInput = landingLoginEmailRef.current?.value?.trim();
    if (!emailInput) {
      setLandingLoginError('Enter your email to sign in with a passkey.');
      return;
    }
    setPasskeyLoginPending(true);
    setLandingLoginError('');
    try {
      await performPasskeyLogin({ emailHint: emailInput });
    } catch (error: any) {
      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        return;
      }
      const message = (error?.message || '').toUpperCase();
      if (message.includes('PASSKEY_NOT_REGISTERED')) {
        setLandingLoginError('No passkey found for that email yet. Sign in with your password once to enable passkeys.');
      } else if (message.includes('EMAIL_NOT_FOUND')) {
        setLandingLoginError('We could not find that email.');
      } else {
        setLandingLoginError('Unable to sign in with passkey. Please try again or use your password.');
      }
      console.warn('[Passkey] Authentication failed', error);
    } finally {
      setPasskeyLoginPending(false);
    }
  }, [passkeySupport.platform, performPasskeyLogin]);

  const handleEnablePasskey = useCallback(async () => {
    if (!user) return;
    if (!passkeySupport.platform) {
      setEnablePasskeyError('Passkey setup is not available on this device.');
      return;
    }
    setEnablePasskeyPending(true);
    setEnablePasskeyError('');
    try {
      const { requestId, publicKey } = await authAPI.passkeys.getRegistrationOptions();
      const attestation = await beginPasskeyRegistration(publicKey);
      const result = await authAPI.passkeys.completeRegistration({ requestId, attestationResponse: attestation, label: 'This device' });
      if (result?.user) {
        setUser(result.user);
      }
    } catch (error: any) {
      const msg = (error?.message || '').toUpperCase();
      if (msg.includes('PASSKEY_ALREADY_REGISTERED')) {
        setEnablePasskeyError('A passkey is already registered for this device.');
      } else if (error instanceof DOMException && error.name === 'NotAllowedError') {
        // User canceled; do not show an error
      } else {
        setEnablePasskeyError('Unable to enable biometric sign-in. Please try again.');
      }
      console.warn('[Passkey] Registration failed', error);
    } finally {
      setEnablePasskeyPending(false);
    }
  }, [user, passkeySupport.platform]);

  // Optionally auto-register a passkey after successful login (opt-in via env).
  useEffect(() => {
    if (!PASSKEY_AUTOREGISTER) return;
    if (!user || !passkeySupport.platform || passkeyAutoRegisterAttemptedRef.current) {
      return;
    }
    passkeyAutoRegisterAttemptedRef.current = true;
    void handleEnablePasskey();
  }, [user, passkeySupport.platform, handleEnablePasskey]);

  // (handled directly in handleLogin/handleCreateAccount to avoid flicker)
  const [landingLoginError, setLandingLoginError] = useState('');
  const [landingSignupError, setLandingSignupError] = useState('');
  const [landingNpiStatus, setLandingNpiStatus] = useState<'idle' | 'checking' | 'verified' | 'rejected'>('idle');
  const [landingNpiMessage, setLandingNpiMessage] = useState('');
  const landingNpiRecordRef = useRef<{ name?: string | null; verifiedNpiNumber?: string } | null>(null);
  const landingNpiCheckIdRef = useRef(0);
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    types: [],
    inStockOnly: false
  });
  const [doctorSummary, setDoctorSummary] = useState<DoctorCreditSummary | null>(null);
  const [doctorReferrals, setDoctorReferrals] = useState<ReferralRecord[]>([]);
  const [salesRepDashboard, setSalesRepDashboard] = useState<SalesRepDashboard | null>(null);
  const [salesRepStatusFilter, setSalesRepStatusFilter] = useState<string>('all');
  const [referralForm, setReferralForm] = useState({
    contactName: '',
    contactEmail: '',
    contactPhone: '',
    notes: '',
  });
  const [referralSubmitting, setReferralSubmitting] = useState(false);
  const [referralStatusMessage, setReferralStatusMessage] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [referralDataLoading, setReferralDataLoading] = useState(false);
  const [referralDataError, setReferralDataError] = useState<ReactNode>(null);
  const referralRefreshInFlight = useRef(false);
  const [adminActionState, setAdminActionState] = useState<{
    updatingReferral: string | null;
    error: string | null;
  }>({
    updatingReferral: null,
    error: null,
  });
  const [catalogProducts, setCatalogProducts] = useState<Product[]>([]);
  const [catalogCategories, setCatalogCategories] = useState<string[]>([]);
  const [catalogTypes, setCatalogTypes] = useState<string[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogError, setCatalogError] = useState<string | null>(null);
const [peptideNews, setPeptideNews] = useState<PeptideNewsItem[]>([]);
const [peptideNewsLoading, setPeptideNewsLoading] = useState(false);
const [peptideNewsError, setPeptideNewsError] = useState<string | null>(null);
const [peptideNewsUpdatedAt, setPeptideNewsUpdatedAt] = useState<Date | null>(null);
const newsLoadingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
const beginNewsLoading = useCallback(() => {
  if (newsLoadingTimeoutRef.current) {
    clearTimeout(newsLoadingTimeoutRef.current);
    newsLoadingTimeoutRef.current = null;
  }
  setPeptideNewsLoading(true);
}, []);
const settleNewsLoading = useCallback((startedAt: number) => {
  const elapsed = Date.now() - startedAt;
  const remaining = Math.max(0, MIN_NEWS_LOADING_MS - elapsed);
  if (newsLoadingTimeoutRef.current) {
    clearTimeout(newsLoadingTimeoutRef.current);
  }
  newsLoadingTimeoutRef.current = window.setTimeout(() => {
    setPeptideNewsLoading(false);
    newsLoadingTimeoutRef.current = null;
  }, remaining);
}, []);
  const [isReferralSectionExpanded, setIsReferralSectionExpanded] = useState(false);
  const [quoteOfTheDay, setQuoteOfTheDay] = useState<{ text: string; author: string } | null>(null);
  const [showWelcome, setShowWelcome] = useState(false);
  const [showQuote, setShowQuote] = useState(false);
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [referralSearchTerm, setReferralSearchTerm] = useState('');
  const [referralSortOrder, setReferralSortOrder] = useState<'desc' | 'asc'>('desc');
  const [isDesktopLandingLayout, setIsDesktopLandingLayout] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth >= 1024;
  });

const filteredDoctorReferrals = useMemo(() => {
    const normalizedQuery = referralSearchTerm.trim().toLowerCase();
    const sorted = [...doctorReferrals].sort((a, b) => {
      const aTime = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const bTime = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return referralSortOrder === 'desc' ? bTime - aTime : aTime - bTime;
    });

    if (!normalizedQuery) {
      return sorted;
    }

    return sorted.filter((referral) => {
      const haystack = [
        referral.referredContactName ?? '',
        referral.referredContactEmail ?? '',
        referral.referredContactPhone ?? '',
        referral.status ?? '',
      ]
        .join(' ')
        .toLowerCase();
      return haystack.includes(normalizedQuery);
    });
  }, [doctorReferrals, referralSearchTerm, referralSortOrder]);

  const salesRepStatusOptions = useMemo(() => {
    if (!salesRepDashboard) {
      return [] as string[];
    }
    if (Array.isArray(salesRepDashboard.statuses) && salesRepDashboard.statuses.length > 0) {
      return Array.from(new Set(salesRepDashboard.statuses.map((status) => (status || '').trim()))).filter(Boolean);
    }
    return Array.from(
      new Set((salesRepDashboard.referrals ?? []).map((referral) => (referral.status || '').trim()).filter(Boolean))
    );
  }, [salesRepDashboard]);

  const filteredSalesRepReferrals = useMemo(() => {
    const allReferrals = salesRepDashboard?.referrals ?? [];
    console.debug('[Referral] Filter compute', {
      filter: salesRepStatusFilter,
      total: allReferrals.length,
    });
    if (salesRepStatusFilter === 'all') {
      return allReferrals;
    }
    const filtered = allReferrals.filter(
      (referral) => (referral.status || '').toLowerCase() === salesRepStatusFilter.toLowerCase()
    );
    console.debug('[Referral] Filter result', { filter: salesRepStatusFilter, count: filtered.length });
    return filtered;
  }, [salesRepDashboard, salesRepStatusFilter]);

  const salesRepChartData = useMemo(() => {
    const referralList = salesRepDashboard?.referrals ?? [];
    const counts = referralList.reduce<Record<string, number>>((acc, referral) => {
      const status = (referral.status || 'pending').toLowerCase();
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    return SALES_REP_STATUS_ORDER.map((status) => ({
      status,
      label: humanizeReferralStatus(status),
      count: counts[status] || 0,
    }));
  }, [salesRepDashboard?.referrals]);

  const handleReferralSortToggle = useCallback(() => {
    setReferralSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'));
  }, []);

  const sortDirectionLabel = referralSortOrder === 'desc' ? 'Newest first' : 'Oldest first';

  useEffect(() => {
    if (salesRepStatusFilter === 'all') {
      return;
    }
    const available = new Set(salesRepStatusOptions.map((status) => status.toLowerCase()));
    if (!available.has(salesRepStatusFilter.toLowerCase())) {
      setSalesRepStatusFilter('all');
    }
  }, [salesRepStatusFilter, salesRepStatusOptions]);

  const refreshReferralData = useCallback(async (options?: { showLoading?: boolean }) => {
    if (!user) {
      console.debug('[Referral] refreshReferralData skipped: no user');
      return;
    }

    const shouldShowLoading = options?.showLoading ?? true;

    if (referralRefreshInFlight.current) {
      if (shouldShowLoading) {
        setReferralDataLoading(true);
      }
      return;
    }

    referralRefreshInFlight.current = true;

    if (shouldShowLoading) {
      setReferralDataLoading(true);
    }

    console.debug('[Referral] Refresh start', { role: user.role, userId: user.id });

    try {
      setReferralDataError(null);
      if (user.role === 'doctor') {
        const response = await referralAPI.getDoctorSummary();
        const referrals = Array.isArray(response?.referrals) ? response.referrals : [];
        const credits = response?.credits ?? {};

        const normalizedCredits: DoctorCreditSummary = {
          totalCredits: Number(credits.totalCredits ?? 0),
          firstOrderBonuses: Number(credits.firstOrderBonuses ?? 0),
          ledger: Array.isArray(credits.ledger) ? credits.ledger : [],
        };

        setDoctorSummary({ ...normalizedCredits });
        const normalizedReferrals = referrals.map((referral) => ({ ...referral }));
        setDoctorReferrals(normalizedReferrals);
        setUser((previous) => {
          if (!previous) {
            return previous;
          }
          const nextCredits = normalizedCredits.totalCredits;
          const nextTotalReferrals = normalizedReferrals.length;
          const unchanged =
            Number(previous.referralCredits ?? 0) === nextCredits &&
            Number(previous.totalReferrals ?? 0) === nextTotalReferrals;
          if (unchanged) {
            return previous;
          }
          return {
            ...previous,
            referralCredits: nextCredits,
            totalReferrals: nextTotalReferrals,
          };
        });
        console.debug('[Referral] Doctor summary loaded', {
          referrals: normalizedReferrals.length,
          credits: normalizedCredits,
        });
      } else if (user.role === 'sales_rep') {
        const dashboard = await referralAPI.getSalesRepDashboard();
        setSalesRepDashboard(dashboard);
        console.debug('[Referral] Sales rep dashboard loaded', {
          referrals: dashboard?.referrals?.length ?? 0,
          statuses: dashboard?.statuses ?? null,
        });
      } else {
        console.debug('[Referral] Refresh skipped for role', { role: user.role });
      }
    } catch (error: any) {
      const status = typeof error?.status === 'number' ? error.status : null;
      const message = typeof error?.message === 'string' ? error.message : 'UNKNOWN_ERROR';
      console.warn('[Referral] Failed to load data', { status, message, error });
      setReferralDataError(
        <>
          There is an issue in loading your referral data. Please refresh the page or contact{' '}
          <a className="text-[rgb(95,179,249)] underline" href="mailto:support@peppro.net">
            support@peppro.net
          </a>
          .
        </>,
      );
    } finally {
      console.debug('[Referral] Refresh complete', { role: user.role });
      referralRefreshInFlight.current = false;
      if (shouldShowLoading) {
        setReferralDataLoading(false);
      }
    }
  }, [user, setUser]);

  const formatDate = useCallback((value?: string | null) => {
    if (!value) {
      return '—';
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return date.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  }, []);

  const formatDateTime = useCallback((value?: string | null) => {
    if (!value) {
      return '—';
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }, []);

  const checkoutButtonRef = useCallback((node: HTMLButtonElement | null) => {
    if (checkoutButtonObserverRef.current) {
      checkoutButtonObserverRef.current.disconnect();
      checkoutButtonObserverRef.current = null;
    }

    if (!node || typeof IntersectionObserver === 'undefined') {
      setIsCheckoutButtonVisible(false);
      return;
    }

    const observer = new IntersectionObserver(([entry]) => {
      setIsCheckoutButtonVisible(entry.isIntersecting);
    }, {
      rootMargin: '-10% 0px 0px 0px',
    });

    observer.observe(node);
    checkoutButtonObserverRef.current = observer;
  }, []);

  // Always start with a clean auth slate on fresh loads
  useEffect(() => {
    authAPI.logout();
  }, []);

  useEffect(() => {
    let cancelled = false;
    const warmApi = async () => {
      const start = typeof performance !== 'undefined' && typeof performance.now === 'function'
        ? performance.now()
        : Date.now();
      try {
        const healthy = await checkServerHealth();
        if (!cancelled) {
          const end = typeof performance !== 'undefined' && typeof performance.now === 'function'
            ? performance.now()
            : Date.now();
          console.debug('[Auth] API warm-up complete', {
            healthy,
            durationMs: Math.round(end - start),
          });
        }
      } catch (error) {
        if (!cancelled) {
          console.warn('[Auth] API warm-up failed', error);
        }
      }
    };
    warmApi();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    // Dev-only: Load a local Woo fixture for testing ProductCard if flag set
    const useFixture = (import.meta as any).env?.VITE_USE_LOCAL_WOO_FIXTURE === 'true';
    if (useFixture) {
      (async () => {
        const fixture = await loadLocalProductForCard();
        if (fixture) {
          setCatalogProducts([fixture as any]);
          setCatalogCategories([fixture.category]);
          setCatalogTypes(['variable']);
        }
      })();
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    let cancelled = false;
    const loadCatalog = async () => {
      setCatalogLoading(true);
      setCatalogError(null);
      try {
        const [wooProducts, wooCategories] = await Promise.all([
          listProducts<WooProduct[]>({ per_page: 48, status: 'publish' }),
          listCategories<WooCategory[]>({ per_page: 100 }),
        ]);

        if (cancelled) {
          return;
        }

        const variableProducts = (wooProducts ?? []).filter(
          (item): item is WooProduct => Boolean(item && typeof item === 'object' && item.type === 'variable'),
        );
        const variationMap = variableProducts.length > 0
          ? await fetchProductVariations(variableProducts)
          : new Map<number, WooVariation[]>();

        if (cancelled) {
          return;
        }

        const mappedProducts = (wooProducts ?? [])
          .filter((item): item is WooProduct => Boolean(item && typeof item === 'object' && 'id' in item))
          .map((item) => mapWooProductToProduct(item, variationMap.get(item.id) ?? []))
          .filter((product) => product && product.name);

        if (mappedProducts.length > 0) {
          setCatalogProducts(mappedProducts);
          const categoriesFromProducts = Array.from(
            new Set(
              mappedProducts
                .map((product) => product.category)
                .filter(
                  (category): category is string =>
                    Boolean(category) && !category.toLowerCase().includes('subscription'),
                ),
            ),
          );
          const categoryNamesFromApi = Array.isArray(wooCategories)
            ? wooCategories
                .map((category) => category?.name?.trim())
                .filter(
                  (name): name is string =>
                    Boolean(name) && !name.toLowerCase().includes('subscription'),
                )
            : [];
          const nextCategories =
            categoriesFromProducts.length > 0
              ? categoriesFromProducts
              : categoryNamesFromApi.length > 0
                ? categoryNamesFromApi
                : [];
          setCatalogCategories(nextCategories);

          const typesFromProducts = Array.from(
            new Set(mappedProducts.map((product) => product.type).filter(Boolean)),
          ) as string[];
          setCatalogTypes(typesFromProducts);
        } else if (Array.isArray(wooCategories) && wooCategories.length > 0) {
          const categoryNames = wooCategories
            .map((category) => category?.name?.trim())
            .filter(
              (name): name is string =>
                Boolean(name) && !name.toLowerCase().includes('subscription'),
            );
          if (categoryNames.length > 0) {
            setCatalogCategories(categoryNames);
          }
        }
      } catch (error) {
        if (!cancelled) {
          console.warn('[WooCommerce] Catalog fetch failed', error);
          // Per preference: keep catalog empty when Woo is not available.
          setCatalogProducts([]);
          setCatalogCategories([]);
          setCatalogTypes([]);
          setCatalogError(null);
        }
      } finally {
        if (!cancelled) {
          setCatalogLoading(false);
        }
      }
    };

    loadCatalog();

    return () => {
      cancelled = true;
    };
  }, []);

useEffect(() => {
  let cancelled = false;
  const loadPeptideNews = async () => {
    beginNewsLoading();
    setPeptideNewsError(null);
    const startedAt = Date.now();

      try {
        const data = await newsAPI.getPeptideHeadlines();
        if (cancelled) {
          return;
        }

        const items = Array.isArray(data?.items)
          ? data.items
            .map((item: any) => ({
              title: typeof item?.title === 'string' ? item.title.trim() : '',
              url: typeof item?.url === 'string' ? item.url.trim() : '',
              summary: typeof item?.summary === 'string' && item.summary.trim() ? item.summary.trim() : undefined,
              image: typeof item?.imageUrl === 'string' && item.imageUrl.trim() ? item.imageUrl.trim() : undefined,
              date: typeof item?.date === 'string' && item.date.trim() ? item.date.trim() : undefined,
            }))
            .filter((item) => item.title && item.url)
          : [];

        if (items.length === 0) {
          setPeptideNews([]);
          setPeptideNewsError('No headlines available right now.');
          setPeptideNewsUpdatedAt(new Date());
          return;
        }
        setPeptideNews(items.slice(0, 6));
        setPeptideNewsUpdatedAt(new Date());
      } catch (error) {
        if (!cancelled) {
          console.warn('[News] Failed to load peptide headlines', error);
          setPeptideNewsError('Unable to load peptide news at the moment.');
          setPeptideNews([]);
        }
      } finally {
        if (!cancelled) {
          settleNewsLoading(startedAt);
        }
      }
  };

    loadPeptideNews();

    return () => {
      cancelled = true;
    };
}, []);

  // Prepare welcome animation on login
  useEffect(() => {
    if (!user) {
      setShowWelcome(false);
      setShowQuote(false);
      setQuoteOfTheDay(null);
      setQuoteLoading(false);
      return;
    }
    setShowWelcome(false);
    setShowQuote(false);
    setQuoteOfTheDay(null);
    setQuoteLoading(true);
    const timer = window.setTimeout(() => setShowWelcome(true), 250);
    return () => window.clearTimeout(timer);
  }, [user]);

  // Load quote only after welcome animation completes
  useEffect(() => {
    if (!user || !showWelcome || infoFocusActive || showQuote) {
      return;
    }

    let cancelled = false;
    const loadQuote = async () => {
      try {
        const quote = await quotesAPI.getQuoteOfTheDay();
        if (!cancelled) {
          setQuoteOfTheDay(quote);
        }
      } catch (error) {
        console.warn('[Quotes] Failed to load quote of the day', error);
        if (!cancelled) {
          setQuoteOfTheDay({ text: "Excellence is not a skill, it's an attitude.", author: 'Ralph Marston' });
        }
      } finally {
        if (!cancelled) {
          setQuoteLoading(false);
          setShowQuote(true);
        }
      }
    };

    loadQuote();
    return () => {
      cancelled = true;
    };
  }, [user, showWelcome, infoFocusActive, showQuote]);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const handleResize = () => {
      setIsDesktopLandingLayout(window.innerWidth >= 1024);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    setFilters((prev) => {
      const nextCategories = prev.categories.filter((category) => catalogCategories.includes(category));
      if (nextCategories.length === prev.categories.length && prev.types.length === 0) {
        return prev;
      }
      return {
        ...prev,
        categories: nextCategories,
        types: [],
      };
    });
  }, [catalogCategories]);

  useEffect(() => {
    if (!user) {
      setDoctorSummary(null);
      setDoctorReferrals([]);
      setSalesRepDashboard(null);
      setSalesRepStatusFilter('all');
      setAdminActionState({ updatingReferral: null, error: null });
      return;
    }

    if (postLoginHold) {
      return;
    }

    let cancelled = false;

    (async () => {
      if (!cancelled) {
        await refreshReferralData({ showLoading: true });
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user, postLoginHold, refreshReferralData]);

  // Set body classes to control background per view
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const isNonLoginView = Boolean(user) && !postLoginHold;
    const isLoginView = !user;
    document.body.classList.toggle('non-login-bg', isNonLoginView);
    document.body.classList.toggle('login-view', isLoginView);
    return () => {
      document.body.classList.remove('non-login-bg');
      document.body.classList.remove('login-view');
    };
  }, [user, postLoginHold]);

  useEffect(() => {
    if (!user || user.role !== 'sales_rep' || postLoginHold) {
      return undefined;
    }

    const intervalId = window.setInterval(() => {
      refreshReferralData({ showLoading: false });
    }, 15000);

    return () => window.clearInterval(intervalId);
  }, [user?.id, user?.role, postLoginHold, refreshReferralData]);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      return undefined;
    }

    if (!user || user.role !== 'doctor' || postLoginHold) {
      return undefined;
    }

    let cancelled = false;

    const refreshIfActive = () => {
      if (!cancelled) {
        refreshReferralData({ showLoading: false });
      }
    };

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        refreshIfActive();
      }
    };

    const handleFocus = () => {
      refreshIfActive();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);

    const intervalId = window.setInterval(() => {
      refreshIfActive();
    }, 15000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, [user?.id, user?.role, postLoginHold, refreshReferralData]);

  useEffect(() => () => {
    if (checkoutButtonObserverRef.current) {
      checkoutButtonObserverRef.current.disconnect();
      checkoutButtonObserverRef.current = null;
    }
  }, []);

  // Add springy scroll effect to sidebar - DISABLED to allow normal scrolling
  // useEffect(() => {
  //   let lastScrollY = window.scrollY;
  //   let ticking = false;

  //   const handleScroll = () => {
  //     if (!ticking) {
  //       window.requestAnimationFrame(() => {
  //         const sidebar = document.querySelector('.filter-sidebar-container > *') as HTMLElement;
  //         if (sidebar && window.innerWidth >= 1024) {
  //           const currentScrollY = window.scrollY;
  //           const scrollDelta = currentScrollY - lastScrollY;
  //           const maxOffset = 40;
  //           const offset = Math.max(-maxOffset, Math.min(maxOffset, scrollDelta * 0.8));

  //           sidebar.style.transform = `translateY(${-offset}px)`;

  //           setTimeout(() => {
  //             sidebar.style.transform = 'translateY(0)';
  //           }, 150);

  //           lastScrollY = currentScrollY;
  //         }
  //         ticking = false;
  //       });
  //       ticking = true;
  //     }
  //   };

  //   window.addEventListener('scroll', handleScroll, { passive: true });
  //   return () => window.removeEventListener('scroll', handleScroll);
  // }, []);

  useEffect(() => {
    const closeAllDialogs = () => {
      setProductDetailOpen(false);
      setSelectedProduct(null);
      setCheckoutOpen(false);
    };
    window.addEventListener('peppro:close-dialogs', closeAllDialogs);
    return () => window.removeEventListener('peppro:close-dialogs', closeAllDialogs);
  }, []);


  const loginWithRetry = async (email: string, password: string, attempt = 0): Promise<AuthActionResult> => {
    console.debug('[Auth] Login attempt', { email, attempt });
    try {
      const user = await authAPI.login(email, password);
      applyLoginSuccessState(user);
      void storePasswordCredential(email, password, user.name || email);
      console.debug('[Auth] Login success', { userId: user.id, visits: user.visits });
      return { status: 'success' };
    } catch (error: any) {
      console.warn('[Auth] Login failed', { email, error });
      const message = error.message || 'LOGIN_ERROR';

      if (message === 'EMAIL_NOT_FOUND') {
        return { status: 'email_not_found' };
      }

      if (message === 'INVALID_PASSWORD') {
        return { status: 'invalid_password' };
      }

      if (message === 'SALES_REP_ACCOUNT_REQUIRED') {
        return { status: 'sales_rep_signup_required', message };
      }

      const statusCode = typeof error?.status === 'number' ? error.status : null;
      const normalizedMessage = typeof message === 'string' ? message.toUpperCase() : '';
      const isNetworkError =
        message === 'Failed to fetch' ||
        normalizedMessage.includes('NETWORKERROR') ||
        normalizedMessage.includes('NETWORK_ERROR');
      const isServerError = statusCode !== null && statusCode >= 500;

      if (attempt === 0 && (isNetworkError || isServerError)) {
        console.warn('[Auth] Transient login failure detected, warming API then retrying', { email, statusCode, message });
        try {
          await Promise.race([
            checkServerHealth(),
            new Promise((resolve) => setTimeout(resolve, 1000))
          ]);
        } catch {
          // ignore health check failures, we'll still retry once
        }
        await new Promise((resolve) => setTimeout(resolve, 350));
        return loginWithRetry(email, password, attempt + 1);
      }

      if (message === 'Invalid credentials' || message === 'INVALID_CREDENTIALS') {
        try {
          const result = await authAPI.checkEmail(email);
          return result.exists ? { status: 'invalid_password' } : { status: 'email_not_found' };
        } catch (lookupError: any) {
          return { status: 'email_not_found' };
        }
      }

      if (message === 'EMAIL_REQUIRED') {
        return { status: 'error', message };
      }

      return { status: 'error', message };
    }
  };

  // Login function connected to backend
  const resetLandingNpiState = useCallback(() => {
    landingNpiCheckIdRef.current += 1;
    setLandingNpiStatus('idle');
    setLandingNpiMessage('');
    landingNpiRecordRef.current = null;
  }, []);

  const handleLandingNpiInputChange = useCallback((rawValue: string) => {
    const digits = (rawValue || '').replace(/[^0-9]/g, '').slice(0, 10);
    if (digits.length < 10) {
      console.debug('[NPI] Waiting for 10 digits before verification', { digits });
      landingNpiCheckIdRef.current += 1;
      setLandingNpiStatus('idle');
      setLandingNpiMessage('');
      landingNpiRecordRef.current = null;
      return;
    }

    const checkId = Date.now();
    landingNpiCheckIdRef.current = checkId;
    console.debug('[NPI] Verifying against CMS registry', { npiNumber: digits, checkId });
    setLandingNpiStatus('checking');
    setLandingNpiMessage('');

    authAPI.verifyNpi(digits)
      .then((record: any) => {
        if (landingNpiCheckIdRef.current !== checkId) {
          return;
        }
        console.debug('[NPI] Verified successfully', { npiNumber: digits });
        const derivedName = (() => {
          if (record?.name && typeof record.name === 'string') {
            return record.name.trim();
          }
          const basic = record?.raw?.basic;
          if (basic) {
            const parts = [basic.first_name, basic.middle_name, basic.last_name]
              .map((part: string | undefined) => part?.trim())
              .filter(Boolean);
            if (parts.length) {
              return parts.join(' ');
            }
          }
          return null;
        })();
        const resolvedRecord = record ?? {};
        landingNpiRecordRef.current = {
          ...resolvedRecord,
          name: derivedName ?? (typeof resolvedRecord.name === 'string' ? resolvedRecord.name : null),
          verifiedNpiNumber: digits,
        };
        setLandingNpiStatus('verified');
        setLandingNpiMessage('NPI verified with the CMS registry.');
      })
      .catch((error: any) => {
        if (landingNpiCheckIdRef.current !== checkId) {
          return;
        }
        console.warn('[NPI] Verification failed', { npiNumber: digits, error });
        const message = describeNpiErrorMessage(error?.message);
        setLandingNpiStatus('rejected');
        setLandingNpiMessage(message);
        landingNpiRecordRef.current = null;
      });
  }, []);

  const updateLandingAuthMode = useCallback((mode: 'login' | 'signup') => {
    setLandingAuthMode(mode);
    resetLandingNpiState();
  }, [resetLandingNpiState]);

  const handleLogin = (email: string, password: string): Promise<AuthActionResult> => {
    return loginWithRetry(email, password, 0);
  };

  // Create account function connected to backend
  const handleCreateAccount = async (details: {
    name: string;
    email: string;
    password: string;
    confirmPassword: string;
    code: string;
    npiNumber: string;
  }): Promise<AuthActionResult> => {
    console.debug('[Auth] Create account attempt', { email: details.email });
    try {
      const password = (details.password || '').trim();
      const confirmPassword = (details.confirmPassword || '').trim();

      if (!password) {
        return { status: 'error', message: 'PASSWORD_REQUIRED' };
      }

      if (password !== confirmPassword) {
        return { status: 'password_mismatch' };
      }

      const normalizedCode = (details.code || '').trim().toUpperCase();

      if (!/^[A-Z]{2}[A-Z0-9]{3}$/.test(normalizedCode)) {
        return { status: 'invalid_referral_code' };
      }

      const normalizedNpi = (details.npiNumber || '').replace(/\D/g, '');
      if (normalizedNpi && !/^\d{10}$/.test(normalizedNpi)) {
        return { status: 'invalid_npi' };
      }

      if (normalizedNpi) {
        const verifiedRecord = landingNpiRecordRef.current;
        if (!verifiedRecord || verifiedRecord.verifiedNpiNumber !== normalizedNpi) {
          return { status: 'error', message: 'Please verify your NPI before continuing.' };
        }
        if (verifiedRecord.name && !namesRoughlyMatch(details.name, verifiedRecord.name)) {
          return { status: 'error', message: 'Ensure your name is exactly as stated on your NPI registry.' };
        }
      }

      const user = await authAPI.register({
        name: details.name,
        email: details.email,
        password,
        code: normalizedCode,
        npiNumber: normalizedNpi || undefined,
      });
      setUser(user);
      setPostLoginHold(true);
      setIsReturningUser(false);
      // toast.success(`Welcome to PepPro, ${user.name}!`);
      console.debug('[Auth] Create account success', { userId: user.id });
      setLoginContext(null);
      setShowLandingLoginPassword(false);
      setShowLandingSignupPassword(false);
      setShowLandingSignupConfirm(false);
      return { status: 'success' };
    } catch (error: any) {
      const status = error?.status ?? 'unknown';
      const detailsPayload = error?.details ?? null;
      console.warn('[Auth] Create account failed', {
        email: details.email,
        status,
        message: error?.message,
        details: detailsPayload,
      });
      const message =
        typeof error?.message === 'string' && error.message.trim()
          ? error.message.trim()
          : 'REGISTER_ERROR';
      if (message === 'EMAIL_EXISTS' || message === 'User already exists') {
        return { status: 'email_exists' };
      }
      if (message === 'INVALID_REFERRAL_CODE') {
        return { status: 'invalid_referral_code' };
      }
      if (message === 'REFERRAL_CODE_NOT_FOUND') {
        return { status: 'referral_code_not_found' };
      }
      if (message === 'REFERRAL_CODE_UNAVAILABLE') {
        return { status: 'referral_code_unavailable' };
      }
      if (message === 'SALES_REP_EMAIL_MISMATCH') {
        return { status: 'sales_rep_email_mismatch' };
      }
      if (message === 'NAME_EMAIL_REQUIRED') {
        return { status: 'name_email_required' };
      }
      if (message === 'PASSWORD_REQUIRED') {
        return { status: 'error', message };
      }
      if (message === 'NPI_INVALID') {
        return { status: 'invalid_npi' };
      }
      if (message === 'NPI_NOT_FOUND') {
        return { status: 'npi_not_found' };
      }
      if (message === 'NPI_NAME_MISMATCH') {
        return { status: 'error', message: 'Ensure your name is exactly as stated on your NPI registry.' };
      }
      if (message === 'NPI_ALREADY_REGISTERED') {
        return { status: 'npi_already_registered' };
      }
      if (message === 'NPI_LOOKUP_FAILED') {
        return { status: 'npi_verification_failed', message };
      }
      return { status: 'error', message };
    }
  };

  const handleLogout = () => {
    console.debug('[Auth] Logout');
    authAPI.logout();
    setUser(null);
    setLoginContext(null);
    setPostLoginHold(false);
    setIsReturningUser(false);
    setCheckoutOpen(false);
    setShouldReopenCheckout(false);
    setShouldAnimateInfoFocus(false);
    setDoctorSummary(null);
    setDoctorReferrals([]);
    setSalesRepDashboard(null);
    setReferralStatusMessage(null);
    setReferralDataError(null);
    setAdminActionState({ updatingReferral: null, error: null });
    // toast.success('Logged out successfully');
  };

  const buildCartItemId = (productId: string, variantId?: string | null) =>
    variantId ? `${productId}::${variantId}` : productId;

  const handleAddToCart = (productId: string, quantity = 1, note?: string, variantId?: string | null) => {
    console.debug('[Cart] Add to cart requested', { productId, quantity, note, variantId });
    const product = catalogProducts.find((item) => item.id === productId);
    if (!product) return;

    const quantityToAdd = Math.max(1, Math.floor(quantity));
    let resolvedVariant: ProductVariant | null = null;

    if (product.variants?.length) {
      resolvedVariant = variantId
        ? product.variants.find((variant) => variant.id === variantId) ?? null
        : product.variants.find((variant) => variant.inStock) ?? product.variants[0] ?? null;

      if (!resolvedVariant) {
        console.warn('[Cart] Variant selection required, opening product details', { productId, variantId });
        setSelectedProduct(product);
        setProductDetailOpen(true);
        return;
      }
    }

    const cartItemId = buildCartItemId(productId, resolvedVariant?.id ?? null);

    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === cartItemId);
      if (existingItem) {
        return prev.map((item) =>
          item.id === cartItemId
            ? {
              ...item,
              quantity: item.quantity + quantityToAdd,
              note: note ?? item.note,
            }
            : item,
        );
      }
      return [...prev, { id: cartItemId, product, quantity: quantityToAdd, note, variant: resolvedVariant }];
    });

    console.debug('[Cart] Add to cart success', { productId, variantId: resolvedVariant?.id, quantity: quantityToAdd });
  };

  const handleRefreshNews = async () => {
    beginNewsLoading();
    setPeptideNewsError(null);
    const startedAt = Date.now();

    try {
      const data = await newsAPI.getPeptideHeadlines();
      const items = Array.isArray(data?.items)
        ? data.items
          .map((item: any) => ({
            title: typeof item?.title === 'string' ? item.title.trim() : '',
            url: typeof item?.url === 'string' ? item.url.trim() : '',
            summary: typeof item?.summary === 'string' && item.summary.trim() ? item.summary.trim() : undefined,
            image: typeof item?.imageUrl === 'string' && item.imageUrl.trim() ? item.imageUrl.trim() : undefined,
            date: typeof item?.date === 'string' && item.date.trim() ? item.date.trim() : undefined,
          }))
          .filter((item) => item.title && item.url)
        : [];

      if (items.length === 0) {
        setPeptideNews([]);
        setPeptideNewsError('No headlines available right now.');
        setPeptideNewsUpdatedAt(new Date());
        return;
      }
      setPeptideNews(items.slice(0, 6));
      setPeptideNewsUpdatedAt(new Date());
    } catch (error) {
      console.warn('[News] Failed to refresh peptide headlines', error);
      setPeptideNewsError('Unable to load peptide news at the moment.');
      setPeptideNews([]);
    } finally {
      settleNewsLoading(startedAt);
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleCheckout = async (referralCode?: string) => {
    console.debug('[Checkout] Attempt', { items: cartItems.length, referralCode });
    if (cartItems.length === 0) {
      // toast.error('Your cart is empty');
      return;
    }

    const items = cartItems.map(({ id, product, quantity, note, variant }, index) => ({
      cartItemId: id,
      productId: product.id,
      variantId: variant?.id ?? null,
      name: variant ? `${product.name} — ${variant.label}` : product.name,
      price: variant?.price ?? product.price,
      quantity,
      note: note ?? null,
      position: index + 1,
    }));

    const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

    try {
      const response = await ordersAPI.create(items, total, referralCode);
      await loadAccountOrders().catch(() => undefined);
      return response;
    } catch (error: any) {
      console.error('[Checkout] Failed', { error });
      const message = error?.message === 'Request failed'
        ? 'Unable to complete purchase. Please try again.'
        : error?.message ?? 'Unable to complete purchase. Please try again.';
      throw new Error(message);
    }
  };

  const handleRequireLogin = () => {
    console.debug('[Checkout] Require login triggered');
    setCheckoutOpen(false);
    setLoginPromptToken((token) => token + 1);
    setShouldReopenCheckout(true);
    setLoginContext('checkout');
    updateLandingAuthMode('login');
    QueueMicrotask(() => window.scrollTo({ top: 0, behavior: 'smooth' }));
  };

  const handleAdvanceFromWelcome = () => {
    console.debug('[Intro] Advance from welcome', { shouldReopenCheckout });
    setPostLoginHold(false);
    if (shouldReopenCheckout) {
      setCheckoutOpen(true);
      setShouldReopenCheckout(false);
    }
  };

  const handleUpdateCartItemQuantity = (cartItemId: string, quantity: number) => {
    console.debug('[Cart] Update quantity', { cartItemId, quantity });
    const normalized = Math.max(1, Math.floor(quantity || 1));
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === cartItemId
          ? { ...item, quantity: normalized }
          : item
      )
    );
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    console.debug('[Cart] Remove item', { cartItemId });
    setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
    // toast.success('Item removed from cart');
  };

  const submitReferralWithRetry = async (
    payload: { contactName: string; contactEmail?: string; contactPhone?: string; notes?: string },
    attempt = 0
  ): Promise<void> => {
    try {
      await referralAPI.submitDoctorReferral(payload);
    } catch (error: any) {
      const statusCode = typeof error?.status === 'number' ? error.status : null;
      const message = typeof error?.message === 'string' ? error.message : '';
      const normalizedMessage = message.toUpperCase();
      const isNetworkError =
        message === 'Failed to fetch' ||
        normalizedMessage.includes('NETWORKERROR') ||
        normalizedMessage.includes('NETWORK_ERROR');
      const isServerError = statusCode !== null && statusCode >= 500;

      if (attempt === 0 && (isNetworkError || isServerError)) {
        console.warn('[Referral] Transient submission failure detected, warming API then retrying', {
          statusCode,
          message
        });
        try {
          await Promise.race([
            checkServerHealth(),
            new Promise((resolve) => setTimeout(resolve, 1000))
          ]);
        } catch {
          // ignore health check failures and continue to retry once
        }
        await new Promise((resolve) => setTimeout(resolve, 350));
        await submitReferralWithRetry(payload, attempt + 1);
        return;
      }

      throw error;
    }
  };

  const handleSubmitReferral = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user || user.role !== 'doctor') {
      return;
    }

    if (!referralForm.contactName.trim()) {
      setReferralStatusMessage({ type: 'error', message: 'Please provide the doctor’s name before submitting.' });
      return;
    }

    try {
      setReferralSubmitting(true);
      setReferralStatusMessage(null);
      await submitReferralWithRetry({
        contactName: referralForm.contactName.trim(),
        contactEmail: referralForm.contactEmail.trim() || undefined,
        contactPhone: referralForm.contactPhone.trim() || undefined,
        notes: referralForm.notes.trim() || undefined,
      });
      setReferralStatusMessage({ type: 'success', message: 'Referral sent to your regional administrator.' });
      setReferralForm({ contactName: '', contactEmail: '', contactPhone: '', notes: '' });
      setReferralSearchTerm('');
      await refreshReferralData({ showLoading: true });
    } catch (error: any) {
      console.warn('[Referral] Submission failed', error);
      setReferralStatusMessage({ type: 'error', message: 'Unable to submit referral. Please try again.' });
    } finally {
      setReferralSubmitting(false);
    }
  };

  const handleUpdateReferralStatus = async (referralId: string, nextStatus: string) => {
    if (!user || user.role !== 'sales_rep') {
      return;
    }

    try {
      setAdminActionState((prev) => ({ ...prev, updatingReferral: referralId, error: null }));
      const response = await referralAPI.updateReferral(referralId, { status: nextStatus });
      setSalesRepDashboard((prev) => {
        if (!prev) {
          return prev;
        }
        const updatedReferral = response?.referral;
        const statuses = (response?.statuses as string[] | undefined) ?? prev.statuses;
        if (!updatedReferral) {
          return { ...prev, statuses };
        }
        const updatedReferrals = prev.referrals.map((item) =>
          item.id === updatedReferral.id ? updatedReferral : item
        );
        return {
          ...prev,
          referrals: updatedReferrals,
          statuses,
        };
      });
    } catch (error: any) {
      console.warn('[Referral] Update referral status failed', error);
      setAdminActionState((prev) => ({
        ...prev,
        error:
          typeof error?.message === 'string' && error.message
            ? error.message
            : 'Unable to update referral status. Please try again.',
      }));
    } finally {
      setAdminActionState((prev) => ({ ...prev, updatingReferral: null }));
    }
  };

  
const renderDoctorDashboard = () => {
  if (!user || user.role !== 'doctor') {
    return null;
  }

  const totalCredits = doctorSummary?.totalCredits ?? Number(user.referralCredits ?? 0);
  const firstOrderBonuses = doctorSummary?.firstOrderBonuses ?? 0;
  const totalReferrals = user.totalReferrals ?? doctorReferrals.length ?? 0;
  const recentLedger = (doctorSummary?.ledger ?? [])
    .slice()
    .sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime())
    .slice(0, 5);

  const renderReferralHubTrigger = (expanded: boolean) => {
    const baseTriggerClasses =
      'group glass-card referral-pill squircle-xl flex w-full items-center justify-between gap-4 pr-5 py-4 text-left transition-all';
    const triggerClasses = expanded
      ? `${baseTriggerClasses} shadow-md`
      : `${baseTriggerClasses} shadow-[0_18px_48px_-28px_rgba(95,179,249,0.8)] hover:shadow-[0_20px_52px_-24px_rgba(95,179,249,0.85)]`;

    return (
      <button
        type="button"
        className={triggerClasses}
        onClick={() => setIsReferralSectionExpanded((prev) => !prev)}
        aria-expanded={expanded}
        aria-label={expanded ? 'Collapse Referral Rewards Hub' : 'Expand Referral Rewards Hub'}
        style={{ borderWidth: '2px', borderColor: 'var(--brand-glass-border-2)', paddingLeft: '1rem', borderRadius: '24px' }}
      >
        <div className="flex items-center gap-6 flex-shrink-0 pl-4 ml-2">
          <div
            className={`flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-600 transition-all duration-300 group-hover:bg-slate-200 ${
              expanded ? 'shadow-inner' : ''
            }`}
          >
            <ChevronRight
              className="h-5 w-5"
              style={{
                transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)',
                transition: 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                transformOrigin: 'center'
              }}
            />
          </div>
          <div className="hidden sm:block">
            <p className="text-sm font-semibold text-slate-700">Referral Rewards Hub</p>
            <p className="text-xs text-slate-500">Invite doctors & track credited referrals</p>
          </div>
        </div>

        <div className="flex flex-1 items-center justify-end gap-2">
          <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
          </svg>
          <p className="text-lg font-medium text-slate-700">Refer your colleagues</p>
        </div>
      </button>
    );
  };

  const renderExpandedContent = () => (
    <div
      className="overflow-hidden transition-all duration-500 ease-in-out"
      style={{
        maxHeight: isReferralSectionExpanded ? '5000px' : '0',
        opacity: isReferralSectionExpanded ? 1 : 0,
      }}
    >
      <div className="px-16 pb-8 space-y-8 squircle-xl" style={{ padding: '1rem 1rem 1rem' }}>
        {referralDataError && (
          <div className="px-4 py-3 text-sm text-red-700">
            <div className="flex items-center justify-center gap-2">
              <svg className="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <span>{referralDataError}</span>
            </div>
          </div>
        )}

        <div className="glass squircle-lg p-8 ml-5 mr-5 shadow-sm space-y-6">
          <form className="glass-strong squircle-md p-6 space-y-3" onSubmit={handleSubmitReferral}>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="mb-1 block text-xs font-medium text-slate-700" htmlFor="referral-contact-name">Colleague Name *</label>
                <input
                  id="referral-contact-name"
                  type="text"
                  required
                  value={referralForm.contactName}
                  onChange={(event) => setReferralForm((prev) => ({ ...prev, contactName: event.target.value }))}
                  className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700" htmlFor="referral-contact-email">Email</label>
                <input
                  id="referral-contact-email"
                  type="email"
                  value={referralForm.contactEmail}
                  onChange={(event) => setReferralForm((prev) => ({ ...prev, contactEmail: event.target.value }))}
                  className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700" htmlFor="referral-contact-phone">Phone</label>
                <input
                  id="referral-contact-phone"
                  type="tel"
                  value={referralForm.contactPhone}
                  onChange={(event) => setReferralForm((prev) => ({ ...prev, contactPhone: event.target.value }))}
                  className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1 block text-xs font-medium text-slate-700" htmlFor="referral-notes">Notes</label>
                <textarea
                  id="referral-notes"
                  value={referralForm.notes}
                  onChange={(event) => setReferralForm((prev) => ({ ...prev, notes: event.target.value }))}
                  className="w-full min-h-[70px] rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
            </div>
            <div className="pt-1 flex w-full justify-end">
              <div className="inline-flex flex-wrap items-center justify-end gap-3 text-right sm:flex-nowrap">
                <p className="text-sm text-slate-600 max-w-[24ch] sm:max-w-[26ch]">
                  Your regional administrator will credit you $50 each time your new referee has completed their first checkout.
                </p>
                <Button
                  type="submit"
                  disabled={referralSubmitting}
                  className="glass-brand squircle-sm transition-all duration-300 hover:scale-105 hover:-translate-y-0.5 active:translate-y-0"
                >
                  {referralSubmitting ? 'Submitting…' : 'Submit Referral'}
                </Button>
                {referralStatusMessage && (
                  <span className={`text-sm ${referralStatusMessage.type === 'success' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {referralStatusMessage.message}
                  </span>
                )}
              </div>
            </div>
          </form>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <div className="glass squircle-lg p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center squircle-sm bg-emerald-100">
                <svg className="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-base font-semibold text-slate-800">Your Referrals</h3>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Total Referrals</p>
                <p className="text-lg font-bold text-emerald-600">{totalReferrals}</p>
              </div>
              {referralDataLoading && (
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <svg className="animate-spin h-3 w-3" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Loading…
                </span>
              )}
            </div>
          </div>
          {doctorReferrals.length === 0 ? (
            <div className="text-center py-8 glass-strong squircle-md">
              <div className="flex justify-center mb-3">
                <div className="flex h-12 w-12 items-center justify-center squircle-sm bg-slate-100">
                  <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-sm text-slate-600">No referrals yet</p>
              <p className="text-xs text-slate-500 mt-1">Submit your first referral above to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="referral-toolbar">
                <div className="referral-toolbar__search">
                  <input
                    type="search"
                    value={referralSearchTerm}
                    onChange={(event) => setReferralSearchTerm(event.target.value)}
                    placeholder="Search by name or email"
                    aria-label="Search referrals"
                    className="referral-search-input"
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleReferralSortToggle}
                  aria-pressed={referralSortOrder === 'desc'}
                  className="referral-sort-toggle"
                >
                  <ArrowUpDown className="h-4 w-4 mr-2" />
                  {sortDirectionLabel}
                </Button>
              </div>
              <div className="referrals-table-scroll">
                <div className="referrals-table-container glass-card squircle-xl">
                  {filteredDoctorReferrals.length === 0 ? (
                    <div className="referrals-empty-state">
                      <p className="text-sm text-slate-600">No referrals match your search.</p>
                      <p className="text-xs text-slate-500 mt-1">Try adjusting your filters or search terms.</p>
                    </div>
                  ) : (
                    <div className="referrals-table" role="table" aria-label="Your referrals">
                      <div className="referrals-table__header" role="row">
                        <span role="columnheader">Colleague</span>
                        <span role="columnheader">Submitted</span>
                        <span role="columnheader">Status</span>
                      </div>
                      <div className="referrals-table__body" role="rowgroup">
                        {filteredDoctorReferrals.map((referral) => (
                          <div key={referral.id} className="referrals-table__row" role="row">
                            <div className="referrals-table__cell" role="cell">
                              <div className="referral-contact">
                                <span className="referral-contact__name">{referral.referredContactName}</span>
                                {(referral.referredContactEmail || referral.referredContactPhone) && (
                                  <span className="referral-contact__meta">
                                    {referral.referredContactEmail || referral.referredContactPhone}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="referrals-table__cell referrals-table__cell--date" role="cell">
                              <span className="referral-date">{formatDate(referral.createdAt)}</span>
                              <span className="referral-date-updated">Updated {formatDateTime(referral.updatedAt ?? referral.createdAt)}</span>
                            </div>
                            <div className="referrals-table__cell" role="cell">
                              <span className="referral-status-badge">
                                {humanizeReferralStatus(referral.status ?? 'pending')}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          </div>

          <div className="glass squircle-lg p-8 shadow-sm min-w-0 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center squircle-sm bg-amber-100">
                <svg className="w-4 h-4 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-base font-semibold text-slate-800">Recent Credit Activity</h3>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">Total Credits</p>
                <p className="text-lg font-bold text-emerald-600">${totalCredits.toFixed(2)}</p>
              </div>
              {recentLedger.length > 0 && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
                  <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                  </svg>
                  {recentLedger.length} recent
                </span>
              )}
            </div>
          </div>

          {recentLedger.length === 0 ? (
            <div className="text-center py-8 glass-strong squircle-md">
              <div className="flex justify-center mb-3">
                <div className="flex h-12 w-12 items-center justify-center squircle-sm bg-slate-100">
                  <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
              </div>
              <p className="text-sm text-slate-600">No credit activity yet</p>
              <p className="text-xs text-slate-500 mt-1">Credits appear after your referrals place their first order</p>
            </div>
          ) : (
            <ul className="space-y-2.5">
              {recentLedger.map((entry) => (
                <li key={entry.id} className="group relative glass-strong squircle-md p-5 shadow-sm transition-all hover:shadow-md">
                  <div className="relative flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="text-lg font-bold text-emerald-600">${entry.amount.toFixed(2)}</span>
                      </div>
                      {entry.description && (
                        <p className="text-sm text-slate-600 leading-relaxed">{entry.description}</p>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-xs font-medium text-slate-500 whitespace-nowrap">{formatDate(entry.issuedAt)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <section className="grid gap-6 mb-16 mt-0">
      <div
        className={`glass-card squircle-xl referral-pill-wrapper transition-all duration-500 ${
          isReferralSectionExpanded
            ? 'pb-8 shadow-[0_30px_80px_-65px_rgba(95,179,249,0.8)]'
            : 'shadow-[0_18px_48px_-28px_rgba(95,179,249,0.8)] hover:shadow-[0_20px_52px_-24px_rgba(95,179,249,0.85)]'
        }`}
        style={{ borderRadius: '24px' }}
      >
        {renderReferralHubTrigger(isReferralSectionExpanded)}
        {renderExpandedContent()}
      </div>
    </section>
  );
};

const renderProductSection = () => (
  <div className="products-layout mt-24">
    {/* Filters Sidebar */}
    <div
      ref={filterSidebarRef}
      className="filter-sidebar-container lg:min-w-[18rem] lg:max-w-[24rem] xl:min-w-[20rem] xl:max-w-[26rem] lg:pl-4 xl:pl-6"
    >
      <CategoryFilter
        categories={catalogCategories}
        types={[]}
        filters={filters}
        onFiltersChange={setFilters}
        productCounts={productCounts}
        typeCounts={{}}
      />
    </div>

    {/* Products Grid */}
    <div className="w-full min-w-0 flex-1">
      <div className="flex flex-wrap lg:flex-nowrap items-center gap-3 mb-6">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-0">
          <h2>Products</h2>
          <Badge variant="outline" className="squircle-sm glass">
            {filteredProducts.length} items
          </Badge>
          {stripeIsTestMode && (
            <Badge variant="outline" className="squircle-sm glass bg-green-100 text-green-700 border-green-200">
              Stripe Test Mode
            </Badge>
          )}
          {searchQuery && (
            <Badge variant="outline" className="squircle-sm">
              Search: "{searchQuery}"
            </Badge>
          )}
          {catalogLoading && (
            <Badge variant="outline" className="squircle-sm glass">
              Syncing…
            </Badge>
          )}
          {catalogError && (
            <Badge variant="destructive" className="squircle-sm">
              Woo sync issue
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-3 ml-auto min-w-[min(100%,220px)] justify-end">
          <div className="flex items-center gap-2 sm:gap-3">
            <Button
              variant="outline"
              aria-pressed={viewMode === 'grid'}
              onClick={() => setViewMode('grid')}
              className={`squircle-sm transition-all duration-300 ease-out flex items-center justify-center ${
                viewMode === 'grid'
                  ? 'h-12 w-12 sm:h-14 sm:w-14 ring-2 ring-primary/60 glass shadow-[0_24px_60px_-36px_rgba(95,179,249,0.45)] text-[rgb(95,179,249)]'
                  : 'h-10 w-10 sm:h-8.5 sm:w-8.5 opacity-70 glass shadow-[0_6px_16px_-14px_rgba(95,179,249,0.25)] text-[rgb(95,179,249)]'
              }`}
            >
              <Grid className={`transition-transform duration-300 ${viewMode === 'grid' ? 'scale-110' : 'scale-95'}`} />
            </Button>
            <Button
              variant="outline"
              onClick={() => setViewMode('list')}
              aria-pressed={viewMode === 'list'}
              className={`squircle-sm transition-all duration-300 ease-out flex items-center justify-center ${
                viewMode === 'list'
                  ? 'h-12 w-12 sm:h-14 sm:w-14 ring-2 ring-primary/60 glass shadow-[0_24px_60px_-36px_rgba(95,179,249,0.45)] text-[rgb(95,179,249)]'
                  : 'h-10 w-10 sm:h-8.5 sm:w-8.5 opacity-70 glass shadow-[0_6px_16px_-14px_rgba(95,179,249,0.25)] text-[rgb(95,179,249)]'
              }`}
            >
              <List className={`transition-transform duration-300 ${viewMode === 'list' ? 'scale-110' : 'scale-95'}`} />
            </Button>
          </div>

          {totalCartItems > 0 && (
            <Button
              variant="ghost"
              onClick={() => setCheckoutOpen(true)}
              ref={checkoutButtonRef}
              className="squircle-sm glass-brand shadow-lg shadow-[rgba(95,179,249,0.4)] transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 px-5 py-2 min-w-[8.5rem] justify-center"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Checkout ({totalCartItems})
            </Button>
          )}
        </div>
      </div>

      {filteredProducts.length > 0 ? (
        <div
          className={`grid gap-6 w-full pr-4 ${
            viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'
          }`}
        >
          {filteredProducts.map((product) => {
            const cardProduct = toCardProduct(product);
            return (
              <ProductCard
                key={product.id}
                product={cardProduct}
                layout={viewMode}
                onAddToCart={(productId, variationId, qty) =>
                  handleAddToCart(productId, qty, undefined, variationId)}
              />
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="glass-card squircle-lg p-8 max-w-md mx-auto">
            <h3 className="mb-2">No products found</h3>
            <p className="text-gray-600">Try adjusting your filters or search terms.</p>
          </div>
        </div>
      )}
    </div>
  </div>
);

const renderSalesRepDashboard = () => {
  if (!user || user.role !== 'sales_rep') {
    return null;
  }

  const referrals = salesRepDashboard?.referrals ?? [];
  const statusOptions = Array.from(
    new Set([
      ...salesRepStatusOptions,
      ...referrals.map((referral) => (referral.status || '').trim()).filter(Boolean),
    ]),
  ).filter(Boolean);
  statusOptions.sort();

  const totalReferrals = referrals.length;
  const activeStatuses = new Set(['pending', 'contacted', 'follow_up', 'code_issued']);
  const activeReferrals = referrals.filter((ref) => activeStatuses.has((ref.status || '').toLowerCase())).length;
  const convertedReferrals = referrals.filter((ref) => (ref.status || '').toLowerCase() === 'converted').length;
  const hasChartData = salesRepChartData.some((item) => item.count > 0);

  return (
    <section className="glass-card squircle-xl p-6 shadow-[0_30px_80px_-55px_rgba(95,179,249,0.6)] w-full">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">Sales Rep Dashboard</h2>
            <p className="text-sm text-slate-600">Monitor referral progress and keep statuses in sync.</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <select
              value={salesRepStatusFilter}
              onChange={(event) => setSalesRepStatusFilter(event.target.value)}
              className="rounded-md border border-slate-200/80 bg-white/90 px-3 py-2 text-sm focus:border-[rgb(95,179,249)] focus:outline-none focus:ring-2 focus:ring-[rgba(95,179,249,0.3)]"
            >
              <option value="all">All statuses</option>
              {statusOptions.map((status) => (
                <option key={status} value={status}>
                  {humanizeReferralStatus(status)}
                </option>
              ))}
            </select>
            <Button
              type="button"
              variant="outline"
              onClick={() => refreshReferralData({ showLoading: true })}
              disabled={referralDataLoading}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${referralDataLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <div className="sales-rep-metrics">
              <div className="sales-rep-metric">
                <span className="sales-rep-metric__label">Total</span>
                <span className="sales-rep-metric__value">{totalReferrals}</span>
              </div>
              <div className="sales-rep-metric">
                <span className="sales-rep-metric__label">Active</span>
                <span className="sales-rep-metric__value">{activeReferrals}</span>
              </div>
              <div className="sales-rep-metric">
                <span className="sales-rep-metric__label">Converted</span>
                <span className="sales-rep-metric__value">{convertedReferrals}</span>
              </div>
            </div>
          </div>
        </div>

        {adminActionState.error && (
          <p className="rounded-md border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">
            {adminActionState.error}
          </p>
        )}

        <div className="sales-rep-leads-card">
          <div className="sales-rep-leads-header">
            <div>
              <h3>Referral Leads</h3>
              <p>Review contact details and keep statuses accurate.</p>
            </div>
          </div>
          <div className="sales-rep-table-wrapper">
            <table className="min-w-[720px] divide-y divide-slate-200/70">
              <thead className="bg-slate-50/70">
                <tr className="text-left text-xs uppercase tracking-wide text-slate-500">
                  <th className="px-4 py-3">Referrer</th>
                  <th className="px-4 py-3">Lead</th>
                  <th className="px-4 py-3">Notes from Referrer</th>
                <th className="px-4 py-3 whitespace-nowrap">Submitted</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60">
              {referralDataLoading ? (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-sm text-slate-500">
                    Loading referrals…
                  </td>
                </tr>
              ) : filteredSalesRepReferrals.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-sm text-slate-500">
                    No referrals match this filter.
                  </td>
                </tr>
              ) : (
                filteredSalesRepReferrals.map((referral) => {
                  const isUpdating = adminActionState.updatingReferral === referral.id;
                  const referralStatusOptions = statusOptions.length > 0 ? statusOptions : [referral.status || 'pending'];

                  return (
                    <tr key={referral.id} className="align-top">
                      <td className="px-4 py-4">
                        <div className="font-semibold text-slate-900">{referral.referrerDoctorName ?? '—'}</div>
                        <div className="text-xs text-slate-500">{referral.referrerDoctorEmail ?? '—'}</div>
                        {referral.referrerDoctorPhone && (
                          <div className="text-xs text-slate-500">{referral.referrerDoctorPhone}</div>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        <div className="font-medium text-slate-900">{referral.referredContactName || '—'}</div>
                        {referral.referredContactEmail && (
                          <div className="text-xs text-slate-500">{referral.referredContactEmail}</div>
                        )}
                        {referral.referredContactPhone && (
                          <div className="text-xs text-slate-500">{referral.referredContactPhone}</div>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        {referral.notes ? (
                          <div className="max-w-md text-sm text-slate-600 whitespace-pre-wrap">
                            {referral.notes}
                          </div>
                        ) : (
                          <span className="text-xs italic text-slate-400">No notes</span>
                        )}
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-600">
                        <div>{formatDateTime(referral.createdAt)}</div>
                        <div className="text-xs text-slate-400">Updated {formatDateTime(referral.updatedAt)}</div>
                      </td>
                      <td className="px-4 py-4">
                        <select
                          value={referral.status}
                          onChange={(event) => handleUpdateReferralStatus(referral.id, event.target.value)}
                          disabled={isUpdating}
                          className="w-full rounded-md border border-slate-200/80 bg-white/95 px-3 py-2 text-sm focus:border-[rgb(95,179,249)] focus:outline-none focus:ring-2 focus:ring-[rgba(95,179,249,0.3)]"
                        >
                          {referralStatusOptions.map((status) => (
                            <option key={status} value={status}>
                              {humanizeReferralStatus(status)}
                            </option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  );
                })
              )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="sales-rep-chart-card">
          <div className="sales-rep-chart-header">
            <div>
              <h3>Pipeline</h3>
              <p>Track lead volume as contacts advance through each stage.</p>
            </div>
          </div>
          <div className="sales-rep-chart-body">
            {hasChartData ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={salesRepChartData} margin={{ top: 16, right: 16, left: 0, bottom: 8 }}>
                  <defs>
                    <linearGradient id="statusBar" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#5FB3F9" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#95C5F9" stopOpacity={0.9} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.3)" />
                  <XAxis dataKey="label" interval={0} tick={{ fontSize: 12, fill: '#334155' }} angle={-15} textAnchor="end" height={60} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#334155' }} />
                  <Tooltip cursor={{ fill: 'rgba(148, 163, 184, 0.12)' }} formatter={(value: number) => [`${value} referral${value === 1 ? '' : 's'}`, 'Leads']} />
                  <Bar dataKey="count" radius={[10, 10, 6, 6]} fill="url(#statusBar)" barSize={32} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="sales-rep-chart-empty">
                <p className="text-sm text-slate-600">No referral activity yet. Keep an eye here as leads arrive.</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <p className="text-xs text-slate-500/80 text-center italic">
        Send dashboard recommendations and ideas that will improve your productivity to{' '}
        <a
          className="text-[rgb(95,179,249)] underline-offset-2 hover:underline"
          href="mailto:petergibbons7@icloud.com"
        >
          petergibbons7@icloud.com
        </a>
        .
      </p>
    </section>
  );
};

  const handleViewProduct = (product: Product) => {
    console.debug('[Product] View details', { productId: product.id });
    setSelectedProduct(product);
    setProductDetailOpen(true);
  };

  const handleCloseProductDetail = () => {
    console.debug('[Product] Close details');
    setProductDetailOpen(false);
    setSelectedProduct(null);
  };

  // Filter and search products
  const filteredProductCatalog = useMemo(
    () =>
      catalogProducts.filter((product) => {
        if (product.isSubscription) {
          return false;
        }
        const type = product.type?.toLowerCase() || '';
        const name = product.name?.toLowerCase() || '';
        const category = product.category?.toLowerCase() || '';
        const manufacturer = product.manufacturer?.toLowerCase() || '';
        const sku = product.description?.toLowerCase() || '';
        return !(
          type.includes('subscription') ||
          name.includes('subscription') ||
          category.includes('subscription') ||
          manufacturer.includes('subscription') ||
          sku.includes('subscription')
        );
      }),
    [catalogProducts],
  );

  const filteredProducts = useMemo(() => {
    let filtered = filteredProductCatalog;

    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.manufacturer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (filters.categories.length > 0) {
      filtered = filtered.filter(product => filters.categories.includes(product.category));
    }

    if (filters.inStockOnly) {
      filtered = filtered.filter(product => product.inStock);
    }

    if (filters.types.length > 0) {
      filtered = filtered.filter(product => product.type && filters.types.includes(product.type));
    }

    return filtered;
  }, [filteredProductCatalog, searchQuery, filters]);

  // Get product counts by category
  const productCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    catalogCategories.forEach(category => {
      counts[category] = filteredProductCatalog.filter(product => product.category === category).length;
    });
    return counts;
  }, [filteredProductCatalog, catalogCategories]);

  // Add springy scroll effect to filter sidebar on large screens - DISABLED FOR TESTING
  // useEffect(() => {
  //   let lastScrollY = window.scrollY;
  //   let ticking = false;

  //   const handleScroll = () => {
  //     if (ticking) {
  //       return;
  //     }
  //     window.requestAnimationFrame(() => {
  //       const sidebar = document.querySelector<HTMLDivElement>('.filter-sidebar-container > *');
  //       if (sidebar && window.innerWidth >= 1024) {
  //         const currentScrollY = window.scrollY;
  //         const scrollDelta = currentScrollY - lastScrollY;
  //         const maxOffset = 40;
  //         const offset = Math.max(-maxOffset, Math.min(maxOffset, scrollDelta * 0.8));

  //         sidebar.style.transform = `translateY(${-offset}px)`;

  //         window.setTimeout(() => {
  //           sidebar.style.transform = 'translateY(0)';
  //         }, 150);

  //         lastScrollY = currentScrollY;
  //       }
  //       ticking = false;
  //     });
  //     ticking = true;
  //   };

  //   window.addEventListener('scroll', handleScroll, { passive: true });
  //   return () => window.removeEventListener('scroll', handleScroll);
  // }, []);

  const featuredProducts = filteredProductCatalog.slice(0, 4);
  const quoteReady = showQuote && Boolean(quoteOfTheDay);

  const totalCartItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const shouldShowHeaderCartIcon = totalCartItems > 0 && !isCheckoutButtonVisible;
  const newsLoadingPlaceholders = Array.from({ length: 5 });

  return (
    <div
      className="min-h-screen bg-slate-50 flex flex-col"
      style={{
        position: 'static',
      }}
    >
      {/* Ambient background texture */}
      <div
        aria-hidden="true"
        style={{
          position: 'fixed',
          top: '-12vh',
          left: '-6vw',
          width: '112vw',
          height: '140vh',
          backgroundImage: 'url(/leafTexture.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          zIndex: 0,
          pointerEvents: 'none',
          maskImage: 'linear-gradient(to top, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.15) 33%, rgba(0,0,0,0.075) 66%, rgba(0,0,0,0) 100%)',
          WebkitMaskImage: 'linear-gradient(to top, rgba(0,0,0,0.50) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 50%, rgba(0,0,0,0) 100%)'
        }}
      />
      {infoFocusActive && postLoginHold && user && <div className="info-focus-overlay" aria-hidden="true" />}
      <div className="relative z-10 flex flex-1 flex-col">
        {/* Header - Only show when logged in */}
        {user && !postLoginHold && (
          <Header
            user={user}
            onLogin={handleLogin}
            onLogout={handleLogout}
            cartItems={totalCartItems}
            onSearch={handleSearch}
            onCreateAccount={handleCreateAccount}
            onCartClick={() => setCheckoutOpen(true)}
            loginPromptToken={loginPromptToken}
            loginContext={loginContext}
            showCartIconFallback={shouldShowHeaderCartIcon}
            onShowInfo={() => {
              console.log('[App] onShowInfo called, setting postLoginHold to true');
              setPostLoginHold(true);
            }}
            onUserUpdated={(next) => setUser(next as User)}
            accountOrders={accountOrders}
            accountOrdersLoading={accountOrdersLoading}
            accountOrdersError={accountOrdersError}
            ordersLastSyncedAt={accountOrdersSyncedAt}
            onRefreshOrders={loadAccountOrders}
            accountModalRequest={accountModalRequest}
          />
        )}

        <div className="flex-1 w-full flex flex-col">
          {/* Landing Page - Show when not logged in */}
          {(!user || postLoginHold) && (
            <div className="min-h-screen flex flex-col items-center pt-20 px-4 py-12">
          {/* Logo with Welcome and Quote Containers */}
          {postLoginHold && user ? (
            <div className="w-full max-w-7xl mb-6 px-4">
              {isDesktopLandingLayout ? (
                <div className="flex flex-row items-stretch justify-between gap-4 lg:gap-6 mb-8">
                  <div
                    className={`glass-card squircle-lg border border-[var(--brand-glass-border-2)] px-8 py-6 lg:px-10 lg:py-8 shadow-lg transition-all duration-500 flex items-center justify-center flex-1 info-highlight-card ${infoFocusActive ? 'info-focus-active' : ''} ${
                      showWelcome ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
                    }`}
                    style={{
                      backdropFilter: 'blur(20px) saturate(1.4)',
                      minHeight: 'min(140px, 12.5vh)',
                    }}
                  >
                    <p
                      className={`font-semibold text-[rgb(95,179,249)] text-center shimmer-text ${infoFocusActive ? 'is-shimmering' : 'shimmer-text--cooldown'}`}
                      style={{
                        fontSize: infoFocusActive ? 'clamp(0.94rem, 1.65vw, 1.65rem)' : 'clamp(0.76rem, 1.22vw, 1.22rem)',
                        lineHeight: 1.15,
                        transition: 'font-size 800ms ease',
                      }}
                    >
                      Welcome{user.visits && user.visits > 1 ? ' back' : ''}, {user.name}!
                    </p>
                  </div>

                  <div className="flex-shrink-0 px-6 lg:px-8">
                    <div className="brand-logo brand-logo--landing">
                      <img
                        src="/Peppro_fulllogo.png"
                        alt="PepPro"
                        style={{
                          display: 'block',
                          width: 'auto',
                          height: 'auto',
                          maxWidth: 'min(320px, 35vw)',
                          maxHeight: 'min(280px, 25vh)',
                          objectFit: 'contain'
                        }}
                      />
                    </div>
                  </div>

                  <div
                    className={`glass-card squircle-lg border border-[var(--brand-glass-border-2)] px-8 py-6 lg:px-10 lg:py-8 shadow-lg transition-all duration-500 flex flex-col justify-center flex-1 ${
                      showWelcome ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
                    }`}
                    style={{
                      backdropFilter: 'blur(20px) saturate(1.4)',
                      minHeight: 'min(140px, 12.5vh)',
                    }}
                    aria-live="polite"
                  >
                    {quoteLoading && !quoteReady && (
                      <div className="w-full flex flex-col items-center gap-4">
                        <div className="news-loading-card flex flex-col items-center gap-3 w-full max-w-md">
                          <div className="news-loading-line news-loading-shimmer w-3/4" aria-hidden="true" />
                          <div className="news-loading-line news-loading-shimmer w-1/2" aria-hidden="true" />
                        </div>
                        <p className="text-xs text-slate-500">Loading today&apos;s quote…</p>
                      </div>
                    )}
                    {quoteReady && quoteOfTheDay && (
                      <p className="text-base lg:text-lg italic text-gray-700 text-center">
                        "{quoteOfTheDay.text}" — {quoteOfTheDay.author}
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-6 mb-8">
                  <div className="flex justify-center px-4">
                    <div className="brand-logo brand-logo--landing">
                      <img
                        src="/Peppro_fulllogo.png"
                        alt="PepPro"
                        style={{
                          display: 'block',
                          width: 'auto',
                          height: 'auto',
                          maxWidth: 'min(320px, 35vw)',
                          maxHeight: 'min(280px, 25vh)',
                          objectFit: 'contain'
                        }}
                      />
                    </div>
                  </div>
                  <div
                    className={`glass-card squircle-lg border border-[var(--brand-glass-border-2)] px-4 py-4 shadow-lg transition-all duration-500 w-full info-highlight-card ${infoFocusActive ? 'info-focus-active' : ''} ${
                      showWelcome ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
                    } flex flex-col items-center text-center gap-3 ${quoteReady && quoteOfTheDay ? '' : 'justify-center'}`}
                    style={{
                      backdropFilter: 'blur(20px) saturate(1.4)',
                      minHeight: quoteReady && quoteOfTheDay ? 'auto' : 'min(140px, 20vh)',
                    }}
                  >
                    <p
                      className={`text-center font-semibold text-[rgb(95,179,249)] shimmer-text ${infoFocusActive ? 'is-shimmering' : 'shimmer-text--cooldown'}`}
                      style={{
                        fontSize: quoteReady && quoteOfTheDay ? 'clamp(1rem, 3.2vw, 1.6rem)' : 'clamp(1.32rem, 4.9vw, 1.9rem)',
                        lineHeight: 1.2,
                        transform: quoteReady && quoteOfTheDay ? 'translateY(-8px)' : 'translateY(0)',
                        transition: 'font-size 600ms ease, transform 600ms ease',
                      }}
                    >
                      Welcome{user.visits && user.visits > 1 ? ' back' : ''}, {user.name}!
                    </p>
                    <div className="w-full rounded-lg bg-white/65 px-4 py-3 text-center shadow-inner transition-opacity duration-500" aria-live="polite">
                      {!quoteReady && (
                        <div className="flex flex-col items-center gap-2 w-full">
                          <div className="news-loading-line news-loading-shimmer w-3/4" aria-hidden="true" />
                          <div className="news-loading-line news-loading-shimmer w-2/3" aria-hidden="true" />
                        </div>
                      )}
                      {quoteReady && quoteOfTheDay && (
                        <p className="text-sm italic text-gray-700">
                          "{quoteOfTheDay.text}" — {quoteOfTheDay.author}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className={`flex justify-center ${
              landingAuthMode === 'signup' ? 'mb-6 sm:mb-8 lg:mb-12' : 'mb-12 sm:mb-12 lg:mb-20'
            }`}>
              <div className="brand-logo brand-logo--landing">
                <img
                  src="/Peppro_fulllogo.png"
                  alt="PepPro"
                  style={{
                    display: 'block',
                    width: 'auto',
                    height: 'auto',
                    maxWidth: 'min(360px, 80vw)',
                    maxHeight: 'min(360px, 40vh)',
                    objectFit: 'contain'
                  }}
                />
              </div>
            </div>
          )}

          {/* Info Container - After Login */}
          {postLoginHold && user ? (
            <div className="w-full max-w-6xl mt-4 sm:mt-6 md:mt-8">

              <div className="post-login-layout">
                <div className="post-login-news glass-card landing-glass squircle-xl border border-[var(--brand-glass-border-2)] p-6 sm:p-8 shadow-xl" style={{ backdropFilter: 'blur(38px) saturate(1.6)' }}>
                  <div className="space-y-5">
                    <div className="flex items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg sm:text-xl font-semibold text-[rgb(95,179,249)]">Peptide News</h2>
                        <button
                          onClick={handleRefreshNews}
                          disabled={peptideNewsLoading}
                          className="p-1.5 rounded-md hover:bg-[rgba(95,179,249,0.1)] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title="Refresh news"
                        >
                          <RefreshCw className={`h-4 w-4 text-[rgb(95,179,249)] ${peptideNewsLoading ? 'animate-spin' : ''}`} />
                        </button>
                        {peptideNewsUpdatedAt && (
                          <span className="text-xs text-gray-500">
                            Updated at: {peptideNewsUpdatedAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
                          </span>
                        )}
                      </div>
                      <a
                        href="https://www.nature.com/subjects/peptides"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold uppercase tracking-wide text-[rgb(95,179,249)] hover:underline"
                      >
                        View All
                      </a>
                    </div>
                    <div className="max-h-[60vh] overflow-y-auto pr-1 space-y-4 text-sm text-gray-700 leading-relaxed">
                      {peptideNewsLoading && (
                        <ul className="space-y-4" aria-live="polite">
                          {newsLoadingPlaceholders.map((_, index) => (
                            <li key={index} className="news-loading-card flex items-start gap-3">
                              <div className="news-loading-thumb" aria-hidden="true" />
                              <div className="flex-1 space-y-2">
                                <div className="news-loading-line news-loading-shimmer w-3/4" aria-hidden="true" />
                                <div className="news-loading-line news-loading-shimmer w-full" aria-hidden="true" />
                                <div className="news-loading-line news-loading-shimmer w-1/2" aria-hidden="true" />
                              </div>
                            </li>
                          ))}
                          <li className="text-xs text-slate-500 pl-1">Loading latest headlines…</li>
                        </ul>
                      )}
                      {!peptideNewsLoading && peptideNewsError && (
                        <p className="text-xs text-red-600">{peptideNewsError}</p>
                      )}
                      {!peptideNewsLoading && !peptideNewsError && peptideNews.length === 0 && (
                        <p className="text-xs text-slate-600">No headlines available right now. Please check back soon.</p>
                      )}
                      {!peptideNewsLoading && !peptideNewsError && peptideNews.length > 0 && (
                        <>
                          <ul className="space-y-4">
                            {peptideNews.map((item) => (
                              <li key={item.url} className="flex items-start gap-3">
                                <div className="peptide-news-thumb flex-none ring-1 ring-white/40 shadow-sm">
                                  <img
                                    src={item.image ?? PEPTIDE_NEWS_PLACEHOLDER_IMAGE}
                                    alt={`Peptide news: ${item.title}`}
                                    loading="lazy"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <div>
                                    <a
                                      href={item.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[rgb(95,179,249)] font-semibold hover:underline"
                                      aria-label={`${item.date ? formatNewsDate(item.date) + ' — ' : ''}${item.title}`}
                                    >
                                      {item.date && (
                                        <span className="text-xs text-gray-500 mr-2">
                                          {formatNewsDate(item.date)}
                                        </span>
                                      )}
                                      <span className="align-middle">{item.title}</span>
                                    </a>
                                  </div>
                                  {item.summary && (
                                    <p className="text-xs text-gray-600 leading-relaxed">
                                      {item.summary}
                                    </p>
                                  )}
                                </div>
                              </li>
                            ))}
                          </ul>
                          <div className="pt-4 text-[11px] uppercase tracking-wide text-gray-500 border-t border-white/40">
                            Source:{' '}
                            <a
                              href="https://www.nature.com/subjects/peptides"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-semibold text-[rgb(95,179,249)] hover:underline"
                            >
                              Nature.com – Peptide Subject
                            </a>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="post-login-info glass-card landing-glass squircle-xl border border-[var(--brand-glass-border-2)] p-6 sm:p-8 shadow-xl" style={{ backdropFilter: 'blur(38px) saturate(1.6)' }}>
                  <div className="space-y-4">
                    <div className="flex w-full justify-between gap-3 pb-2">
                      <Button
                        type="button"
                        size="lg"
                        onClick={handleLogout}
                        className="text-white squircle-sm px-6 py-2 font-semibold uppercase tracking-wide shadow-lg shadow-[rgba(95,179,249,0.4)] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[rgba(95,179,249,0.35)] focus-visible:ring-offset-2 focus-visible:ring-offset-white transition-all duration-300 hover:shadow-xl hover:scale-105 hover:-translate-y-0.5 active:translate-y-0"
                        style={{ backgroundColor: 'rgb(95, 179, 249)' }}
                      >
                        <ArrowLeft className="h-4 w-4 mr-2" aria-hidden="true" />
                        <span>Logout</span>
                      </Button>
                      <Button
                        type="button"
                        size="lg"
                        onClick={handleAdvanceFromWelcome}
                        className="text-white squircle-sm px-6 py-2 font-semibold uppercase tracking-wide shadow-lg shadow-[rgba(95,179,249,0.4)] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[rgba(95,179,249,0.35)] focus-visible:ring-offset-2 focus-visible:ring-offset-white transition-all duration-300 hover:shadow-xl hover:scale-105 hover:-translate-y-0.5 active:translate-y-0"
                        style={{ backgroundColor: 'rgb(95, 179, 249)' }}
                      >
                        <span className="mr-2">Shop</span>
                        <ArrowRight className="h-4 w-4" aria-hidden="true" />
                      </Button>
                    </div>
                    {/* Regional contact info for doctors */}
                    {user.role !== 'sales_rep' && (
                      <div className="glass-card squircle-md p-4 space-y-2 border border-[var(--brand-glass-border-2)]">
                        <p className="text-sm font-medium text-slate-700">Please contact your Regional Administrator anytime.</p>
                        <div className="space-y-1 text-sm text-slate-600">
                          <p><span className="font-semibold">Name:</span> {user.salesRep?.name || 'N/A'}</p>
                          <p>
                            <span className="font-semibold">Email:</span>{' '}
                            {user.salesRep?.email ? (
                              <a href={`mailto:${user.salesRep.email}`} className="text-[rgb(95,179,249)] hover:underline">
                                {user.salesRep.email}
                              </a>
                            ) : (
                              'N/A'
                            )}
                          </p>
                          <p><span className="font-semibold">Phone:</span> {user.salesRep?.phone || 'N/A'}</p>
                        </div>
                      </div>
                    )}
                    {/* Passkey registration now handled automatically after login when supported */}
                    <div className="relative flex flex-col gap-6 max-h-[70vh]">
                      <div className="flex-1 overflow-y-auto pr-1 space-y-16">
                        {/* Removed: Customer experiences & referrals section */}

                        <div className="grid gap-10 md:grid-cols-[1.15fr_0.85fr] mb-4">
                          <section className="squircle glass-card landing-glass border border-[var(--brand-glass-border-2)] p-6 shadow-sm mb-4">
                            <h3 className="text-lg font-semibold text-[rgb(95,179,249)] mb-4">Physicians' Choice Program</h3>
                            <div className="space-y-4 text-sm text-gray-700 leading-relaxed">
                              <p>
                                The Physicians' Choice Program is designed exclusively for medical professionals who order 25 units or more of a single product. Participants can choose to private label their products and/or utilize our 3PL Fulfillment Program for seamless inventory and distribution management.
                              </p>
                            </div>
                            <div className="text-sm text-gray-700 leading-relaxed">
                              <h4 className="text-sm font-semibold text-[rgb(95,179,249)] uppercase tracking-wide" style={{ marginTop: '12px', marginBottom: 0 }}>Private Labeling</h4>
                              <p className="mt-0">
                                Physicians who opt to private label will collaborate with their Regional Administrator to provide logos and branding details for custom product labels.
                              </p>
                              <p className="mt-3">
                                For those wishing to customize beyond the standard PepPro label design - such as changing colors, layout, or branding - we will provide a die line template for your designer to create your preferred look and feel. If design assistance is needed, we can connect you with a trusted graphic design partner.
                              </p>
                            </div>
                            <div className="text-sm text-gray-700 leading-relaxed">
                              <h4 className="text-sm font-semibold text-[rgb(95,179,249)] uppercase tracking-wide" style={{ marginTop: '12px', marginBottom: 0 }}>3PL Fulfillment Program</h4>
                              <p className="mt-0">
                                Our third-party logistics (3PL) program enables physicians to maintain inventory at our Anaheim, CA fulfillment center, ensuring quick, reliable delivery directly to patients. Participants may also hold stock at their practice for in-person distribution.
                              </p>
                              <p className="mt-3">
                                All PepPro products are produced in GMP-certified and 503A/503B-compliant facilities located in San Diego, CA. Each order is stored in a temperature-controlled environment and shipped within 24 hours of receipt.
                              </p>
                              <p className="mt-3">
                                Shipments include ice packs to maintain product integrity, ensuring all items arrive cold and ready for use. Comprehensive dosing instructions are included with every order - covering nasal sprays, vials, and chewables.
                              </p>
                            </div>
                            <div className="text-sm text-gray-700 leading-relaxed">
                              <h4 className="text-sm font-semibold text-[rgb(95,179,249)] uppercase tracking-wide" style={{ marginTop: '12px', marginBottom: 0 }}></h4>
                              <p className="mt-0 font-semibold text-[rgb(95,179,249)]">
                                Orders over $250 qualify for free shipping within the U.S.A.
                              </p>
                            </div>
                          </section>
                          <section className="squircle glass-card landing-glass border border-[var(--brand-glass-border-2)] p-6 shadow-sm flex items-center justify-center">
                            <figure className="space-y-4 flex flex-col items-center">
                              <img
                                src="/src/data/Peptide_PNGs/PeptidePackagedWell.png"
                                alt="PepPro fulfillment specialists preparing temperature-controlled shipments"
                                className="object-contain shadow-md"
                                style={{ width: '50%', height: 'auto' }}
                              />
                              <figcaption className="text-xs text-gray-500">
                                {/* Supply supporting caption or accreditation */}
                              </figcaption>
                            </figure>
                          </section>
                        </div>

                        <section className="squircle glass-strong landing-glass-strong border border-[var(--brand-glass-border-3)] p-6 text-slate-900 shadow-sm">
                          <h3 className="text-lg font-semibold">Care & Compliance</h3>
                          <div className="mt-4 text-sm">
                            <p>PepPro peptide products are research chemicals intended for licensed physicians only. They are not intended to prevent, treat, or cure any medical condition, ailment or disease. These products have not been reviewed or approved by the US Food and Drug Administration.</p>
                          </div>
                        </section>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className={`w-full max-w-md ${
              landingAuthMode === 'signup' ? 'mt-3 sm:mt-4 md:mt-6' : 'mt-4 sm:mt-6 md:mt-8'
            }`}>
              <div
                className="glass-card landing-glass squircle-xl border border-[var(--brand-glass-border-2)] p-8 shadow-xl"
                style={{ backdropFilter: 'blur(38px) saturate(1.6)' }}
              >
                <div className={landingAuthMode === 'login' ? 'space-y-4' : 'space-y-6'}>
                {landingAuthMode === 'login' ? (
                  <>
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        if (landingLoginPending) {
                          return;
                        }
                        setLandingLoginError('');
                        setLandingLoginPending(true);
                        try {
                          const fd = new FormData(e.currentTarget);
                          const res = await handleLogin(fd.get('username') as string, fd.get('password') as string);
                          if (res.status !== 'success') {
                            if (res.status === 'invalid_password') {
                              setLandingLoginError('Incorrect password. Please try again.');
                            } else if (res.status === 'email_not_found') {
                              setLandingLoginError('We could not find that email.');
                            } else {
                              setLandingLoginError('Unable to log in. Please try again.');
                            }
                          }
                        } catch (error) {
                          console.warn('[Landing Login] Failed', error);
                          setLandingLoginError('Unable to log in. Please try again.');
                        } finally {
                          setLandingLoginPending(false);
                        }
                      }}
                      className="space-y-3"
                      autoComplete="on"
                    >
                      <div className="space-y-2">
                        <label htmlFor="landing-username" className="text-sm font-medium">Email</label>
                        <input
                          ref={landingLoginEmailRef}
                          id="landing-username"
                          name="username"
                          type="text"
                          autoComplete="username"
                          inputMode="email"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          required
                          onFocus={handleLandingCredentialFocus}
                          className="w-full h-10 px-3 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                        />
                        {/* Hidden field to hint WebAuthn conditional UI to the browser */}
                        <input
                          type="text"
                          autoComplete="webauthn"
                          aria-hidden="true"
                          tabIndex={-1}
                          style={{ position: 'absolute', left: '-9999px', top: 'auto', width: '1px', height: '1px', opacity: 0 }}
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-password" className="text-sm font-medium">Password</label>
                        <div className="relative">
                          <input
                            ref={landingLoginPasswordRef}
                            id="landing-password"
                            name="password"
                            type={showLandingLoginPassword ? 'text' : 'password'}
                            autoComplete="current-password"
                            autoCorrect="off"
                            spellCheck={false}
                            required
                            onFocus={handleLandingCredentialFocus}
                            className="w-full h-10 px-3 pr-12 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                          />
                          <button
                            type="button"
                            onClick={() => setShowLandingLoginPassword((p) => !p)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 flex h-8 w-8 items-center justify-center rounded-md text-gray-600 hover:text-gray-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[rgba(95,179,249,0.3)] btn-hover-lighter"
                            aria-label={showLandingLoginPassword ? 'Hide password' : 'Show password'}
                            aria-pressed={showLandingLoginPassword}
                          >
                            {showLandingLoginPassword ? (
                              <Eye className="h-5 w-5" />
                            ) : (
                              <EyeOff className="h-5 w-5" />
                            )}
                          </button>
                        </div>
                      </div>
                      {landingLoginError && (
                        <p className="text-sm text-red-600" role="alert">{landingLoginError}</p>
                      )}
                      {passkeySupport.platform && (
                        <Button
                          type="button"
                          variant="outline"
                          size="lg"
                          onClick={handleManualPasskeyLogin}
                          disabled={passkeyLoginPending}
                          className="w-full squircle-sm btn-hover-lighter"
                          aria-label="Sign in with a passkey (biometrics)"
                        >
                          <Fingerprint className="h-4 w-4" aria-hidden="true" />
                          {passkeyLoginPending ? 'Waiting for biometric confirmation…' : 'Sign in with passkey'}
                        </Button>
                      )}
                      <Button
                        type="submit"
                        size="lg"
                        className="w-full squircle-sm glass-brand btn-hover-lighter inline-flex items-center justify-center gap-2"
                        disabled={landingLoginPending}
                      >
                        {landingLoginPending && (
                          <Loader2
                            className="h-4 w-4 animate-spin-slow text-white shrink-0"
                            aria-hidden="true"
                            style={{ transformOrigin: 'center center' }}
                          />
                        )}
                        {landingLoginPending ? 'Signing in…' : 'Sign In'}
                      </Button>
                    </form>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">
                        Have a referral code?{' '}
                        <button type="button" onClick={() => updateLandingAuthMode('signup')} className="font-semibold hover:underline btn-hover-lighter" style={{ color: 'rgb(95, 179, 249)' }}>
                          Create an account
                        </button>
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="text-center space-y-2">
                      <h1 className="text-2xl font-semibold">Join the PepPro Network</h1>
                    </div>
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        setLandingSignupError('');
                        const fd = new FormData(e.currentTarget);
                        const suffix = (fd.get('suffix') as string) || '';
                        const nameOnly = (fd.get('name') as string) || '';
                        const fullName = suffix ? `${suffix} ${nameOnly}`.trim() : nameOnly;
                        const details = {
                          name: fullName,
                          email: (fd.get('email') as string) || '',
                          password: (fd.get('password') as string) || '',
                          confirmPassword: (fd.get('confirm') as string) || '',
                          code: ((fd.get('code') as string) || '').toUpperCase(),
                          npiNumber: (fd.get('npiNumber') as string) || '',
                        };
                        const res = await handleCreateAccount(details);
                        if (res.status === 'success') {
                          updateLandingAuthMode('login');
                        } else if (res.status === 'email_exists') {
                          setLandingSignupError('An account with this email already exists. Please sign in.');
                        } else if (res.status === 'invalid_referral_code') {
                          setLandingSignupError('Referral codes must be 5 characters (e.g., AB123).');
                        } else if (res.status === 'referral_code_not_found') {
                          setLandingSignupError('We couldn\'t locate that onboarding code. Please confirm it with your regional administrator.');
                        } else if (res.status === 'referral_code_unavailable') {
                          setLandingSignupError('This onboarding code has already been used. Ask your regional administrator for a new code.');
                        } else if (res.status === 'name_email_required') {
                          setLandingSignupError('Name and email are required to create your account.');
                        } else if (res.status === 'password_mismatch') {
                          setLandingSignupError('Passwords do not match. Please confirm and try again.');
                        } else if (res.status === 'invalid_npi') {
                          setLandingSignupError('Enter a valid 10-digit NPI number assigned to you by CMS.');
                        } else if (res.status === 'npi_not_found') {
                          setLandingSignupError('We couldn\'t verify that NPI number in the CMS registry. Please double-check and try again.');
                        } else if (res.status === 'npi_already_registered') {
                          setLandingSignupError('An account already exists for this NPI number. Please sign in or contact support.');
                        } else if (res.status === 'npi_verification_failed') {
                          setLandingSignupError('We were unable to reach the CMS NPI registry. Please try again in a moment.');
                        } else if (res.status === 'error') {
                          if (res.message === 'PASSWORD_REQUIRED') {
                            setLandingSignupError('Please create a secure password to access your account.');
                          } else if (res.message) {
                            setLandingSignupError(res.message);
                          } else {
                            setLandingSignupError('Unable to create account. Please try again.');
                          }
                        }
                      }}
                      className="space-y-4"
                    >
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:gap-4">
                        <div className="space-y-2 sm:w-36">
                          <label htmlFor="landing-suffix" className="text-sm font-medium">Suffix</label>
                          <select
                            id="landing-suffix"
                            name="suffix"
                            className="glass squircle-sm w-full px-3 text-sm border transition-colors focus-visible:outline-none focus-visible:border-[rgb(95,179,249)] focus-visible:ring-[rgba(95,179,249,0.3)] leading-tight"
                            style={{
                              borderColor: 'rgba(95,179,249,0.18)',
                              backgroundColor: 'rgba(95,179,249,0.02)',
                              WebkitAppearance: 'none' as any,
                              MozAppearance: 'none' as any,
                              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23071b1b' d='M6 9L1 4h10z'/%3E%3C/svg%3E")`,
                              backgroundRepeat: 'no-repeat',
                              backgroundPosition: 'right 0.75rem center',
                              backgroundSize: '12px',
                              paddingRight: '2.5rem',
                              height: '2.5rem',
                              lineHeight: '1.25rem'
                            }}
                          >
                            <option value="">None</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Mrs.">Mrs.</option>
                            <option value="Ms.">Ms.</option>
                            <option value="Mx.">Mx.</option>
                            <option value="Dr.">Dr.</option>
                            <option value="Prof.">Prof.</option>
                            <option value="Sir">Sir</option>
                            <option value="Dame">Dame</option>
                          </select>
                        </div>
                        <div className="flex-1 space-y-2">
                          <label htmlFor="landing-name" className="text-sm font-medium">Full Name</label>
                          <input id="landing-name" name="name" type="text" required className="w-full h-10 px-3 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-email2" className="text-sm font-medium">Email</label>
                        <input id="landing-email2" name="email" type="email" required className="w-full h-10 px-3 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-password2" className="text-sm font-medium">Password</label>
                        <div className="relative">
                          <input
                            id="landing-password2"
                            name="password"
                            type={showLandingSignupPassword ? 'text' : 'password'}
                            required
                            autoComplete="new-password"
                            className="w-full h-10 px-3 pr-12 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                          />
                          <button
                            type="button"
                            onClick={() => setShowLandingSignupPassword((p) => !p)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 flex h-8 w-8 items-center justify-center rounded-md text-gray-600 hover:text-gray-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[rgba(95,179,249,0.3)] btn-hover-lighter"
                            aria-label={showLandingSignupPassword ? 'Hide password' : 'Show password'}
                            aria-pressed={showLandingSignupPassword}
                          >
                            {showLandingSignupPassword ? (
                              <Eye className="h-5 w-5" />
                            ) : (
                              <EyeOff className="h-5 w-5" />
                            )}
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-confirm" className="text-sm font-medium">Confirm Password</label>
                        <div className="relative">
                          <input
                            id="landing-confirm"
                            name="confirm"
                            type={showLandingSignupConfirm ? 'text' : 'password'}
                            required
                            autoComplete="new-password"
                            className="w-full h-10 px-3 pr-12 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                          />
                          <button
                            type="button"
                            onClick={() => setShowLandingSignupConfirm((p) => !p)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 flex h-8 w-8 items-center justify-center rounded-md text-gray-600 hover:text-gray-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[rgba(95,179,249,0.3)] btn-hover-lighter"
                            aria-label={showLandingSignupConfirm ? 'Hide confirm password' : 'Show confirm password'}
                            aria-pressed={showLandingSignupConfirm}
                          >
                            {showLandingSignupConfirm ? (
                              <Eye className="h-5 w-5" />
                            ) : (
                              <EyeOff className="h-5 w-5" />
                            )}
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-npi" className="text-sm font-medium">NPI Number</label>
                        <input
                          id="landing-npi"
                          name="npiNumber"
                          type="text"
                          inputMode="numeric"
                          pattern="\d*"
                          maxLength={10}
                          placeholder="10-digit NPI"
                          onInput={(event) => {
                            const target = event.currentTarget;
                            const digits = target.value.replace(/[^0-9]/g, '').slice(0, 10);
                            target.value = digits;
                            handleLandingNpiInputChange(digits);
                          }}
                          className="w-full h-10 px-3 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                        />
                        <p
                          className={`text-xs ${
                            landingNpiStatus === 'verified'
                              ? 'text-emerald-600'
                              : landingNpiStatus === 'rejected'
                                ? 'text-red-600'
                                : 'text-slate-500'
                          }`}
                        >
                          {landingNpiStatus === 'idle' &&
                            'We securely verify your medical credentials with the CMS NPI registry.'}
                          {landingNpiStatus === 'checking' && 'Contacting the CMS NPI registry...'}
                          {landingNpiStatus === 'verified' && (
                            <span className="inline-flex items-center gap-1">
                              <span className="npi-checkmark" aria-hidden="true">✔</span>
                              {landingNpiMessage || 'NPI verified with the CMS registry.'}
                            </span>
                          )}
                          {landingNpiStatus === 'rejected' &&
                            (landingNpiMessage || 'We were unable to verify this NPI number. Please double-check and try again.')}
                        </p>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="landing-code" className="text-sm font-medium">Referral Code</label>
                        <input
                          id="landing-code"
                          name="code"
                          type="text"
                          required
                          maxLength={5}
                          inputMode="text"
                          pattern="[A-Z0-9]*"
                          autoComplete="off"
                          onInput={(event) => {
                            const target = event.currentTarget;
                            target.value = target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5);
                          }}
                          className="w-full h-10 px-3 squircle-sm border border-slate-200/70 bg-white/96 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                          style={{ textTransform: 'uppercase' }}
                        />
                        <p className="text-xs text-slate-500">Codes are 5 characters and issued by your regional administrator.</p>
                      </div>
                      {landingSignupError && (
                        <p className="text-sm text-red-600" role="alert">{landingSignupError}</p>
                      )}
                      <Button
                        type="submit"
                        size="lg"
                        className="w-full squircle-sm glass-brand btn-hover-lighter"
                      >
                        Create Account
                      </Button>
                    </form>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">
                        Already have an account?{' '}
                        <button type="button" onClick={() => updateLandingAuthMode('login')} className="font-semibold hover:underline btn-hover-lighter" style={{ color: 'rgb(95, 179, 249)' }}>
                          Sign in
                        </button>
                      </p>
                    </div>
                  </>
                )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

          {/* Main Content */}
          {user && !postLoginHold && (
            <main className="w-full py-12 mobile-safe-area" style={{ marginTop: '2.4rem' }}>
              {user.role === 'sales_rep' ? renderSalesRepDashboard() : renderDoctorDashboard()}
              {renderProductSection()}
            </main>
          )}
        </div>

        <LegalFooter />
      </div>

      {/* Checkout Modal */}
      {stripePromise ? (
        <Elements stripe={stripePromise}>
          <CheckoutModal
            isOpen={checkoutOpen}
            onClose={() => setCheckoutOpen(false)}
            cartItems={cartItems}
            onCheckout={handleCheckout}
            onClearCart={() => setCartItems([])}
            onPaymentSuccess={() => {
              const requestToken = Date.now();
              setAccountModalRequest({ tab: 'orders', open: true, token: requestToken });
              setTimeout(() => {
                setAccountModalRequest((prev) => (prev && prev.token === requestToken ? null : prev));
              }, 2500);
            }}
            onUpdateItemQuantity={handleUpdateCartItemQuantity}
            onRemoveItem={handleRemoveCartItem}
            isAuthenticated={Boolean(user)}
            onRequireLogin={handleRequireLogin}
            physicianName={user?.npiVerification?.name || user?.name || null}
            customerEmail={user?.email || null}
            customerName={user?.name || null}
          />
        </Elements>
      ) : (
        <CheckoutModal
          isOpen={checkoutOpen}
          onClose={() => setCheckoutOpen(false)}
          cartItems={cartItems}
          onCheckout={handleCheckout}
          onClearCart={() => setCartItems([])}
          onPaymentSuccess={() => {
            const requestToken = Date.now();
            setAccountModalRequest({ tab: 'orders', open: true, token: requestToken });
            setTimeout(() => {
              setAccountModalRequest((prev) => (prev && prev.token === requestToken ? null : prev));
            }, 2500);
          }}
          onUpdateItemQuantity={handleUpdateCartItemQuantity}
          onRemoveItem={handleRemoveCartItem}
          isAuthenticated={Boolean(user)}
          onRequireLogin={handleRequireLogin}
          physicianName={user?.npiVerification?.name || user?.name || null}
          customerEmail={user?.email || null}
          customerName={user?.name || null}
        />
      )}

      <ProductDetailDialog
        product={selectedProduct}
        isOpen={productDetailOpen}
        onClose={handleCloseProductDetail}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
}
