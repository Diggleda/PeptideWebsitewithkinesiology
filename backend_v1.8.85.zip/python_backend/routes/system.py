from __future__ import annotations

from flask import Blueprint

import os
import platform
import shutil
from pathlib import Path

from ..services import get_config
from ..services import news_service
from ..integrations import ship_engine, woo_commerce
from ..utils.http import handle_action

blueprint = Blueprint("system", __name__, url_prefix="/api")

def _read_linux_meminfo() -> dict | None:
    try:
        if platform.system().lower() != "linux":
            return None
        meminfo_path = Path("/proc/meminfo")
        if not meminfo_path.exists():
            return None
        parsed: dict[str, int] = {}
        for line in meminfo_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if ":" not in line:
                continue
            key, rest = line.split(":", 1)
            value = rest.strip().split(" ", 1)[0]
            if value.isdigit():
                parsed[key.strip()] = int(value)
        # Values are kB.
        total_kb = parsed.get("MemTotal")
        avail_kb = parsed.get("MemAvailable") or parsed.get("MemFree")
        if not total_kb or not avail_kb:
            return None
        used_kb = max(0, total_kb - avail_kb)
        used_pct = round((used_kb / total_kb) * 100, 2) if total_kb else None
        return {
            "totalMb": round(total_kb / 1024, 2),
            "availableMb": round(avail_kb / 1024, 2),
            "usedPercent": used_pct,
        }
    except Exception:
        return None


def _process_memory_mb() -> float | None:
    try:
        import resource  # type: ignore

        usage = resource.getrusage(resource.RUSAGE_SELF)
        maxrss = getattr(usage, "ru_maxrss", None)
        if maxrss is None:
            return None
        # On Linux it's kilobytes; on macOS it's bytes.
        if platform.system().lower() == "darwin":
            return round(float(maxrss) / (1024 * 1024), 2)
        return round(float(maxrss) / 1024, 2)
    except Exception:
        return None


def _disk_usage(path: str) -> dict | None:
    try:
        usage = shutil.disk_usage(path)
        total = float(usage.total)
        used = float(usage.used)
        free = float(usage.free)
        used_pct = round((used / total) * 100, 2) if total else None
        return {
            "totalGb": round(total / (1024**3), 2),
            "freeGb": round(free / (1024**3), 2),
            "usedPercent": used_pct,
        }
    except Exception:
        return None


def _server_usage() -> dict:
    cpu_count = os.cpu_count() or 0
    load_avg = None
    load_pct = None
    try:
        if hasattr(os, "getloadavg"):
            one, five, fifteen = os.getloadavg()
            load_avg = {"1m": round(one, 2), "5m": round(five, 2), "15m": round(fifteen, 2)}
            if cpu_count > 0:
                load_pct = round((one / cpu_count) * 100, 2)
    except Exception:
        load_avg = None

    config = get_config()
    data_dir = str(getattr(config, "data_dir", None) or Path.cwd())

    return {
        "cpu": {
            "count": cpu_count or None,
            "loadAvg": load_avg,
            "loadPercent": load_pct,
        },
        "memory": _read_linux_meminfo(),
        "disk": _disk_usage(data_dir),
        "process": {"maxRssMb": _process_memory_mb()},
        "platform": platform.platform(),
    }


@blueprint.get("/health")
def health():
    def action():
        config = get_config()
        return {
            "status": "ok",
            "message": "Server is running",
            "build": config.backend_build,
            "usage": _server_usage(),
            "timestamp": _now(),
        }

    return handle_action(action)


@blueprint.get("/help")
def help_endpoint():
    def action():
        config = get_config()
        return {
            "ok": True,
            "service": "PepPro Backend",
            "build": config.backend_build,
            "integrations": {
                "wooCommerce": {"configured": woo_commerce.is_configured()},
                "shipEngine": {"configured": ship_engine.is_configured()},
                "shipStation": {"configured": getattr(config, "ship_station", {}).get("api_token") or getattr(config, "ship_station", {}).get("api_key")},
            },
            "endpoints": [
                "/api/auth/login",
                "/api/auth/register",
                "/api/auth/me",
                "/api/auth/check-email",
                "/api/orders",
                "/api/shipping/rates",
                "/api/quotes/daily",
                "/api/quotes",
                "/api/woo/products",
                "/api/woo/products/categories",
                "/api/referrals/doctor/summary",
                "/api/referrals/admin/dashboard",
                "/api/settings/shop",
                "/api/contact",
                "/api/integrations/google-sheets/sales-reps",
                "/api/help",
                "/api/news/peptides",
                "/api/health",
            ],
            "timestamp": _now(),
        }

    return handle_action(action)


def _now():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


@blueprint.get("/news/peptides")
def peptide_news():
    def action():
        items = news_service.fetch_peptide_news(limit=8)
        return {
            "items": [
                {
                    "title": item.title,
                    "url": item.url,
                    "summary": item.summary,
                    "imageUrl": item.image_url,
                    "date": item.date,
                }
                for item in items
            ],
            "count": len(items),
        }

    return handle_action(action)
