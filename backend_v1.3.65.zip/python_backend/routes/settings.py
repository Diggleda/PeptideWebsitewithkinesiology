from __future__ import annotations

from flask import Blueprint, request

from ..storage import settings_store
from ..utils.http import handle_action

blueprint = Blueprint("settings", __name__, url_prefix="/api/settings")


def _get_settings():
    if settings_store:
        return settings_store.read() or {"shopEnabled": True}
    return {"shopEnabled": True}


def _write_settings(data):
    if settings_store:
        settings_store.write(data)


@blueprint.get("/shop")
def get_shop():
    def action():
        settings = _get_settings()
        return {"shopEnabled": bool(settings.get("shopEnabled", True))}

    return handle_action(action)


@blueprint.put("/shop")
def update_shop():
    def action():
        payload = request.get_json(silent=True) or {}
        enabled = bool(payload.get("enabled", False))
        settings = _get_settings()
        settings["shopEnabled"] = enabled
        _write_settings(settings)
        return {"shopEnabled": enabled}

    return handle_action(action)
