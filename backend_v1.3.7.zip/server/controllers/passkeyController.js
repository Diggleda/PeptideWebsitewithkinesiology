const passkeyService = require('../services/passkeyService');

const isLoopbackHost = (host) => {
  if (!host) {
    return false;
  }
  const normalized = host.toLowerCase();
  return normalized.includes('localhost') || normalized.startsWith('127.') || normalized === '::1';
};

const resolveProtocol = (req, host) => {
  const raw = (req.headers['x-forwarded-proto'] || req.protocol || '').split(',')[0]?.trim().toLowerCase();
  if (raw === 'http' && host && !isLoopbackHost(host)) {
    return 'https';
  }
  if (raw) {
    return raw;
  }
  return host && !isLoopbackHost(host) ? 'https' : 'http';
};

const getRequestOrigin = (req) => {
  const directOrigin = req.get('origin');
  if (directOrigin) {
    return directOrigin;
  }
  const referer = req.get('referer');
  if (referer) {
    try {
      return new URL(referer).origin;
    } catch {
      // ignore invalid referer
    }
  }
  const forwardedHost = (req.headers['x-forwarded-host'] || req.get('host') || '').split(',')[0]?.trim();
  if (forwardedHost) {
    const protocol = resolveProtocol(req, forwardedHost);
    return `${protocol}://${forwardedHost}`;
  }
  return null;
};

const getRequestRpId = (req) => {
  const hostHeader = (req.headers['x-forwarded-host'] || req.get('host') || '').split(',')[0]?.trim();
  if (!hostHeader) {
    return null;
  }
  return hostHeader.split(':')[0].toLowerCase();
};

const registrationOptions = async (req, res, next) => {
  try {
    const context = {
      origin: getRequestOrigin(req),
      rpId: getRequestRpId(req),
    };
    const result = await passkeyService.generateOptionsForRegistration(req.user.id, context);
    res.json(result);
  } catch (error) {
    next(error);
  }
};

const verifyRegistration = async (req, res, next) => {
  try {
    const context = {
      origin: getRequestOrigin(req),
      rpId: getRequestRpId(req),
    };
    const result = await passkeyService.verifyRegistration(req.body, req.user.id, context);
    res.json(result);
  } catch (error) {
    next(error);
  }
};

const authenticationOptions = async (req, res, next) => {
  try {
    const context = {
      origin: getRequestOrigin(req),
      rpId: getRequestRpId(req),
    };
    const result = await passkeyService.generateOptionsForAuthentication(req.body?.email || '', context);
    res.json(result);
  } catch (error) {
    next(error);
  }
};

const verifyAuthentication = async (req, res, next) => {
  try {
    const context = {
      origin: getRequestOrigin(req),
      rpId: getRequestRpId(req),
    };
    const result = await passkeyService.verifyAuthentication(req.body, context);
    res.json(result);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registrationOptions,
  verifyRegistration,
  authenticationOptions,
  verifyAuthentication,
};
